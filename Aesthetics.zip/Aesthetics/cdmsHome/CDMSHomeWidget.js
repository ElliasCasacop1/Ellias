var glblUtil;
var glblDom;
var glblTabContainer;
var glblContentPane;
var glblBorderContainer;
var glblICMUtil;
var glblDataGrid;
var glblall;
var glblLang;
var glblECMRequest;
var glblAttr;
var glblItemFileWriteStore;
var globalUserShortName;
var glblWorkflowInstId;
var glblNamesForInquiry;
var glnldomConstruct;
var thisMainObj;
var solutionPrefix;
var subWFCode="";
var strStepCode;
var strPageId;
var isOtherTask=0;
var isOutBox=0;
var iData;
var glblRqstCancel;
var glblVariousSEC;
var stDTIStepCode="";
var strDTISubWorkflow="";
var stSECStepCode="";
var strSECSubWorkflow="";
var gridId = "ForVeriGrid";
var grid;
var ForVeriGrid;
var actionTakenData = [];
var storeAction;
var PageLimit = 50;
var PageNum = 1;
var strIsFiltered = 0;
var globalUserId;
var glblTabId="tabForVerification";
var glblCDMSUploader;
var cmdHistory = function(){
	 var cmdHist = new dijit.form.Button({ 
       label: 'View',
       iconClass: "viewIcon"
	 });
	
	return cmdHist;
};

define([
        "dojo/_base/declare",
        "dojo/json",
        "icm/base/BasePageWidget",
        "icm/base/_BaseWidget",
        "dojo/on",
        "dojo/query",
        "cdmsPluginCustomWidget/util/DropDownMenu",
        "cdmsPluginCustomWidget/util/pagenavigation",
        "dijit/form/ComboBox",
        "cdmsPluginCustomWidget/util/ICMUtil",
        "icm/base/Constants",
        "dojo/_base/lang",
        "dojo/text!./templates/CDMSHomeWidget.html",
        "dijit/form/Button",
        "dijit/_WidgetsInTemplateMixin",
        "ecm/LoggerMixin",
        "dojo/Deferred","dojo/promise/all",
        "icm/util/Coordination",
        "cdmsPluginCustomWidget/util/Util",
        "icm/model/CaseEditable",
        "ecm/model/Request",
        "dojo/_base/lang",
        "cdmsPluginCustomWidget/lookup/WFSearch",
        "dojo/data/ItemFileWriteStore",
        "icm/model/Case",
        "dojo/dom",
        "cdmsPluginCustomWidget/lookup/NamesForInquiry",
        "cdmsPluginCustomWidget/lookup/RequestForCancellation",
        "cdmsPluginCustomWidget/lookup/VariousSEC",
        "cdmsPluginCustomWidget/uploader/CDMSUploader"
        ], function(declare, json, BasePageWidget, _BaseWidget, onObj, query, DropDownMenu, 
        			pagenavigation, ComboBox, ICMUtil, Constants, lang, template, ButtonObj, 
        			_WidgetsInTemplateMixin, LoggerMixin, Deferred, all, Coordination, Util, CaseEditable,
        			ecmReq,lang,WFSearch, ItemFileWriteStore,Case,dom,NamesForInquiry,RequestForCancellation,
        			VariousSEC,CDMSUploader){
	
		glblUtil = Util;
		glblICMUtil = ICMUtil;
		glblall = all;
		glblLang = lang;
		glblECMRequest = ecmReq;
		glblDom = dom;
		glblNamesForInquiry = NamesForInquiry;
		glblItemFileWriteStore = ItemFileWriteStore;
		glblRqstCancel = RequestForCancellation;
		glblVariousSEC = VariousSEC;
		glblCDMSUploader=CDMSUploader;
		
	return declare("cdmsPluginCustomWidget.cdmsHome.CDMSHomeWidget", [_BaseWidget, BasePageWidget], {
		templateString: template,
		
		postCreate: function(){
			thisMainObj = this;
			solutionPrefix = this.solution.getPrefix();
			globalUserId = ecm.model.desktop.userId;
			glblUtil.getUserWorkflowStep(globalUserId,function(data){
				if(data!=undefined){
					var isLoandex=0;
					var isNFISCMAP=0;
					var isSEC=0;
					var isDTI=0;
					var isVSEC=0;
					var isVDTI=0;
					var isTV=0;
					var isExternal=0;
					iData = data;
					for(var i in data){
						strStepCode = data[i].stepCode;
						subWFCode = data[i].subWorkflowCode;
						if(data[i].subWorkflowCode=="CDMS_05_1003_01" && isLoandex==0){
							isLoandex=1;
							var loandexData = [];
							loandexData["stepCode"] = data[i].stepCode;
							loandexData["subWorkflowCode"] = data[i].subWorkflowCode;
							loandexData["mainPageId"] = data[i].mainPageId;
							loandexData["instructionId"] = data[i].wfInstructionId;
							document.getElementById("loandexInboxLink").style.display = "block";
							document.getElementById("myInboxLink").style.display = "block";
							onObj(this.loandexInbox, "click", function(evt){
								try{
									if(document.getElementById('DIVInstruction')==null){
										//TODO
										glblUtil.OpenWorkItemPage(thisMainObj,solutionPrefix,loandexData.mainPageId,loandexData);
									}else{
										glblUtil.alertMsg('The processor inbox need to be close before opening new inbox.');
									}
								}catch(e){
									alert(e);
								}
							});
						}else if(data[i].subWorkflowCode.toString()=="CDMS_05_1003_02" && isNFISCMAP==0){
							isNFISCMAP=1;
							var NFISData = [];
							NFISData["stepCode"] = data[i].stepCode;
							NFISData["subWorkflowCode"] = data[i].subWorkflowCode;
							NFISData["mainPageId"] = data[i].mainPageId;
							NFISData["instructionId"] = data[i].wfInstructionId;
							document.getElementById("nfisInboxLink").style.display = "block";
							document.getElementById("myInboxLink").style.display = "block";
							onObj(this.nfisInbox, "click", function(evt){
								try{
									if(document.getElementById('DIVInstruction')==null){
										glblUtil.OpenWorkItemPage(thisMainObj,solutionPrefix,NFISData.mainPageId,NFISData);
									}else{
										glblUtil.alertMsg('The processor inbox need to be close before opening new inbox.');
									}
								}catch(e){
									alert(e);
								}
							});
						}else if(data[i].subWorkflowCode=="CDMS_05_1003_03" && isSEC==0 && data[i].stepCode!="CDMS_01_2310_05"){
							isSEC=1;
							var SECData = [];
							SECData["stepCode"] = data[i].stepCode;
							SECData["subWorkflowCode"] = data[i].subWorkflowCode;
							SECData["mainPageId"] = data[i].mainPageId;
							SECData["instructionId"] = data[i].wfInstructionId;
							document.getElementById("secInboxLink").style.display = "block";
							document.getElementById("myInboxLink").style.display = "block";
							onObj(this.secInbox, "click", function(evt){
								try{
									if(document.getElementById('DIVInstruction')==null){
										glblUtil.OpenWorkItemPage(thisMainObj,solutionPrefix,SECData.mainPageId,SECData);
									}else{
										glblUtil.alertMsg('The processor inbox need to be close before opening new inbox.');
									}
								}catch(e){
									alert(e);
								}
							});
						}else if(data[i].subWorkflowCode=="CDMS_05_1003_04" && isDTI==0 && data[i].stepCode!="CDMS_01_2320_05"){
							isDTI=1;
							var DTIData = [];
							DTIData["stepCode"] = data[i].stepCode;
							DTIData["subWorkflowCode"] = data[i].subWorkflowCode;
							DTIData["mainPageId"] = data[i].mainPageId;
							DTIData["instructionId"] = data[i].wfInstructionId;
							document.getElementById("dtiInboxLink").style.display = "block";
							document.getElementById("myInboxLink").style.display = "block";
							onObj(this.dtiInbox, "click", function(evt){
								try{
									if(document.getElementById('DIVInstruction')==null){
										glblUtil.OpenWorkItemPage(thisMainObj,solutionPrefix,DTIData.mainPageId,DTIData);
									}else{
										glblUtil.alertMsg('The processor inbox need to be close before opening new inbox.');
									}
								}catch(e){
									alert(e);
								}
							});
						}else if(iData[i].subWorkflowCode=="CDMS_05_1003_03" && iData[i].stepCode=="CDMS_01_2310_05" && isVSEC==0){
							isVSEC=1;
							strSECStepCode=iData[i].stepCode;
							strSECSubWorkflow=iData[i].subWorkflowCode;
							document.getElementById("variousSECLink").style.display = "block";
							document.getElementById("publicInboxLink").style.display = "block";
						}else if(iData[i].subWorkflowCode=="CDMS_05_1003_04" && iData[i].stepCode=="CDMS_01_2320_05" && isVDTI==0){
							isVDTI=1;
							strDTIStepCode=iData[i].stepCode;
							strDTISubWorkflow=iData[i].subWorkflowCode;
							document.getElementById("variousDTILink").style.display = "block";
							document.getElementById("publicInboxLink").style.display = "block";
						}else if(data[i].subWorkflowCode=="CDMS_01_3200" && isExternal==0){
							isExternal=1;
							var externalData = [];
							externalData["stepCode"] = data[i].stepCode;
							externalData["subWorkflowCode"] = data[i].subWorkflowCode;
							externalData["mainPageId"] = data[i].mainPageId;
							externalData["instructionId"] = data[i].wfInstructionId;
							document.getElementById("externalInboxLink").style.display = "block";
							onObj(this.externalInbox, "click", function(evt){
								try{
									if(document.getElementById('DIVInstruction')==null){
										glblUtil.OpenWorkItemPage(thisMainObj,solutionPrefix,externalData.mainPageId,externalData);
									}else{
										glblUtil.alertMsg('The processor inbox need to be close before opening new inbox.');
									}
								}catch(e){
									alert(e);
								}
							});
						}else if(data[i].subWorkflowCode=="CDMS_01_3100" && isTV==0){
							isTV=1;
						var TVData = [];
						TVData["stepCode"] = data[i].stepCode;
						TVData["subWorkflowCode"] = data[i].subWorkflowCode;
						TVData["mainPageId"] = data[i].mainPageId;
						TVData["instructionId"] = data[i].wfInstructionId;
						document.getElementById("tvInboxLink").style.display = "block";
						onObj(this.tvInbox, "click", function(evt){
							try{
								if(document.getElementById('DIVInstruction')==null){
									glblUtil.OpenWorkItemPage(thisMainObj,solutionPrefix,TVData.mainPageId,TVData);
								}else{
									glblUtil.alertMsg('The processor inbox need to be close before opening new inbox.');
								}
							}catch(e){
								alert(e);
							}
						});
					}
						
					}
				}
			});

			
			onObj(this.cmdSECCIBI, "click", function(evt){
				glblUtil.processCIBI(solutionPrefix,"CDMS_01_2310_04",function(isDespatch){
					if(isDespatch==true){
						glblUtil.getInbox("gridInbox","",subWFCode,globalUserId,"","","","","","","","","","",50,1,0);
						glblUtil.alertMsg('Successfully process SEC to CIBI.');
					}else if(isDespatch==0){
						glblUtil.alertMsg('No pending workitem for CIBI..');
					}else{
						glblUtil.alertMsg('Error in processing workitem to CIBI..');
					}
				});
			});
			
			onObj(this.cmdDTICIBI, "click", function(evt){
				glblUtil.processCIBI(solutionPrefix,"CDMS_01_2320_04",function(isDespatch){
					if(isDespatch==true){
						glblUtil.alertMsg('Successfully process DTI to CIBI.');
					}else if(isDespatch==0){
						glblUtil.alertMsg('No pending workitem for CIBI..');
					}else{
						glblUtil.alertMsg('Error in processing workitem to CIBI..');
					}
				});
			});
			
			
			onObj(this.reviseCancelRqst, "click", function(evt){
				glblRqstCancel.cancelRqstPopUp(subWFCode,strStepCode,solutionPrefix);
			});
			
			onObj(this.variousSEC, "click", function(evt){
				var data = [];
				data["stepCode"] = strSECStepCode;
				data["UserName"] = globalUserId;
				data["SolutionPrefix"] = solutionPrefix;
				data["subWorkflowCode"] = strSECSubWorkflow;
				glblVariousSEC.VariousSECPopUp(data);
			});
			
			onObj(this.variousDTI, "click", function(evt){
				var data = [];
				data["stepCode"] = strDTIStepCode;
				data["UserName"] = globalUserId;
				data["SolutionPrefix"] = solutionPrefix;
				data["subWorkflowCode"] = strDTISubWorkflow;
				glblVariousSEC.VariousSECPopUp(data);
			});
			
			onObj(this.cmdOBFilter, "click", function(evt){
				publicInbox.filter(1);
			});
			
			onObj(this.cmdOBClear, "click", function(evt){
				publicInbox.clearSearchFields();
			});
			
			
			dojo.connect(dijit.byId("userInbox"),'selectChild',function(page){
				if(page.id.toString() == "cpProcessorInbox"){

				}else if(page.id.toString() == "cpOtherTask" && isOtherTask==0){
					isOtherTask=1;
					var isLoandex=0;
					var isNFIS=0;
					var isSEC=0;
					var cancelTab=0;
					console.log(iData);
					for(var i in iData){
						if(iData[i].subWorkflowCode=="CDMS_01_3300" && cancelTab==0){
							cancelTab=1;
							document.getElementById("reviseCancelRqstLink").style.display = "block";
						}else if(iData[i].subWorkflowCode=="CDMS_05_1003_01" && isLoandex==0){
							document.getElementById("reviseCancelRqstLink").style.display = "block";
						}else if(iData[i].subWorkflowCode=="CDMS_05_1003_02" && isNFIS==0){
							isNFIS=1;
							document.getElementById("reviseCancelRqstLink").style.display = "block";
						}else if(iData[i].subWorkflowCode=="CDMS_05_1003_03" && isSEC==0){
							isSEC=1;
							document.getElementById("processCIBIbnt").style.display = "block";
						}
					}
				}else if(page.id.toString() == "cpOutBox"){
					publicInbox.outBoxGrid();
					
				}
				
			});
			
			dojo.connect(dijit.byId,"tbLoandex",function(page){
				page.id.toString() == cpOutBox;
			
				
			});
			
			onObj(this.attachLoandex, "click", function(evt){
				alert("Loandex trigger");
				reqno = "General";
			    reqtype = "LOANDEX";
				glblCDMSUploader.onBatchUploadDocument(reqno,reqtype);
			});
			
			onObj(this.attachNFIS, "click", function(evt){
				reqno = "General";
			    reqtype = "NFIS";
				glblCDMSUploader.onBatchUploadDocument(reqno,reqtype);
			});
			
			onObj(this.attachSECDTI, "click", function(evt){
				reqno = "General";
			    reqtype = "SEC-DTI";
				glblCDMSUploader.onBatchUploadDocument(reqno,reqtype);
			});
			
			onObj(this.viewNameListLoandex, "click", function(evt){
				glblNamesForInquiry.NamesInquiryPopUp("Loandex");
			});
			
			onObj(this.viewNameListNFIS, "click", function(evt){
				glblNamesForInquiry.NamesInquiryPopUp("NFIS");
			});
			
			
			
			
		},
		handleICM_PageOpenedEvent: function(payload) {
			
			if(payload!=undefined){
				glblUtil.getInstruction("20191126000008","publicInboxInst");
				dojo.connect(dijit.byId("userInbox"),'selectChild',function(page){
					if(page.id.toString() == "cpOtherTask" && isOtherTask==0){
						isOtherTask=1;
						glblUtil.getInstruction("20191126000008","processCIBIInst");
					}else if(page.id.toString() == "cpOutBox" && isOutBox==0){
						isOutBox=1;
						glblUtil.getInstruction("20191126000008","outBoxInst");
					}
				});
			}

		},
		handleICM_SendWorkItemEvent: function(payload) {
			
		}
	
	});
});

var publicInbox = {
		
		outBoxGrid:function(){
			//storeAction=store;
			var layout = [{ field: "no", width: '15px', name: "No",styles: 'text-align: center;' },
			
				{ field: "requestNo", width: '90px', name: "Request No",styles: 'cursor: pointer; text-align: center;',
				cellStyles: 'text-decoration: underline; color: blue;'},
				{ field: "customerName", width: '220%',cellStyles:'text-align: left;', name: "Customer Name",styles: 'text-align: center;'},
				{ field: "nameVerified", width: '220px', name: "Name Verified",styles: 'text-align: center;'},
				{ field: "status", width: '100px', name: "Status",styles: 'text-align: center;'},
				{ field: "requestDate", width: '100px', name: "Request Date",styles: 'text-align: center;'},
				{ field: "dateReceive", width: '100px', name: "Date Receive",styles: 'text-align: center;cursor: pointer;text-align: center;',},
				{ field: "history", width: '7%', name: "History",styles:'text-align:center;cursor:pointer;',
						formatter:cmdHistory}
				];
			if(dijit.byId("OutBoxGrid") == null || grid == undefined || grid =="") {
				glblUtil.createDataGrid("OutBoxGrid","divForOutBoxGrid", layout, null);
				glblUtil.getOutBox("OutBoxGrid",globalUserId,"CDMS_01_2100_01","","","","","","","","","","",1,50,0);
				grid = dijit.byId("OutBoxGrid");
				publicInbox.setPaginationObject("OB","OutBoxGrid");
			}
			grid.update();
			grid._refresh();
			dojo.connect( window, "onresize", function(){
				grid.attr("width", '100%');
				grid.resize();
				grid.update();
			});
			grid.set("singleClickEdit",true);
			dojo.connect(grid,'onCellFocus',function(a,row){
				globalRow1 = row;
			});
			this.GridcellClick(namesInfo,strRequestNo,userid,strNameVerified,strRqstStats,strRqstOfficerName,strDateRcvd);
			
		},
		filter:function(intIsFilterd){
				var strWorkflowNo = dijit.byId("txtOBWorkflowNo").get('value');
				var strRequestUnit = dijit.byId("txtOBRqstUnit").get('value');
				var strRequestNo = dijit.byId("txtOBRqstNo").get('value');
				var strRequestOfficer = dijit.byId("txtOBRqstOfficer").get('value');
				var strCustomerName = dijit.byId("txtOBCustName").get('value');
				var strRequestDateFrm = glblUtil.formatDate(dijit.byId("textOBRqstDateFrm").get('value'));
				var strRequestDateTo = glblUtil.formatDate(dijit.byId("txtOBRqstDateto").get('value'));
				var strStatus = dijit.byId("txtOBStatus").get('value');
				var strDateRcvFrm = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqFrm").get('value'));
				var strDaterecvTo = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqTo").get('value'));
				
				if(strWorkflowNo=="" && strRequestUnit==""  && strRequestNo=="" && strRequestOfficer=="" && strCustomerName=="" && strStatus==""
					&& strRequestDateFrm==""&& strRequestDateTo==""&& strDateRcvFrm==""&& strDaterecvTo==""){
					alert("Please input data in the available criteria.");
				}else {
					if(strRequestDateFrm!="" && strRequestDateTo==""){
						alert("This range of dates is not valid From:"+strRequestDateFrm+" To:");
					}else if(strRequestDateTo!="" && strRequestDateFrm==""){
						alert("This range of dates is not valid From: To:"+strtxtRqstDateto);
					}else if(strDateRcvFrm!="" && strDaterecvTo==""){
						alert("This range of dates is not valid From:"+strDateRcvFrm+" To:");
					}else if(strDaterecvTo!="" && strDateRcvFrm==""){
						alert("This range of dates is not valid From: To:"+strDaterecvTo);
					}else{
						 glblUtil.getOutBox("OutBoxGrid",globalUserId,"CDMS_01_2100_01",strWorkflowNo,strRequestUnit,strRequestNo,strRequestOfficer,
								 strCustomerName,strRequestDateFrm,strRequestDateTo,strStatus,strDateRcvFrm,strDaterecvTo,
								 1, 50, 1);
					}
				}
				
			},
			clearSearchFields:function(strGridId,callback){
				dijit.byId("txtOBWorkflowNo").set('value','');
				dijit.byId("txtOBRqstUnit").set('value','');
				dijit.byId("txtOBRqstNo").set('value','');
				dijit.byId("txtOBRqstOfficer").set('value','');
				dijit.byId("txtOBCustName").set('value','');
				dojo.byId("textOBRqstDateFrm").value = "";
				dojo.byId("txtOBRqstDateto").value = "";
				dijit.byId("txtOBStatus").set('value','');
				dojo.byId("txtOBDateRecvReqFrm").value = "";
				dojo.byId("txtOBDateRecvReqTo").value = "";
//				dojo.byId('resultSize'+strGridId).value = "50";
//				dojo.byId('currentPage'+strGridId).value = "1";
//				callback(1);
			},
			setPaginationObject:function(glblTabId,gridId){
				dojo.connect(dojo.byId("resultSize"+glblTabId),'onchange',function(){
					rs = dojo.byId("resultSize"+glblTabId).value;
					if(rs!=""){
						dojo.byId("currentPage"+glblTabId).value = 1;
						var strWorkflowNo = dijit.byId("txtOBWorkflowNo").get('value');
						var strRequestUnit = dijit.byId("txtOBRqstUnit").get('value');
						var strRequestNo = dijit.byId("txtOBRqstNo").get('value');
						var strRequestOfficer = dijit.byId("txtOBRqstOfficer").get('value');
						var strCustomerName = dijit.byId("txtOBCustName").get('value');
						var strRequestDateFrm = glblUtil.formatDate(dijit.byId("textOBRqstDateFrm").get('value'));
						var strRequestDateTo = glblUtil.formatDate(dijit.byId("txtOBRqstDateto").get('value'));
						var strStatus = dijit.byId("txtOBStatus").get('value');
						var strDateRcvFrm = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqFrm").get('value'));
						var strDaterecvTo = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqTo").get('value'));
//						var strSuggestedStatus = dijit.byId("cbStatus").get('value');
						var strResultSize = dojo.byId('resultSize'+glblTabId).value;
						var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
						glblUtil.getOutBox(gridId,globalUserId,"CDMS_01_2100_01",strWorkflowNo,strRequestUnit,strRequestNo,strRequestOfficer,
								 strCustomerName,strRequestDateFrm,strRequestDateTo,strStatus,strDateRcvFrm,strDaterecvTo,
								 strCurrentPage, strResultSize, 1);
					}
				});
				
				dojo.connect(dojo.byId("nextPage"+glblTabId),'onclick',function(){
					var rs = dojo.byId("resultSize"+glblTabId).value;
					var currentPage = Number(dojo.byId("currentPage"+glblTabId).value);
					var totalPage 	= dojo.byId("totalPages"+glblTabId).innerHTML;

					if (currentPage <= totalPage && currentPage < totalPage){
						currentPage += 1;
						dojo.byId("currentPage"+glblTabId).value = currentPage;
						var strWorkflowNo = dijit.byId("txtOBWorkflowNo").get('value');
						var strRequestUnit = dijit.byId("txtOBRqstUnit").get('value');
						var strRequestNo = dijit.byId("txtOBRqstNo").get('value');
						var strRequestOfficer = dijit.byId("txtOBRqstOfficer").get('value');
						var strCustomerName = dijit.byId("txtOBCustName").get('value');
						var strRequestDateFrm = glblUtil.formatDate(dijit.byId("textOBRqstDateFrm").get('value'));
						var strRequestDateTo = glblUtil.formatDate(dijit.byId("txtOBRqstDateto").get('value'));
						var strStatus = dijit.byId("txtOBStatus").get('value');
						var strDateRcvFrm = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqFrm").get('value'));
						var strDaterecvTo = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqTo").get('value'));
//						var strSuggestedStatus = dijit.byId("cbStatus").get('value');
						var strResultSize = dojo.byId('resultSize'+glblTabId).value;
						var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
						glblUtil.getOutBox(gridId,globalUserId,"CDMS_01_2100_01",strWorkflowNo,strRequestUnit,strRequestNo,strRequestOfficer,
								 strCustomerName,strRequestDateFrm,strRequestDateTo,strStatus,strDateRcvFrm,strDaterecvTo,
								 strCurrentPage, strResultSize, 1);
					}
				});
				
				dojo.connect(dojo.byId("prevPage"+glblTabId),'onclick',function(){
					var rs = dojo.byId("resultSize"+glblTabId).value;
					var currentPage = Number(dojo.byId("currentPage"+glblTabId).value);
					var totalPage 	= dojo.byId("totalPages"+glblTabId).innerHTML;

					if (currentPage <= totalPage && currentPage != 1){
						currentPage -= 1;
						dojo.byId("currentPage"+glblTabId).value = currentPage;
						var strWorkflowNo = dijit.byId("txtOBWorkflowNo").get('value');
						var strRequestUnit = dijit.byId("txtOBRqstUnit").get('value');
						var strRequestNo = dijit.byId("txtOBRqstNo").get('value');
						var strRequestOfficer = dijit.byId("txtOBRqstOfficer").get('value');
						var strCustomerName = dijit.byId("txtOBCustName").get('value');
						var strRequestDateFrm = glblUtil.formatDate(dijit.byId("textOBRqstDateFrm").get('value'));
						var strRequestDateTo = glblUtil.formatDate(dijit.byId("txtOBRqstDateto").get('value'));
						var strStatus = dijit.byId("txtOBStatus").get('value');
						var strDateRcvFrm = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqFrm").get('value'));
						var strDaterecvTo = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqTo").get('value'));
//						var strSuggestedStatus = dijit.byId("cbStatus").get('value');
						var strResultSize = dojo.byId('resultSize'+glblTabId).value;
						var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
						glblUtil.getOutBox(gridId,globalUserId,"CDMS_01_2100_01",strWorkflowNo,strRequestUnit,strRequestNo,strRequestOfficer,
								 strCustomerName,strRequestDateFrm,strRequestDateTo,strStatus,strDateRcvFrm,strDaterecvTo,
								 strCurrentPage, strResultSize, 1);
					}
				});
				
				dojo.connect(dojo.byId("gotoPage"+glblTabId),'onclick',function(){
					var rs = dojo.byId("resultSize"+glblTabId).value;
					var currentPage = Number(dojo.byId("currentPage"+glblTabId).value);
					if(currentPage != ""){
						var strWorkflowNo = dijit.byId("txtOBWorkflowNo").get('value');
						var strRequestUnit = dijit.byId("txtOBRqstUnit").get('value');
						var strRequestNo = dijit.byId("txtOBRqstNo").get('value');
						var strRequestOfficer = dijit.byId("txtOBRqstOfficer").get('value');
						var strCustomerName = dijit.byId("txtOBCustName").get('value');
						var strRequestDateFrm = glblUtil.formatDate(dijit.byId("textOBRqstDateFrm").get('value'));
						var strRequestDateTo = glblUtil.formatDate(dijit.byId("txtOBRqstDateto").get('value'));
						var strStatus = dijit.byId("txtOBStatus").get('value');
						var strDateRcvFrm = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqFrm").get('value'));
						var strDaterecvTo = glblUtil.formatDate(dijit.byId("txtOBDateRecvReqTo").get('value'));
//						var strSuggestedStatus = dijit.byId("cbStatus").get('value');
						var strResultSize = dojo.byId('resultSize'+glblTabId).value;
						var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
						glblUtil.getOutBox(gridId,globalUserId,"CDMS_01_2100_01",strWorkflowNo,strRequestUnit,strRequestNo,strRequestOfficer,
								 strCustomerName,strRequestDateFrm,strRequestDateTo,strStatus,strDateRcvFrm,strDaterecvTo,
								 strCurrentPage, strResultSize, 1);
					}else{
		        		dijit.byId("currentPage"+glblTabId).set('value',1);
					}
				}); 
			},
			GridcellClick:function(namesInfo,strRequestNo,userid,strNameVerified,strRqstStats,strRqstOfficerName,strDateRcvd){
				grid.on("CellClick", function(evt){
					var strRequestNo = item.requestNo.toString();
					
					if(evt.cellIndex == 7){
						alert("strRequestNo >>"+ strRequestNo);

						globalRqstTypeHist.RqstTypeHistPopUp();
						}
				});
			}
		
		
};

