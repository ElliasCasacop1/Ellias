var glblUtil;
var glblDom;
var glblTabContainer;
var glblContentPane;
var glblBorderContainer;
var glblICMUtil;
var glblDataGrid;
var glblall;
var glblLang;
var glblECMRequest;
var glblAttr;
var glblItemFileWriteStore;
var globalUserId;
var glblRqstType = "LOANDEX";
var strStepCode="";
var glblWorkflowInstId;
var glblRemarks;
var gridId = "confirmationGrid";
var cancelRqst = "<div class='cancelRqstIcon'></div>";
var cancelRqstNo="";
var glblTabId="tabForStatusConfirmation";
var cancelRqstIcon = function(val) {
	var rt = "";
	if(val!=""){
		rt = cancelRqst;
	}else{
		rt = "";
	}
	return rt;
};
var rqstNoMerge = function(val){

	return val; 
};
var addressNV = "<div class='addressIcon'></div>";
var addressIcon = function(val) {addressNV;return addressNV;};
var check = "<div class='checkIcon'></div>";
var changeIcon = function(val){
	 var rt = "";
	if(val != 0){
			rt = check;
	}else{
		rt = "&nbsp;";
	}
	 return rt;
};
var glblRqstType = "LOANDEX";
var PageLimit = 50;
var PageNum = 1;
var strIsFiltered = 0;
var solutionPrefix;
var glblViewRequestDetails;
var tooltip = "<span id='divTooltip' class='tooltiptext'></span>";
var getTooltip = function(val) {tooltip;return tooltip;};


define([
        "dojo/_base/declare",
        "dojo/json",
        "icm/base/BasePageWidget",
        "icm/base/_BaseWidget",
        "dojo/on",
        "dojo/query",
        "cdmsPluginCustomWidget/util/DropDownMenu",
        "cdmsPluginCustomWidget/util/pagenavigation",
        "dijit/form/ComboBox",
        "cdmsPluginCustomWidget/util/ICMUtil",
        "icm/base/Constants",
        "dojo/_base/lang",
        "dojo/text!./templates/ForStatusConfirmation.html",
        "dijit/form/Button",
        "dijit/_WidgetsInTemplateMixin",
        "ecm/LoggerMixin",
        "dojo/Deferred","dojo/promise/all",
        "icm/util/Coordination",
        "cdmsPluginCustomWidget/util/Util",
        "icm/model/CaseEditable",
        "ecm/model/Request",
        "dojo/_base/lang",
        "cdmsPluginCustomWidget/lookup/WFSearch",
        "dojo/data/ItemFileWriteStore",
        "icm/model/Case",
        "dojo/dom",
        "cdmsPluginCustomWidget/lookup/Remarks",
        "cdmsPluginCustomWidget/lookup/ViewRequestDetails",
        "dijit/Tooltip"
        ], function(declare, json, BasePageWidget, _BaseWidget, onObj, query, DropDownMenu, 
        			pagenavigation, ComboBox, ICMUtil, Constants, lang, template, ButtonObj, 
        			_WidgetsInTemplateMixin, LoggerMixin, Deferred, all, Coordination, Util, CaseEditable,
        			ecmReq,lang,WFSearch, ItemFileWriteStore,Case,dom,Remarks,ViewRequestDetails,Tooltip){
	
		glblUtil = Util;
		glblICMUtil = ICMUtil;
		glblall = all;
		glblLang = lang;
		glblECMRequest = ecmReq;
		glblDom = dom;
		glblRemarks=Remarks;
		glblViewRequestDetails = ViewRequestDetails;
		glblTooltip = Tooltip;
		
	return declare("cdmsPluginCustomWidget.confirmTaggedStatus.ForStatusConfirmationWidget", [_BaseWidget, BasePageWidget], {
		templateString: template,
		
		postCreate: function(){
			globalUserId = ecm.model.desktop.userId;
			solutionPrefix = this.solution.getPrefix();
//			if(globalUserId == "DMSAO07"){
//				glblRqstType = "LOANDEX";
//				strStepCode="1";
//			}else{
//				glblRqstType = "LOANDEX";
//				strStepCode="1";
//			}
		},
		handleICM_PageOpenedEvent: function(payload) {
			if(payload.wfData != undefined){
				var wfData = payload.wfData;
				if(wfData.stepCode!=undefined){
					strStepCode = wfData.stepCode;
					if(strStepCode=="CDMS_01_2100_02"){
						dijit.byId('txtStepCode').set('value',strStepCode);
						dijit.byId('txtTabId').set('value',glblTabId);
						forStatusConfirmation.gridLayout();
						document.getElementById("userActionContent").style.display = "none";
						document.getElementById("userActionHeader").style.color = "#3d6392";
						document.getElementById("workflowContent1").style.display = "none";
//						var grid = dijit.byId("confirmationGrid");
					}
					
				}
				
//				dojo.connect(dojo.byId("resultSize"),'onchange',function(){
//					rs = dojo.byId('resultSize').value;
//					grid.store = null;
//					grid._refresh();
//					grid.rowCount=rs;
////					glblUtil.getForLoandexProcessing(gridId,glblRqstType,strStepCode,globalUserId,"","","","","","","","","",rs,PageNum,strIsFiltered);
//				});
				
//				dojo.connect(dojo.byId('nextPage'),'onclick',function(){
//					var rs = dojo.byId('resultSize').value;
//					var currentPage = Number(dojo.byId('currentPage').value);
//					var totalPage 	= dojo.byId('totalPages').innerHTML;
//
//					if (currentPage <= totalPage && currentPage < totalPage){
//						currentPage += 1;
//						dojo.byId('currentPage').value = currentPage;
//						PageNum = currentPage;
//						grid.store = null;
//						grid._refresh();
//						glblUtil.getForLoandexProcessing(gridId,glblRqstType,strStepCode,globalUserId,"","","","","","","","","",rs,PageNum,strIsFiltered);
//					}
//				});
//				
//				dojo.connect(dojo.byId('prevPage'),'onclick',function(){
//					var rs = dojo.byId('resultSize').value;
//					var currentPage = Number(dojo.byId('currentPage').value);
//					var totalPage 	= dojo.byId('totalPages').innerHTML;
//
//					if (currentPage <= totalPage && currentPage != 1){
//						currentPage -= 1;
//						dojo.byId('currentPage').value = currentPage;
//						PageNum = currentPage;
//						grid.store = null;
//						grid._refresh();
//						glblUtil.getForLoandexProcessing(gridId,glblRqstType,strStepCode,globalUserId,"","","","","","","","","",rs,PageNum,strIsFiltered);
//					}
//				});
//				
//				dojo.connect(dojo.byId("gotoPage"),'onclick',function(){
//					var rs = dojo.byId('resultSize').value;
//					var currentPage = Number(dojo.byId('currentPage').value);
//					PageNum = currentPage;
//					grid.store = null;
//					grid._refresh();
//					glblUtil.getForLoandexProcessing(gridId,glblRqstType,strStepCode,globalUserId,"","","","","","","","","",rs,PageNum,strIsFiltered);
//				}); 
			}
//			document.getElementById("tabForStatusConfirmation").style.width = glblUtil.getWidth();
//			document.getElementById("tbLoandex").style.width = glblUtil.getWidth();
			
		},
		handleICM_SendWorkItemEvent: function(payload) {
			
		}
		
	});
	
});

var forStatusConfirmation = {
	gridLayout : function(){
			var layout = [{ field: "no", width: '15%', name: "No",styles: 'text-align: center;' },
			    { field: "requestNo", width: '65%', name: "Request No",styles: 'cursor: pointer; text-align: center;',
				cellStyles: 'text-decoration: underline; color: blue;',formatter:rqstNoMerge},
				{ field: "btnCancel",width: '14%',name: '&nbsp;',styles:'align:center;',formatter:cancelRqstIcon},
				{ field: "NameVerified", width: '100%',cellStyles:'text-align: left;', name: "Name Verified",styles: 'text-align: center;'},
				{ field: "Address", width: '65%', name: "Address",styles: 'text-align: center;',cellStyles: 'text-align: left;text-decoration: underline; color: blue;'},
				{ field: "lastReportDate", width: '60%', name: "Last Report Date",styles: 'text-align: center;'},
				{ field: "lastRequestDate", width: '60%', name: "Last Request Date",styles: 'text-align: center;'},
				{ field: "taggedStatus", width: '80%', name: "Tagged Status",styles: 'text-align: center;cursor: pointer;text-align: center;',
					formatter:function(data, inRow){
						console.log(inRow);
     					return data;
     			    }},
				{ field: "remarksToProcessor", width:'70%', name:"Remarks from Processor",styles: 'text-align: center;'},
				{ field: "remarksFromReviewer", width:'70%', name:"Remarks to Processor",styles: 'text-align: center;',editable:true},
				{ field: "confirm", width:'35%', name:"Confirm",styles:'text-align:center;',cellStyles:'text-align:center;',formatter:changeIcon},
				{ field: "reject", width:'35%', name:"Reject",styles:'text-align:center;',cellStyles:'text-align:center;',formatter:changeIcon}];
				
				if(dijit.byId("confirmationGrid") == null || grid == undefined || grid =="") {
					glblUtil.createDataGrid("confirmationGrid","divForStatusConfirmationGrid", layout, null);
					glblUtil.getForLoandexProcessing(glblTabId,gridId,"LOANDEX",strStepCode,globalUserId,"","","","","","","","","",PageLimit,PageNum,strIsFiltered);	
					forStatusConfirmation.setPaginationObject(glblTabId,"confirmationGrid");
				}
				grid = dijit.byId("confirmationGrid");
				grid.update();
				grid._refresh();
				dojo.connect( window, "onresize", function(){
					grid.attr("width", '100%');
					grid.resize();
					grid.update();
				});

				grid.set("singleClickEdit",true);
				grid.set("canSort",false);
				
				forStatusConfirmation.cellClick(strStepCode);
				forStatusConfirmation.tooltip(grid);
				
		},
		cellClick:function(strStepCode){
			grid = dijit.byId("confirmationGrid");
			grid.on("CellClick", function(evt){
				var userid = globalUserId;
				var row = evt.rowIndex;
				var ttl = grid.rowCount;
				var index = grid.selection.selectedIndex;
				var item = grid.getItem(index);
				var namesInfo = [];
//				if(evt.cellIndex == 1){
//				var strRequestNo = grid.store.getValue(item,'requestNo');
//				if(strRequestNo!=""){
////					alert("cell index 1 ");
////					namesInfo["strRequestNo"]=item.requestNo;
////					namesInfo["strNameVerified"]=item.NameVerified;
////					namesInfo["strRqstStats"]=item.RqstStats;
////					namesInfo["strRqstOfficerName"]=item.requestingOfficer;
////					namesInfo["strDateRcvd"]=item.dateReceived;
////					namesInfo["strWFTrackNo"]=item.wfNo;
////					var strWfNo = item.wfNo;
//							glblViewRequestDetails.RequestDetailsPopUp("");
////							glblUtil.setCIMInternalLogSaveComp(userid, strWfNo , 2, strStepCode,"", 0, 
////									strRequestNo, "", "","",function(isLogged){
////					});
//				}else 
					if(evt.cellIndex == 2){
					alert("cell index 2");
					var strRequestNo = grid.store.getValue(item,'requestNo');
					namesInfo["strWFTrackNo"]=item.wfNo;
					var strWfNo = item.wfNo;
					if(strRequestNo!=""){
						glblRemarks.remarksPopUp(function(remarks){
//							glblUtil.setCIMInternalLogSaveComp(userid, strWfNo, 2, strStepCode,"", 0, 
//									strRequestNo, "", "","",function(isLogged){});
							if(remarks!=false){
								grid.store.fetch({
									onComplete:function(items){
										for(var x = 0; items.length > x ;x++){
											if(strRequestNo==grid.store.getValue(items[x],'requestNo')){
												var strWobNum = items[x].objectId.toString();
												glblUtil.setCancelRequest(strWobNum,remarks,strStepCode,"Cancel Name",globalUserId,solutionPrefix,function(isSaved){
													if(isSaved!=true){
														alert("error in cancellation.");
													}
												});
												grid.store.deleteItem(items[x]);
												grid.store.save();
											}
											dojo.byId("totalRecords").innerHTML = document.getElementById('totalRecords').innerHTML-items.length;
										}
									}
								});
							}
						});
					}
				}else if(evt.cellIndex == 10){
					grid.store.setValue(item, "confirm",1);
					grid.store.setValue(item, "reject",0);
					grid.store.setValue(item, "nextStepCode","CDMS_01_2100_04");
					grid.store.save();
//					glblUtil.validateWorkItem(grid,function(validated){
//						if(validated==true){
////							glblUtil.getWorkflowResponse();
//						}
//					});
				}else if(evt.cellIndex == 11){
					grid.store.setValue(item, "reject",1);
					grid.store.setValue(item, "confirm",0);
					grid.store.setValue(item, "nextStepCode","CDMS_01_2100_03");
					grid.store.save();
//					glblUtil.validateWorkItem(grid,function(validated){
//						if(validated==true){
//							glblUtil.getWorkflowResponse();
//						}
//					});
				}else if(evt.cellIndex == 4){
					console.log("dijit__MasterTooltip_0");
					document.getElementById("dijit__MasterTooltip_0").style.display = "none";
					glblUtil.getAddressAlert(item.fullAddress.toString());
				}else if(evt.cellIndex == 7){
					var strSuggestedVSID = item.suggestedVSID.toString();
					var strTaggedStatus = item.taggedStatus.toString();
					if(strTaggedStatus!="For Inquiry to Loandex"){
						if(strSuggestedVSID!=""){
							glblUtil.onViewDocumentsXT(strSuggestedVSID,"","");
						}
					}
					
				 }
//				}
			});
		},
		tooltip:function(grid){
			try{
				dojo.connect(grid, "onCellMouseOver", showTooltip);
				dojo.connect(grid, "onCellMouseOut", function(e){
					dijit.hideTooltip(e.cellNode);  
				});
				
				function showTooltip(e) {
					 enabled: true;
					 try{
						 if (grid.getCell(e.cellIndex).field == 'Address') {
							 var value = grid.store.getValue(grid.getItem(e.rowIndex),'fullAddress');
							 dijit.showTooltip(value, e.cellNode);
						 }
					 }catch(e){
						 console.log(e);
					 }
					
				}
				function hideTooltip(e) {
					console.log(e);
					 dijit.hideTooltip(e.cellNode);  
				}
			}catch(err){
				
			}
		},
		setPaginationObject:function(glblTabId,gridId){
			dojo.connect(dojo.byId("resultSize"+glblTabId),'onchange',function(){
				rs = dojo.byId("resultSize"+glblTabId).value;
				if(rs!=""){
					dojo.byId("currentPage"+glblTabId).value = 1;
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+glblTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
					glblUtil.getForLoandexProcessing(glblTabId,gridId,glblRqstType,"","",strRequestNo,
							"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
							strSuggestedStatus,strResultSize,strCurrentPage,1);
					
				}
			});
			
			dojo.connect(dojo.byId("nextPage"+glblTabId),'onclick',function(){
				var rs = dojo.byId("resultSize"+glblTabId).value;
				var currentPage = Number(dojo.byId("currentPage"+glblTabId).value);
				var totalPage 	= dojo.byId("totalPages"+glblTabId).innerHTML;

				if (currentPage <= totalPage && currentPage < totalPage){
					currentPage += 1;
					dojo.byId("currentPage"+glblTabId).value = currentPage;
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+glblTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
					glblUtil.getForLoandexProcessing(glblTabId,gridId,glblRqstType,"","",strRequestNo,
							"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
							strSuggestedStatus,strResultSize,strCurrentPage,1);
				}
			});
			
			dojo.connect(dojo.byId("prevPage"+glblTabId),'onclick',function(){
				var rs = dojo.byId("resultSize"+glblTabId).value;
				var currentPage = Number(dojo.byId("currentPage"+glblTabId).value);
				var totalPage 	= dojo.byId("totalPages"+glblTabId).innerHTML;

				if (currentPage <= totalPage && currentPage != 1){
					currentPage -= 1;
					dojo.byId("currentPage"+glblTabId).value = currentPage;
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+glblTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
					glblUtil.getForLoandexProcessing(glblTabId,gridId,glblRqstType,"","",strRequestNo,
							"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
							strSuggestedStatus,strResultSize,strCurrentPage,1);
				}
			});
			
			dojo.connect(dojo.byId("gotoPage"+glblTabId),'onclick',function(){
				var rs = dojo.byId("resultSize"+glblTabId).value;
				var currentPage = Number(dojo.byId("currentPage"+glblTabId).value);
				if(currentPage != ""){
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+glblTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+glblTabId).value);
					glblUtil.getForLoandexProcessing(glblTabId,gridId,glblRqstType,"","",strRequestNo,
							"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
							strSuggestedStatus,strResultSize,strCurrentPage,1);
				}else{
	        		dijit.byId("currentPage"+glblTabId).set('value',1);
				}
			}); 
		},
};

