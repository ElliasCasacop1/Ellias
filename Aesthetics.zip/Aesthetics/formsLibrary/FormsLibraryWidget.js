var snode="";
var glblQuery;
var glblDDMenu;
var glblPageNavi;
var myFormListGrid;
var globalPayload;
var globalToday;
var workFlowStore;
var workFlow = [];
var globalItemFileWriteStore;
var globalCaseEditable = null;
var globalCoordination = null;
var globalSendNewCaseEditablePayload = null;
var txtCusName;
var txtWrkFlwNo;
var txtWrkFlwNoVal;
var txtCusNameVal;
var strStepId;
var glblStatus;
var glblWorkflowNo;
var glblRequestNo;
var dataStore = null;

var glblWorkFlowId;
var glblWorkFlowCode;
var glblModule;
var glblReportUrl = "http://"+location.host+"/CDMSCISMEXTWidgets/CDMSCISMEXTWidgets/reportsrepository/localreportdestination/";

var workflowTypeStore = [];
var icmContextRoot = "/CDMS_MyWorkplaceWidgets";
var paths = {
		"cdmsPluginCustomWidget": icmContextRoot + "/cdmsPluginCustomWidget"
};
var globalICMUtil;
var wfDetailsPayload = {};
var globalSendNewCaseEditablePayload;
var solutionPrefix = "";
var reqPayload = {};
var propPayload = {};
var thisMainObj;
var solution; 
var repositoryId; 
var glblCoordination;
var glblUtil;
var glblCaseEditable;
var globalUserId;
var globalWorkFlowNo;
var globalECMRequest;
var globalLang;
var globalWFSearch;
var globalSol;
var glblAddFromLocal;
var cbStore;
var workflowData = [];

define([
        "dojo/_base/declare",
        "dojo/json",
        "icm/base/BasePageWidget",
        "icm/base/_BaseWidget",
        "dojo/on",
        "dojo/query",
        "cdmsPluginCustomWidget/util/DropDownMenu",
        "cdmsPluginCustomWidget/util/pagenavigation",
        "dijit/form/ComboBox",
        "cdmsPluginCustomWidget/util/ICMUtil",
        "icm/base/Constants",
        "dojo/_base/lang",
        "dojo/text!./templates/FormsLibrary.html",
        "dijit/form/Button",
        "dijit/_WidgetsInTemplateMixin",
        "ecm/LoggerMixin",
        "dojo/Deferred","dojo/promise/all",
        "icm/util/Coordination",
        "cdmsPluginCustomWidget/util/Util",
        "icm/model/CaseEditable",
        "icm/model/Solution",
        "icm/action/AddFromLocal",
        "ecm/model/Request",
        "dojo/_base/lang",
        "cdmsPluginCustomWidget/lookup/WFSearch",
        "dojo/data/ItemFileWriteStore",
        "icm/model/Case"
        ], function(declare, json, BasePageWidget, _BaseWidget, onObj, query, DropDownMenu, 
        			pagenavigation, ComboBox, ICMUtil, Constants, lang, template, ButtonObj, 
        			_WidgetsInTemplateMixin, LoggerMixin, Deferred, all, Coordination, Util, CaseEditable,
        			Solution,AddFromLocal,ecmReq,lang,WFSearch, ItemFileWriteStore,Case){
	return declare("cdmsPluginCustomWidget.formsLibrary.FormsLibraryWidget", [_BaseWidget, BasePageWidget], {
		templateString: template,
		
//		createCDMSCase : function(strRqstNo,strWorkflowNo,callback) {
//			try{
//				CaseEditable = globalSol.createNewCaseEditable(solutionPrefix +"_InternalLaunchRequest",
//					globalLang.hitch(thisMainObj, function(CaseEditable) {
//						var newCaseRequest = CaseEditable.propertiesCollection[solutionPrefix + "_RequestNumber"];
//						newCaseRequest.setValue(strRqstNo);
//						CaseEditable.save(globalLang.hitch(thisMainObj, 
//							function _newCaseSaveComplete(CaseEditable) {
//							var caseObj = CaseEditable.caseObject;
//							var caseIdentifier = caseObj.caseIdentifier;
//							if(caseIdentifier!=null||caseIdentifier!==""){
//								callback(caseObj.id);
//							}else{
//								callback(0);
//							}
//						}));
//					}));
//			}catch(err){
//				alert(err);
//				callback(0);
//			}
//		},
		postCreate: function(){
			glblUtil = Util;
			globalSol = this.solution;
			globalCaseEditable = CaseEditable;
			glblAddFromLocal = AddFromLocal;
			globalUserId = ecm.model.desktop.userId;
//			glblUtil.getCDMSScreenDetails(globalUserId,1,"instructionContent1",function(screenInfo){
//				
//			});
			getTodate();
			glblQuery = query;
			glblDDMenu = DropDownMenu;
			glblPageNavi = pagenavigation;
			globalICMUtil = ICMUtil;
			solutionPrefix = this.solution.getPrefix();
//			alert(solutionPrefix);
			thisMainObj = this;
			solution = this.getSolution(); 
			repositoryId = solution.getTargetOS().id; 
			glblCoordination = Coordination;
			
			glblCaseEditable = CaseEditable;
			globalECMRequest = ecmReq;
			globalLang = lang;
			globalWFSearch = WFSearch;
			globalItemFileWriteStore = ItemFileWriteStore;
			
			onObj(this.btnInitSubMenu, "click", function(evt){
				glblDDMenu.initSubMenu(this);
			});
			onObj(this.cmdSearch, "click", function(evt){
				var workflowType = dijit.byId('workflowType');
				if(workflowType.getValue()!= ""){
					var strWFNo = dijit.byId('txtWrkFlwNo').getValue();
					var strCustName = dijit.byId('txtCusName').getValue();
					if(strWFNo != "" || strCustName != ""){
						var wfID = workflowType.item.strWFID;
						var strWFModId = workflowType.item.strWFModId;
						var userid = globalUserId;
						if(wfID.toString() != ""){
							formsLibrary.getWorkFlow(strCustName, strWFNo, userid, wfID, strWFModId);
						}
					}else{
						glblUtil.alertMsg('Please input Customer Name or Workflow Number.');
					}
				}else{
					glblUtil.alertMsg('Please select Workflow type.');
				}
				
				
			});
			onObj(this.cmdWrkFlw, "click", function(evt){
				var workflowType = dijit.byId('workflowType');
				if(workflowType.getValue()!= ""){
				var wfid = workflowType.item.strWFID;
				var wfcode = workflowType.item.strWFCode;
				var wfModid = workflowType.item.strWFModId;
				var userid = globalUserId;
				var strwfAction = "1";
				var stepId = "CDMS_01_1410_01"; 
				var wfResponse = "";
				var wfTaskStatus = "0";
				var requestNo = "N/A";
				var stepRemarks = "";
				var routedTo = "";
				var completionTime = "";
					if(workflowType.getValue()!=null&&workflowType.getValue()!=undefined&&workflowType.getValue()!=""){
						console.log("=====================getNewWFTrackNo");
						formsLibrary.getNewWFTrackNo(wfid,wfcode,wfModid,userid,function(strWorkflow){
							//TODO - START LOGGING TO CI_LOG_WORKFLOW
							//alert("start log - create WF");
							formsLibrary.setCIMInternalLog(userid, strWorkflow, strwfAction, stepId, wfResponse, wfTaskStatus, requestNo, stepRemarks, routedTo, completionTime, function(isSaved){
							});
							//alert("end log - create WF");
						});
					}
				}else{
					glblUtil.alertMsg('Please select Workflow type.');
				}
				
				
			});
			onObj(this.cmdCancelWF, "click", function(evt){
				dijit.byId("myFormListGrid").store.fetch({
	    			onComplete:function(item){
	    				var strWfNo = dijit.byId("workflowType").getValue();
	    				var txtCusName = dijit.byId('txtCusName').get('value');
	    				var nDate = new Date(item[0].rqstDate);
            			var isYear = nDate.getFullYear();
            			var isMonth = ("0" + (nDate.getMonth()+1)).slice (-2);
            			var strFolderName = isYear+"-"+isMonth;
	    				if(item[0].status=="Not Started"){
	    					glblUtil.setCancelWorkflow(item[0].wfNo,txtCusName,item[0].requestNo,
	    							item[0].status,strFolderName,"","");
	    				}else{
	        				glblUtil.cancelRequest(item[0].wfNo,txtCusName,item[0].requestNo,item[0].status,strFolderName);
	    				}
	    			}
	        	});
				
				
			});
			onObj(this.cmdLaunchWF, "click", function(evt){
				var val = dijit.byId("workflowType").getValue();
				var strFolderName;
				if (confirm('Are you sure you want to launch this workflow?')) {
					myFormListGrid.store.fetch({
		    			onComplete:function(item){
		    				strFolderName = glblUtil.getForlderName(item[0].rqstDate);
						if(item[0].status == "Completed"){
							var strRqstNo = item[0].requestNo.toString();
							var strWfNo = item[0].wfNo.toString();
							var strCustomerName = item[0].customerName.toString();
							
							//for external
							if(item[0].wfId == "20182204000001"){
								/*var extData= {};
								extData["wfNo"] = item[0].wfNo.toString();
								extData["UserName"] = globalUserId;
								glblUtil.generateCIMPdf(item[0].wfId,strRqstNo,extData,function(isGenerated){	
									if(isGenerated=="error"){
										glblUtil.alertMsg('PDF generation error.');
									}else{
										glblUtil.alertMsg("PDF generated");
										//launchExternalRequest();
									}
								});*/
								glblUtil.getSYSParam("CIEXTAutoGeneration",function(varParamValue){
									var autoAuthLetterFlag = varParamValue == "true" ? true : false;
									if(autoAuthLetterFlag){
										formsLibrary.getExtRqstWithAuthLetter(strRqstNo, function(varReportUrl){
											launchExternalRequest();
//											var linkWindow = window.open(varReportUrl,"Autorization Letter",'width=1000px,height=600px,alwaysRaised=yes,location=0,toolbar=no,directories=no,status=0,menubar=no,scrollbars=no,resizable=yes');
//											var timer = setInterval(function() { 
//											    if(linkWindow.closed) {
//											    	clearInterval(timer);
//											    	getRequestExpenses(strRqstNo,function(callback){});
//											    }
//											}, 1000);
										});
									}
								});
								
								
							}else{
								formsLibrary.createDocumentPdf(strCustomerName,strRqstNo,strFolderName,globalUserId,solutionPrefix,function(strVSID){
									if(strVSID!="error"){
										launchFormsLibCIM();
										var userid = globalUserId;
										var strWfNo = item[0].wfNo.toString();
										var strwfAction = "4";
										var stepId = "CDMS_01_1410_03"; 
										var wfResponse = "Process Request";
										var wfTaskStatus = "1";
										var requestNo = strRqstNo;
										var stepRemarks = "";
										var routedTo = "";
										var completionTime = "";
										
										formsLibrary.setCIMInternalLog(userid, strWfNo, strwfAction, stepId, wfResponse, wfTaskStatus, requestNo, stepRemarks, routedTo, completionTime, function(isSaved){
										});
										
										formsLibrary.setCIMInternalLogLaunch(userid,strWfNo,requestNo);
									}else{
										glblUtil.alertMsg('Failed to launch, please contact system administrator.');
									}
								});
							}
							
		        		}else{
		        			glblUtil.alertMsg('Failed to launch, please contact system administrator.');
		        		}
		    		}
		    	});
				}
			});
			
			onObj(this.cmdCloseWF, "click", function(evt){
				clearFields();
			});
			
			txtCusName = dijit.byId('txtCusName');
			txtWrkFlwNo = dijit.byId('txtWrkFlwNo');
			
			dojo.connect(txtWrkFlwNo,'onFocus',function() 
			{
				txtWrkFlwNoVal = txtWrkFlwNo.getValue();
				
			});

			dojo.connect(txtCusName,'onFocus',function() 
			{
				txtCusNameVal = txtCusName.getValue();
				
			});
			
			var cb = dijit.byId("workflowType");
			dojo.connect(cb,'onChange',function(){
				formsLibrary.getWorkflowDetails(cb.get('value'),function(data){
					glblWorkFlowId=data.strWFID;
					glblWorkFlowCode=data.strWFCode;
					glblModule=data.strWFModId;
				});
			});
			
		},
		handleICM_PageOpenedEvent: function(payload) {
			if(payload.wfNo != undefined){
				glblUtil.setVal("workflowType",payload.WFName);
				glblUtil.setVal("txtWrkFlwNo",payload.wfNo);
				formsLibrary.getWorkflowDetails(payload.WFName,function(data){
					glblWorkFlowId=data.strWFID;
					glblWorkFlowCode=data.strWFCode;
					glblModule=data.strWFModId;
					glblWorkflowNo = payload.wfNo;
					formsLibrary.getWorkFlow("", payload.wfNo, globalUserId, glblWorkFlowId, glblModule);
				});
				
				
			}
			glblDDMenu.initSubMenu2(); 
			formsLibrary.getWorkFlowType();
			formsLibrary.initFormsLibField();
			globalSendNewCaseEditablePayload = payload;
			getMyInboxInstruction();
			dijit.byId('cmdLaunchWF').set('disabled',true);
			dijit.byId('cmdCancelWF').set('disabled',true);
			dijit.byId('cmdCloseWF').set('disabled',true);
			
			
			
		},
		handleICM_SendWorkItemEvent: function(payload) {
			console.log("handleICM_SendWorkItemEvent ===>");
			console.log(payload);
			globalPayload = payload;
		}
		
		
	});
});


 

var formsLibrary = {
		initFormsLibField : function(){
			var layout = [
			          	{'field': 'id','width': '70px','name': 'No', styles: 'text-align: center;' },
			        	{'field': 'requiredForm','width': 'auto','name': 'List of Required Forms', styles: 'text-align: center; cursor: pointer;'},
			        	{'field': 'customerName','width': 'auto','name': 'Customer Name'},
			        	{'field': 'requestNo','width': '150px','name': 'Request No'},
			        	{'field': 'status','width': '100px','name': 'Status'}
			        ];
			            
			if(dijit.byId("myFormListGrid") == null || myFormListGrid == undefined || myFormListGrid =="") {
				glblUtil.createDataGrid("myFormListGrid","myFormList", layout, null);
			}
			myFormListGrid = dijit.byId("myFormListGrid");
			this.cellDbClick();
		},
		cellDbClick:function(){
        	myFormListGrid.on("CellDblClick", function(evt){
	        		myFormListGrid.store.fetch({
	    			onComplete:function(item){
//	    				alert(item[0].rqstDate+"=="+item[0].formattedRqstDate);
					if(item[0].status == "Completed"){
//						var objbuilder = '';
//						var strBase64 = "JVBERi0xLjQKJeLjz9MKNCAwIG9iago8PC9Db2xvclNwYWNlWy9JbmRleGVkWy9DYWxSR0I8PC9NYXRyaXhbMC40MTIzNyAwLjIxMjY0IDAuMDE5MzMgMC4zNTc1OSAwLjcxNTE4IDAuMTE5MiAwLjE4MDQ3IDAuMDcyMTggMC45NTA0OV0vV2hpdGVQb2ludFswLjk1MDQzIDEgMS4wOV0+Pl0gMjU1KAAAAP\/\/\/+MAAOMBAeEBAeICAuECAt4DA+EEBOIFBd4FBd0FBdoFBdkFBeEGBt4GBt0GBtwHB9oHB9xcYlxi21xiXGLVXGJcYuBcdFx031x0XHTZXHRcdN8LC9Vcblxu3VxmXGbXCwvgXHJcctpcZlxm2FxmXGbcDg7bDw\/YEBDeEhLhExPXExPUExPbFBTdFRXNFBThGRnNFxffGxvaGhrDFxfbHBzNGhrjHh7gHR3XHBzOGxvLGxvLHBzYICDVHx\/IHh7GHx\/gJCTWIyPHICDTIyPVJCTOJCTYJibhXClcKdEmJt1cKVwp1Ccn1VwoXCjPJyfWXClcKdcqKtgsLNwvL9kuLtItLeAzM9szM+A1Nd01Ndk0NOE3N8kyMsUyMrsvL987O988POA+PsY3N98\/P+JCQr43N8E8PL08PNNERLg+PtZKSuVQUMFGRuNTU9ZTU+ZeXthZWd9dXdZaWtNZWctXV9pgYNxmZuVra+NqauZtbe1xcdxqatBnZ+p1deFxcex7e+x+ft94eOl\/f85wcOyCgsNtbeyIiOeIiN+FheKJieOLi9mFhe2SksR5edqOjsqEhMJ\/f+ubm++hofKpqeGenvCvr96lpfG2tuqystmlpdWiouGsrMKUlMSXl\/fAwO24uNyurvfFxea4uOW4uM2lpc+oqM6np82mpua8vNCqqtGsrOS8vOjBweK8vNSwsNOvr+rDw+W\/v\/PMzOjCwvnS0vfQ0OrFxebCwte1terHx\/TQ0O\/MzNm5uejHx\/XT0+vKytu9vd2\/v+LExPvb29\/Dw+zPz+zQ0O7T0\/TZ2evR0ePLy\/ng4PDY2PXe3vPd3enU1OjT0\/vl5fji4u7a2vzo6PXh4evY2OnW1u\/d3fzq6vvp6fvr6\/np6fHh4e7f3\/zt7fXm5vvt7fHj4+\/h4fjr6\/ru7vPn5\/Hl5fTp6fvx8fTq6vbt7fXs7Pbu7v739\/ny8vjx8ffw8Pr19fn09Pv39\/z5+fv4+P78\/P37+\/7+\/v\/\/\/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACldL0JpdHNQZXJDb21wb25lbnQgOC9MZW5ndGggMTMxNS9IZWlnaHQgNDUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDIzNS9UeXBlL1hPYmplY3QvRGVjb2RlUGFybXM8PC9CaXRzUGVyQ29tcG9uZW50IDgvUHJlZGljdG9yIDE1L0NvbHVtbnMgMjM1L0NvbG9ycyAxPj4vTWFzayBbMjQyIDI0Ml0vU3VidHlwZS9JbWFnZT4+c3RyZWFtCnja7JpRaBxFGMf\/M3ubu+SS3mybNpFgq5SS1gdb1IhKrC8FH9QHjRRfahARwQcrKPpmsQoKgihooaigUiqIAR\/0xapQjSCSVtMEsYg0ttQaTDJfrmkvtze748Pd7e3dze5dUjkbe8Pd8e3M7Nz3m++b75udO5bFNVM42qxt1jZrm7XN2mZtTUmUBV+DMxSUr1h6qRNcw9Jgeb9DcdsHV77tu7bnq27uJtc6qwYDCjPPfa8a3HD3a4OmekFXPSsr75syIB9qz1TjW4Y\/r2KsaqM1sV4J4Hi7CVSMh0lFjXXXhA8LCFn4DgA2DXYEtVaeJcAV0wwAvPlJvwGauIpNmwjJSk8DGHxrR1cBAHRCLSXX+Rc67VzaLnhWHhn18qE1Y8UYVhLkHp8H2MO3PD0DwFKKudtufcJ7\/dgySyQ9i7Mb79uXMqFSHLgodygLouYWQp1cPRhVfyHVXwVSlVfVRctKzoH2Tmqgs\/fIp0EoPjX5wJGjwdXM7GMzALqNqCABRKgRFkRFjzrUQD1hjPAxfYIqAVDUvFdyzoIzOwFg+z3vqMzuFMtz4AvXTU6rzCO2m1r2L36i7fwd13VYGyJchOJ8+0rcPS6d1bcFqBTJyrVUUwB2DHyDkQMcebH41fjfOzOTePSgzzXY0TF1e+pxoIDMosGsZnTRpI7NTIVotkFEqBXaS7gTcwC7oXAeRz7WNgdbUomhD86ndhfH+nY\/H8luWY1dqG7Ka1UUTUxWRHYrT1rNUqe4\/OqBj2tAbDzkcq685cvuJYW7Rif11uE5AHLOvvf57h4AwGKD3UNpXQkhRFxyqrmdTOgisk+8fSl2vRZsPQ2g\/\/59eGi0k\/lInnnlN7V5EEPgC4yJnw9MPTt6CQv838o0whCrq1y7PszTat2\/hlX56icAt2VOsvRpO9mRTpwjbHrjhUTnj4sb\/tg+dvgYGz6X\/ezL3j0yVndqwpdXFrcqMfsKY13A6nk\/\/Amw7e\/n8REYB0ssa7brrMK77yVgF7CMoYEP38yx\/hMrRaW6XiRiQ0llxYkG4aYyUE2iMYbuUH6d0MC6zSd6s76Gp1GAtXfv8V1THny4TNs7n7FOzwPZpDYFVGFStSapGnSkSDtRxKRU9yFDnWho160XTgG4\/pcX91+053py2cV5b9uQ++DI7xZsZsuerh4cHgMw3BvnTdRMxmlqvYnVeSzFGDZgXVDTAKanX40epz8H4GbbgsERoxekMeNQVIQ26EiGPrUDUZ3TGAYKWC+nOxrN2V8A+p7K9SAClla8aaKqbCiMvSly9JXG48pzDrvz1yYe7Z9MJCMmnMJTEBGiSJBpoijSNSgyMJm\/rrTKKf5comCdPvi12wA1NfrS5fVr9mwtYPXcVPZMTstLHXaOpTSYBqBszVzV1TmP5S0z6wsD6ZvW7MFamFUvpi09l+mjPLeY4uDwLM\/rA0jM0kauPd92ZvvOZvA\/YI0ujiy+Q5cwXDmydVoL86IsBmiCQEmIPINxpIPql4QDSDiQKEulSweQDor1VY2tQS1GxRIXSIRPPAQEQZi2GaFzfxn6DERZaZAOpKwVSq1Sto4UgCgalcqUVIn0QTCOP1tzgKIpHek4ZaeUYX6nTkDtXLWiUOgkhkCi7inXnHQifs+RMFE55XqnDsxpZZARVZskQaBKgqUSqmjEGnJjWTJ0dbMDwHGkrNRLp9hNthS25lEjdCggAFH6XEUcbqI4LSVdbbmWfpNk7f\/8tFnbrG3WNut\/Wv4ZALtiB20KZW5kc3RyZWFtCmVuZG9iago1IDAgb2JqCjw8L0NvbG9yU3BhY2UvRGV2aWNlR3JheS9CaXRzUGVyQ29tcG9uZW50IDgvTGVuZ3RoIDEzL0hlaWdodCAxNy9GaWx0ZXIvRmxhdGVEZWNvZGUvV2lkdGggMTcvVHlwZS9YT2JqZWN0L1N1YnR5cGUvSW1hZ2U+PnN0cmVhbQp4nPv\/fxTgBQAX\/R\/vCmVuZHN0cmVhbQplbmRvYmoKNiAwIG9iago8PC9TTWFzayA1IDAgUi9Db2xvclNwYWNlWy9DYWxSR0I8PC9NYXRyaXhbMC40MTIzOSAwLjIxMjY0IDAuMDE5MzMgMC4zNTc1OCAwLjcxNTE3IDAuMTE5MTkgMC4xODA0NSAwLjA3MjE4IDAuOTUwNF0vV2hpdGVQb2ludFswLjk1MDQzIDEgMS4wOV0vR2FtbWFbMi4yIDIuMiAyLjJdPj5dL0JpdHNQZXJDb21wb25lbnQgOC9MZW5ndGggNzcyL0hlaWdodCAxNy9GaWx0ZXIvRmxhdGVEZWNvZGUvV2lkdGggMTcvVHlwZS9YT2JqZWN0L0ludGVudC9QZXJjZXB0dWFsL1N1YnR5cGUvSW1hZ2U+PnN0cmVhbQp4nFWS30tTYRjH\/4RuoougIgoCL4wIq4siuumHZBR1VRdFRYFSpAaRm1lLcz88287O2e+Nbbq5nIq2foNiDlExosIfrSLTNjV3tuV0m9vO2fn2HrWLXh4e3vf78vnyvs\/zQIgjH88V8qtABiA5l8uSBBSISJQUEC9I5\/SfRYhpiDz4tMvMslZXs7FVbe9Umb20yWG2ODQtdFOLSePoUpgDDfpWvc3rcbnpFiVQJLyZ8RC3+Tw4IAEsE9ss1v1jwCIkPbIMoQiWtoGsAijK9zOBsgrZzqPVWw9V7j1eU3Lk5q4DV7YfuLrtyJ3NZZWl5XWlx6p+J+DzvoIIfhW06Tnx2XOi7qZ2RNY2rWgL1zs\/kWhoDT\/pjdf7I3etn3Yfvc1lQOm8oogCjybd06iITWU36gOzj4MxWftXdXBO95a77\/9+2\/39XiCiCs6XlNeSdyoptwgIgMroWQB2nalW98dkPdN3PGP13ZPyzkl5z7e64Kw8ONPQNb7l0AWCWN1PRen\/goKiyR93nLyu6f+lH+JMwzF6YIYNRdlhThNa1AwuGEOzpWeupYFmiiIIxLzF6Y4UUHr+FvNu1jYas49ELYM\/7EO\/7KML+tAcMzTX\/pHbf\/bqnwJMFjMhsokkpWWWgMOX7vVOFZ59FYKTK8HPiY73Cy\/Cuc6pvPt90j8WO1hxPQ9YLBtFZulW0ot9p269nhBfTwh9E7mB8fTAeLZ\/kn\/zBX0\/EJpG+UUZX4RGyZAiI082zoyI05ebpzP4mUEkhRkOsTSmovgQxVRKyucuNwoCDFrnOmLQ+ghSVecJcwj\/RjyFlQwWY+BSiItS6z\/Po+ahL0s6qHWtIw57N\/F8ZOi1d40pqA497WP1LhPjZYwBudpf2xx4YHipNL9aysBqaSfI0tKyw+OPC+BEaahSRUgjkV0prq7yApI8kmuDR+qTzIEx2UXpvkiq3WJ1GdwdchWtNhi9bS5Wp3LZWINBr6QtJv8zudbWaHTqbQ4dw0p9kShpBvi1vKYU\/8WGzv93i79YUpgVCmVuZHN0cmVhbQplbmRvYmoKNyAwIG9iago8PC9Db2xvclNwYWNlL0RldmljZUdyYXkvQml0c1BlckNvbXBvbmVudCA4L0xlbmd0aCAxMy9IZWlnaHQgMTcvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE3L1R5cGUvWE9iamVjdC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJz7\/38U4AUAF\/0f7wplbmRzdHJlYW0KZW5kb2JqCjggMCBvYmoKPDwvU01hc2sgNyAwIFIvQ29sb3JTcGFjZVsvQ2FsUkdCPDwvTWF0cml4WzAuNDEyMzkgMC4yMTI2NCAwLjAxOTMzIDAuMzU3NTggMC43MTUxNyAwLjExOTE5IDAuMTgwNDUgMC4wNzIxOCAwLjk1MDRdL1doaXRlUG9pbnRbMC45NTA0MyAxIDEuMDldL0dhbW1hWzIuMiAyLjIgMi4yXT4+XS9CaXRzUGVyQ29tcG9uZW50IDgvTGVuZ3RoIDc4OS9IZWlnaHQgMTcvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE3L1R5cGUvWE9iamVjdC9JbnRlbnQvUGVyY2VwdHVhbC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJxFk0tME1EUhkeFtpQ+lBZaIg8fIGCCLowRCMFEZWFiXBg1UVaoC0yM0RiMoiLUFOiDPocWW2ilCKFWonGDbly4UOPCpRsNGh4q5dl2Smc60\/m9owtv\/pzkJuc795yT\/yIFCAASHL8oYpXHSgY\/OKyzAMODBzYyGyKQTHDIQRK5ZEEPDnmcA1Z77\/BI0NRvNdn6HP4Rq3P6gemJzROITE31WTyjI88sZto24JWQNEboGMGXfrN8FhyHTBZrKSQYpFhkgNU00hkkkxB5DHkmCCKk4bY\/SyVQtvN4HnWeoi6X6u0UdUMmu5NfcEmmat6mrNEbW\/Jk9Qvz8NJTBCGs0xnjBSjkJ8t1gQLqebHiww7ZO7ViWi63VFZ15ilP6Axnt+Y3cDkEQlHSFy\/C459ObIKijpXrX2i2fFJTX4zab0Xat4bSiLb4Fpk7yWKr4gQj4H6fmSBLSW4oHE0DctXpEl2kZPtHrfJ9YeFMntJXsss5t4bFDbI0UrCZAVyhQQE8GbCfDixtQlV8qkjvNBhfFu+c0FcOGWtMcQHzaSxnodLdy9e0\/eZhCfYKyJL6vQ4fqUCpj+w\/5JhfRzwHw8G2JdIAEBeRr7tWWkFTsvYE8NB99x9i84+vsKAUh6sOmBdSWBSk5FleitT2i1UHg2XlUU1R988MXGMO0hgj4pEjwuQg15ypq38s13b94jDLIA4oy67UN0b31s40NXwtUA7MrsIZpgXkVhjY6VgiA43uSkfHXFPLm5LqrmUBO3bdbGyNtp763H6JvXCOUav7kyJ67FZiLg5kybEMD5WmfSwMnw9Xb3ytqLUeOfrcbIfXj8lJvHoJecH1+RUEJqIEIca73WWOr6Gx+WHtPreh1Lqn7pFxb2dZdU9FjWl33f2aA91afUf1\/utpEZ0PBgjC5jb9o0Hy1uIy4utI8lgVsU4MDHxbkyJZFNnn97jkt0HvuCh5mXXSDovD7fJFhkOvuy1hk8czGPLZgsP2kMccuNfjveUOuyxe2uV76qYlhPwBUZJkauGv+P\/K8WAFScSD+JdDzh+EsTffCmVuZHN0cmVhbQplbmRvYmoKOSAwIG9iago8PC9Db2xvclNwYWNlL0RldmljZUdyYXkvQml0c1BlckNvbXBvbmVudCA4L0xlbmd0aCAxMi9IZWlnaHQgMTUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE2L1R5cGUvWE9iamVjdC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJz7\/39kAQCOiO8RCmVuZHN0cmVhbQplbmRvYmoKMTAgMCBvYmoKPDwvU01hc2sgOSAwIFIvQ29sb3JTcGFjZVsvQ2FsUkdCPDwvTWF0cml4WzAuNDEyMzkgMC4yMTI2NCAwLjAxOTMzIDAuMzU3NTggMC43MTUxNyAwLjExOTE5IDAuMTgwNDUgMC4wNzIxOCAwLjk1MDRdL1doaXRlUG9pbnRbMC45NTA0MyAxIDEuMDldL0dhbW1hWzIuMiAyLjIgMi4yXT4+XS9CaXRzUGVyQ29tcG9uZW50IDgvTGVuZ3RoIDY0NC9IZWlnaHQgMTUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE2L1R5cGUvWE9iamVjdC9JbnRlbnQvUGVyY2VwdHVhbC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJwdUktIVGEYjRatIlwUghG1cFME9gAXaWRFQ1pEUKRtTDAqGAyUFlbUZIEULVq0aKUgUliZDWW+QoXGykehjg8qx3Eeznjn3rl37mvu+87pu8LPzw\/\/951zvu8cB7xipx0oDqAbcEzwadiq98jnYVhwCnDoOw\/JoLIkPXVXcmCzWcOxEHyX9l\/v2VdSV7Sj\/MD+s48CnctLqpiD48KBIRqxvKURMoHIIvyNwe1b61qb+z99jE5NbgwP\/Wu62b2nuPbVyx8acdnUYlOx7SIWxcmK+8cOPUtH4OiIr8E0IQoQNhCexnlf++NAL1EIkmW6BZLXHgiVljRzCTAJiDxmprN9H37Pz2oSD4XH33mU7Ly8uJCnFtPxoPYWN7zv0iPLMDV0dAwnk7YiIx5DX++CwMHR8CXIXr3SxjKwbIyNRnYV+bi0t5P+z2GW1zJZhaBiMUtVMTmZiK6pmoYjZfUklcS87fl5usrPpMBzGBz6xQo5zdYlBVzWQxsYnMqbznpaOVHRJHNe\/ZvXE4fLakkJCZieWU1lGFmX5HyB5Vwhh9D3RV5SBdGtqrxtSJAVWBZ2F9esLEOVEQqtJNIZVuD5nK3poEFSKZflsLQkXboYID2W61FUn3r65N4Mz0CRMDo2921ibnYuMTISHh9bXaeNcWhvG+7qnCJDNcuk0eIr2Lblwtd+w9YhiuAF7xBOjvfsGAwqleUthg5itAGNYmNjYlw\/WNp8t2UoGvHcl1SXybg5Dg9bB2rOPCAHNyPhWSzINJ1DaH\/CuHGtu\/xog89Xf8t\/p\/pc3fGKxhfPRz0W4pJ1G9Zm6iicmmqYBhFZ4Bjv9mLpoSGZUqlYVmEUZAPMf2fmUK8KZW5kc3RyZWFtCmVuZG9iagoxMSAwIG9iago8PC9Db2xvclNwYWNlL0RldmljZUdyYXkvQml0c1BlckNvbXBvbmVudCA4L0xlbmd0aCAxMi9IZWlnaHQgMTUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE2L1R5cGUvWE9iamVjdC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJz7\/39kAQCOiO8RCmVuZHN0cmVhbQplbmRvYmoKMTIgMCBvYmoKPDwvU01hc2sgMTEgMCBSL0NvbG9yU3BhY2VbL0NhbFJHQjw8L01hdHJpeFswLjQxMjM5IDAuMjEyNjQgMC4wMTkzMyAwLjM1NzU4IDAuNzE1MTcgMC4xMTkxOSAwLjE4MDQ1IDAuMDcyMTggMC45NTA0XS9XaGl0ZVBvaW50WzAuOTUwNDMgMSAxLjA5XS9HYW1tYVsyLjIgMi4yIDIuMl0+Pl0vQml0c1BlckNvbXBvbmVudCA4L0xlbmd0aCA2NzkvSGVpZ2h0IDE1L0ZpbHRlci9GbGF0ZURlY29kZS9XaWR0aCAxNi9UeXBlL1hPYmplY3QvSW50ZW50L1BlcmNlcHR1YWwvU3VidHlwZS9JbWFnZT4+c3RyZWFtCnicNVJrSJNhGBWFAqF5WcvUIZbZtPSHqAglMRv+ELr9qfwRRbFMM0sTxbKLaYFFUCgZSgQq6iAlqRCTkGbbvGCaoXPOy5qfzsvUXdzt23c5vV\/hy\/nxvs97nsPzcI7HDxpg4PfwNh5g\/YAX8AA+2KwQKgQstt0CjcD+7+LlaA9LDr72UFdzG6PDz+8KSM2W5yuVVcPDFLPD3\/Q4vCwRx7aPdbpQcEO1LzS\/KE\/b2Y7+PjTUGx9WjB6KvfX2jYbhiDLNgLT63AxDnqlp11JSKtVqrK1gdgbGWaxbsWRCXw+OHystK68jsj6ed3qWyYTVNZ9lCfmTc5g0oeG94\/odXWbOq4LS3vYPMC1ibgFiSebPMYrlyUYuMlt0ZG7ti6mlLfRoWVHUg8j4+kYVYpKehkTcb1HBYMSnL\/N5yuccDbfbS5npwIAstwfaccjPdARL2uKSxgvKcO6SJTik+dRZjdmCaSOTcOAiXOBZdHeNZqTdGxvDHytCpbW7Q3rF0YYwqU4aPxIQ2BUuaVqgMLvAyTMqODv8XmjVFllc0fw8DItITG8Li9SJJNOi\/VpRRH+Y+Lss8dPKBtHn0o\/ehQPgYNTTB2NuDg1h1QFlyUTQnhax9EfU4T5xTGdAUFNZueu3Xlj5wunXNkpw0OdDTnZdYaH61wwMFiiL9bFJ7\/bGVUXJah49s+lGsLGB3NyXHa163oc16yrLwTANqVTZrFrQjGPdiTEDJkxYsqF\/ACYzPnY7FIoylrjFCPGw2j3EOfWAPfFIUXXN1OCg4BRlgXkJlAmVFROKk5Wk4uewtU27aNbl9xPvGB4arbv4dndUxGVFVnVJSWty8hX5icdPqr7NzHDkl3C8vPd\/6mw+isYmC444uLoM3g+nYyecQnoFOFmXk7P9BVdiCawKZW5kc3RyZWFtCmVuZG9iagoxMyAwIG9iago8PC9MZW5ndGggNDAyOS9GaWx0ZXIvRmxhdGVEZWNvZGU+PnN0cmVhbQp4nM1dW3fbNhJ+96\/A26Y9jUxcCJJ9U2Q50daWXUluT7LZBx9aSbRLXyorvfz7BUAAhC4EBhTTdXISDG1AM\/Nh5iMwJMXfTt4sTihHeVGgxd3JeHHy8wlB\/5Q\/xSgRf+X\/BU3R4v7k9BwjTNDi08mr7xb\/kX2bLgkq791BFKM85QPO6oEEYSYHitHrk2TAOOcZ+uMkUb1nb7Ww\/nzyajb++WY8X6DzqxkazcZnkwWaTH8RP5m8HS4mV1P0WhwvxrPp8EIakaDP4p\/8UPRWKP\/jgFX\/+rdo75RXvyGS5IO8UL9iibIyk53Q6er+c4LOHtHPu16I3wsX7DgB0mv3QOmTf4XxUr9UY93SquXH0ATdn6Q5UVJlpd22rH\/DctNHSLttqT5QddHCdlMahZURtpvy5NPLM2luwPLEFBV900FamJgqnJCi\/nCaXg3iw6XdFJywQ7Y0evHrBIs4wcXrRPwhjBntHRUSfITzZ8PFuE\/vSXHQmEZx7Xj6mhRHuk1THO\/2r1ezn84vrn7te9KZoEGv22eX89ejyaWa9yQlau5TgoEYSF\/2uYNgPEhVDt0bWaXRHDJYwGcHaxk+GCfEDtYyfDApmsFahg9mlNrBWj40GMC6Ims0xQmpstJuqylOjKistNtqCsOGwuqzQ9OURmFlhO3GsO6LMgnIujjvRDyT6Vt0dX4+GY1n3\/fKvvygTY3++Wg4nY5nP6DR8HpxMxujhaTB+eCoTMSMqUjEMh9qWUG7FZXJgCPzzx+bWcF0IEipstJuqwMBMxssDO22eqKZmWiGtpvSKKyMsN3o2HxZJsFiMyuKQU7tKhO7wdm+yhzdzBdXl+PZP+ZiNSmWmpdqbdklRsMklPHUoCqkykq7banxtn0K\/Tun1ailBrUUbTelUVgZYbsxE\/2iTAJOdE7jSMjMMZoOL8eoVwKS5mTJoODSHPXDAcEk5bu\/kpbmjqWkPSLPH9do8nC3+n119\/W2Qj+ii9vnDZre3i9\/QOertZUvV3d31VIdHPTIrtEIHtDMseU1znP5k2bX0mHhJyYgy3g78b6dnC\/Q6N149JPYpw1ns+FUnAiArAvIJLUiUIFndyOZ3oW4rQ5bzm1oc7Tb6rDkJiw52m5Ko7AywnZjMulFmQTMpDQ2kybnaHLWJYEOn0m5iCDl0b0WlU9zWAzy\/JADjrFqw0UzetzJPifWRi3HGElY6rcSY5IX0J1B6zooZ10mE01vLt+MZ\/3NJ2HUgqXlGLAo7xCTi\/fXY7G4RIbl+\/OGcmy90XKMN0wFaDpguC1AH9dPj+vbzerx4agQZU4asfY8apmyNJMDCrkO0LI6RUdvsTJslxLYLhOwXh44bQkiyRDBaYWVEbYbw8kvyiQgJ8cWOYZnZ7PxfN73qoYk\/3cziuQQGo1KnqVIpPxwji6H1zdDNF\/MxuPFD6IdDtBodvOhPauEcy35kBeDTCaQorBCrNTqA5kQ7YOkpYzLvvdKplh+iH+MVkSJo0gc+AcRVxPZVgXGdH9qG0x\/OAIztSG2rmAAZsJ4ixnmYMxw5igSBwDMjCayrQpY5cTxaTmaLN6fikhcjHvNCWVLbG6Orm6mi9n7XimCM39ySv\/laflyOJ1cDLtElVgNNKnIMgJLRWWYyZDaSkAyGl0qG42uYDaKjo0udRCZjco+XzpevzsGOZWQ1ptQQhqwGuQgKWl0qZw0uoI5acBqkIvMyVS55LvukiSehX+7ZSlhTdSlOfAEkNa9an9q2wBRZ3SpqDO6glEnOjq68vhzAMsOYufnkA+TazS6Outw+QheCeVFptdrUqqstNuWoDVdaD2mFVZG2G70EvJlmQRYQmKxks+SpEMpdDIZIHOhUG2qOlXKwhuFlBENqZQqK+22pQabW9g52m01ZNxAxtF2UxqFlRG2Gz3LL8skO8u\/IVzjJxpc5Ijn2NyiQPZuUTAdZCFS\/kTen2AE7x0aBBM5MI4OpueT+elIrLvR6Muy\/O\/q4fPpc5fbMHYclMWt2kF22EHOOzrI94qVgTXTenm32pxePN4+3C3\/7NfLNDSNaddpTCOn8WwxQb8s16tPq3KrDtHLUlUaRCNhn49HRxq0hzblAbRpa0y5n6XcIZ6ZMx3iZ45wOTAeqPnmdvP1yIBUViceiEyHbm4lkfP\/dvmwXN9WaPLw6XF9r0IAzb8slxv08dV78efjd0eHKHwZXeRyXcXrpS0t5IqLB5e2tChkL72MlgcJASyjta6EOroSGlpGU0eXOmh09QCAtKMBoF6fhgFgLHGMkgcQAIyuGgCtKwxA7urKk74BEHZYAFKCgQCIs7BjFAYCoHUpAIyuIACiY6NLHfQKgLSjAYATGAApIa5RBAaA0VUDoHWFAeCuLk5aANilvLQIMLns0InyxMDIyulXsdBY3qHz4wtF0dSWEJduQjtPw2aW2tI8A1NbmueNLnkAoDajSx44unqkthoAQzfBgo9mM0ttIAC0Lg1ArQsAQO7qypO+ATB0Q1y6CQKg2cxSGwyAWlcNgNYVBsCwmaW2fgGwdENcugkWXzSbWWoDAaB1aQBqXQAAuKuLkxYA9qgtC6zmZIdu1LZ\/x0eA2tabVVktn9HjJ7GiK\/evd3Zbsyrq8XlpOkR7yeSNl9Fe3i8f7sS\/zbGbQzU5PHRi4l1PTDzyxPTmL3Rx+8eRPqmp8PlkOnSbq1if+p0rFso01jXT2BGZdn273ohd1POX1VMPc+fz0XToNnfRPh4zd6339xSSgHmhbm5Xcsr2bub1D84ws4Prwh\/08k\/nUu0AXd\/Mrq\/mnYq0doqLAc3l00+y+sepmWa+N81Nl+iJTtP42uL1+vH5aVluVr8v0ahaiQnvw0fOHR\/zgz7WXTr5GFtevHm6u90s0fjP1fNm9fC5Rz\/T8Fym3ecytsA4+rpeC8fQsCwfv4r26mn5IPztw1HKg47S7hMaW7i82nxZrv++DRyrF6\/1Mwh5vXoPXuFlsiBrLrrKbTPg+i5zCgBGUbAAgOU2wWhSBwcv78KvDMqVtr5AQ+wFGqIvzDhtCbqIE7oAoxVWRthuzDWjF2US5OYyJvpmHc42F5P5Qt7KIW+fn6PFFXozRr+MZ5Pzyfis39vpWb03TrLIi1GPQCM8RYp6h0pkPnGshEBVQ3XSpRAhJxh+3s\/ygdicRLu5+OtpKdd3o6\/Pm8f75RqMfbsX3HEbZwzgN3f85pF+47wYpCze8fOvVaUedEAfX4Wfhvj4XQ\/A4Iw2yDAMiQiNnyY9eRCDDcuyeGCGd3fr5fNzD\/4y7ESCoCWVh0GXNTD6jIKbcPDdvUKaIeogCiV5TznL92BqIPHcSh\/M\/gRvB7U\/+5Mm+3WBKzBG9ZFFM6VECvBnHbDf6wNbvg40kOCdyPXTQNLQAAgA7gAgtUQhUA\/wQPB8e\/8kGIB08d9ke4LBcaxharIdBIFWVGMgFUVhUA\/4RhgYBkhcBgjCoMFqGAAEg9ZVw6B1GSQC1JE41OHoimAP7gGwE3Itie1lD5Y77MHh7MGNEh7JHj6vQQ+ixOe1lz0sABwIAHcAUFpiEKgHeCCIfF6xQ4b7qcTCUVsaQSXcKooBRA3IyCDjLYD4Hq4wuGx9GCf6SScnrmY3H1CnJwq6EYSG2yEjCJBGF3d1cQgZWV3qgHchI+aJyU73L7fwhJ+MuENGDE5GzChhkWTk83r+KM5g1+vHp\/VquXk8ckmzTxd+UuIOKUGA4A4QSksMEvWA8Om805K2lR4CPMRdHoJAYBQxqygGg3rAN8KgW2ZrsBwWgcBgdDFXFwOxCHdZhHVhEeIB0POFU9EJ7mcR5rAIgbOIqbkwEskiPq\/7WdLs5bWfPZjDHhAAuAOA0hKDQD0gnDnpMeyxl9QB9mAue0AgMIpsnSUKg3rAN8KgW0ZrsBz2gMBgdLnlFxYsv9SE4bIH6cIe+1WnBsBOyLUktp89nGIqS+DsYWo2LKaMpPp7vG6+f+UI8thLaz95OEVVkP\/c8V9piarEqgHhxOm0BG3N6QB5uLVTEARGkS3bRGFQD\/hGGHRLaA2WQx4QGIwut3LDQIVY5hZiHV1w8qC+chQ\/gjx289pPHk4tlsJrsdSUbGhkLdbrdb8bmL389rOIU5MFAcEdIKSWKCTqAeEM6rQEbU3uAIu4NVkQBFoRtRWbKAzqAd8Ig26ZrcFqWAQEg9ZF3ZILBdVkmVuTpZCabCQZ7OWplwyoU1ql8NIqNSUTGqyjRebwfnZ5c5g6lVGQ\/dyxX2npz4HW3PAnIXWrmSAfjCJbrujRiW6Rrb11siiimEjdkgMNlhzqxHGzCFJMjM2i3QD3Z5FTE6TwmiA1JQMarALFZtFefPuzyCnlgeznjv1KS38OtAZ3IIvcWhzIB6PIbtt7dKJbZGtvnSyKKKZRd+tNQcU06hbTKKSYFptFuwHuzyKnJkbhNTFqts40WA2JzaK9+PZnkVPSAtnPHfuVlv4caA3uQBa5NSmQD0aR3b\/26ES3yNbeOlkUUVSi7h6UgopK1C0qUUhRKTaLdgPcn0VObYjCa0PU7CFpsCwQm0V78e3PIqe2A7KfO\/YrLf050BrcgSxyizMgH4wiu3\/r0Yluka29dbIoorpC3T0YBVVXqFtdoZDqSmwW7Qa4P4ucIgmBF0mI2XyR4LY4Nov24tufRU5tA2Q\/d+yXWnp0oDW4A1nkFidAPmhFxG7AenSiW2Rrb5ssAvmhdRF3D0ZA1QXqVhfIweoC\/DkCws2rjqRUWWm3LY020yfXv3PaUicSqoyw3ZRGYWWE7UY\/R\/CyTII8RyDtSTs8RzC\/Ho8mwws0mc4Xs5vRt3vRArEvtCL2hVZEv8jKbUsQ7CHItMLKCNuNmeUXZVLbLLfDHpFi2HqKrRdYW++0JQiNkCdaYWWE7caA\/6JMgn0PNMFdUkx\/f9\/4DL3p9etecYY7WjS8Wby7mk0+9G4SY1lHk0bvhrO3Y\/kg0\/Vo1OuX4iZFR5Pe3Mwn0\/F8jm6mk0WPDzfzQpxbCSnkkqOW8YHlQ9vyL7ODtQwfzFhqB2v50OAwl2NmvoBTSpWVdtsSlN+h3NQKKyNsN5pOXpZJDp14g0BxYC3XnxcTBGpwLUcMNhOf2CA4OLg1ndQ3+BXtL1CIfK9MO5Pkfj00Ab+7r9UX4TvHvndBPGxuyw2aPj5\/\/+OxbwMRm4u\/T1mRD4oCyVejtOp7ym\/v7lcPKElPSXEqX4p4pNK0GBQ5TGf0Gyhb8kDMXyYjWOaQkYFpoOZDD6YJaxsc4MJCaE3VF01wpqTKSrttWf8mS0wfIe22pfpA1UUL201pFFZG2G4kF744kwBLq4ILfUl73GBCWcqzvEj6eVsVoQYkNfXKeiPttqUOj8T0EdJuW9afqPoYabctrdbKSrutnL+XaxtgIgntdyb\/B7YzVSMKZW5kc3RyZWFtCmVuZG9iagoxIDAgb2JqCjw8L0dyb3VwPDwvUy9UcmFuc3BhcmVuY3kvVHlwZS9Hcm91cC9DUy9EZXZpY2VSR0I+Pi9SZXNvdXJjZXM8PC9Db2xvclNwYWNlPDwvQ1MvRGV2aWNlUkdCPj4vWE9iamVjdDw8L2ltZzQgOCAwIFIvaW1nNSA5IDAgUi9pbWc2IDEwIDAgUi9pbWc3IDExIDAgUi9pbWc4IDEyIDAgUi9pbWcwIDQgMCBSL2ltZzEgNSAwIFIvaW1nMiA2IDAgUi9pbWczIDcgMCBSPj4vUHJvY1NldCBbL1BERiAvVGV4dCAvSW1hZ2VCIC9JbWFnZUMgL0ltYWdlSV0vRm9udDw8L0YxIDIgMCBSL0YyIDMgMCBSPj4+Pi9NZWRpYUJveFswIDAgNjEyIDkzNV0vUGFyZW50IDE0IDAgUi9Db250ZW50cyAxMyAwIFIvVHlwZS9QYWdlPj4KZW5kb2JqCjE1IDAgb2JqClsxIDAgUi9YWVogMCA5NDcgMF0KZW5kb2JqCjIgMCBvYmoKPDwvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nL1R5cGUvRm9udC9TdWJ0eXBlL1R5cGUxL0Jhc2VGb250L0hlbHZldGljYT4+CmVuZG9iagoxNiAwIG9iago8PC9MZW5ndGggMzE1NzAvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aDEgNjc4NDg+PnN0cmVhbQp4nOy8d3wUVfc\/fsvUndnd2c32JFuy2U1ZSiChBKIsUqSF3oJEgnQQIYAoCAJKDQhYQEEUsIKKBAgYio+I2EVQFEUQUAFRpKiIJWT3e+7sJsLzfD6\/7\/N9\/f51NzNzpt97zvvUezcII4QMaDaiyD9s\/NCJD3z3cWM48gpCgaeHTZ3iX5\/2xXmEMrohJPQdOXHU+PduegLOZ69DiL846s5pI6+2Me5AqNFyhIYvHT1i6PAv3ju9G6FH\/fCM5qPhgDXfHoP9gbCfOXr8lHuv3h6vgf0ZCBV8dueEYUN592Pwrvd6wv6X44feO9HajT+JUG02XO+fOGnExNCR4jdgvxNCyr\/gGE0uaYi1G2mDYA8oSxnitJsRwgWwI6ICdD+OEz8pIZtokPagE+jd9H5aQZfQ9fRjepUzcj24+XwK\/y7\/I39FoIJdSBV8QivhdiEujk8fmz4u\/a30D9Lj3lneJ70\/e\/\/02X3pvg6+Yt8AX4nvNl+pb6avyrffd9h3zHfJd8UX85v9Gf6wv5E\/z1\/gb+Uv8t\/sb++\/3T\/BP8v\/mH97gA+kBJyBjEA40CjQPdA3cHtgbmBFYEMGyRAyzBnWDHuGJ8OXkZMRyeiUMTRjRJAEtWAghEIkpIa0kC3kCqWFMkMNQgWhotCdodmhuaGFoSWhR0PrQ6+EtoZ2hfaE9oc+Ch0MHQ2dDReFo+FbwmXhYeGR4XHhCQ3ubHBPI+eLnhcDNaSmeU1Rzc01bWva12yp+aEmfu2O2ja1v9ReiwVj1+LX4nHGcbSOIBIgg8irNJP2pFPodDoXuLaUPksP0d85E9eTW8g\/zB\/iLwtIUIBrXiEgRIUysWc6Aq7dmb4\/PeZF3tnedd5ffMjn8vl9nXw9k1wb4pvt2+F7x3fE97XvF99VP\/JbgWu5wLWm\/sJ6ro0Fri33r9O55khyrTjQJ3AbcG15PdcswDV3hjfJtbKM4TrX\/P8L13rWc215aF3opXqufQBc+xK41qqeayPCY4FrZQ2mANecL\/prcE16TUvgWrSmXU3HmsM1167dXnuzzjV\/bDbjWvw7hLhLsHwKGnETLDkMl7ExbM0dAioX6Z9rh659yK+H7aeo\/nOxOUKXuEvFCJ2fhdBZDrb28ynnLefN543n1fPKecN5+bx4XjjPn6fnyXn0I5MROjUPlhWwzD315zcbTt3z01igX\/upENYVp2YidHLsyWmndp0\/8F2DU0vPP3Fyw8mVJ1aeeObEYoROvMDuP+k8UX5iCOzlnYieyD+Rebzj8Q7Hi44XHm9+PP943vGc4xnHU4\/bjuNjF4+dP3bu2Jlj37K7jr1z7I1j\/zr2GlBvH3v+2OZjHY7dcqztscxjGccCx7ynV516\/dSOE7tHOkdaedBTcY34pLhaXJXop\/CDcLPxK+Mn6o88osOYvuKmoMYXgUODgWPtYZnNL4T1I3w1XK3C0lx4RqxO3C15YcmTmkrDpXXyCTBWDnbUYE0uHdH\/5WMoMPSG9URYpl53dKK+1o8Y1vyv985ni2Fhcm\/u\/+1d19052HB7PT3ov7i+qJ4aqRQpo\/\/jAoqeRXPRPHo7WonOovloKVqMnkIb0XNIQxXA0gfRo+gy+hk9hB5HCzFGx9El9DR6Cf2KfkFX0DNg0d9D76BN6A40DC1Hw9EHaAR6F72PPkYfoo\/QAfQ9Gok+QQfRIfQqGoUuoofRZ+hTdBiNRj+g82gRGovGoHFoPLoT3YXWoQmoHE1Ek9BkdDeagqaie9A5dC+ajqah+9BMNAO9htajWeh+8Ctz0I\/oJ7QTr8SPY4Ip5jCPatA1\/ARehVfjJ1EtimEBi1hCcbwGP4WfxmvxOrwey9iAFaziZ\/Cz6Cr6HT+Hn8cv4BfxBrwRv4Rfxq\/gTfhVvBlX4i14K96G\/kCf4wq8GFfh7XgHfg1XYyM24Z14FzZjDVuwFZ1C3+AUbMO78R5sxw68BL+O\/4XfwHvxm3gfdmIX2owqsRt78Ft4P07FaTgde\/Hb+B30J\/oLfYu+wz7sxwGcgd\/F7+H38Qf4Q\/wRPoA\/xkGciUM4jA\/iQ\/gT\/Ck+jD9Du3AWzsY5OBedRmfw50KFsFhYIjwkLBWWCcuFh4VHhEeFx4QVwkrhceEJPlNYJaxGLwhPCmuEp4SnhbXCOmG98IzwrPCc8LzwgvAiN5YbJ2wQNgovCS8LrwibhFeFzUKlsEXYKmwTqrg7ufHCdmGH8JpQLewUdgm7hT3C68K\/hDeEvcKbwj7hLWG\/8LbwjvCu8J7wvvCB8KHwkXBA+Fg4KBzirnG1XIyL84jHPOEpz\/E8L\/AiL\/Eyb+AV4RPhU+Gw8LlwRPhC+FI4KnwlHBOOC18LJ4STwinhG+Fb4TvhtHBGOCt8L5wDXf9ROC\/8JFwQLuIj+Av8JT6Kv8LHFKuoiRbRKqaINtEuOkSn6BLdYqqYJqaLXtEn+sWAmKGkKDbFrpiVk8op5RvlW+U75bRyRjmrfK+cU39Tr6q\/q3+of6p\/qTXqNbVWjalxIzJiIxGDYqYYEsNilpgt5oi5YoQPKQ7FKc4W54gPiA+Kc8V54nxxgbhQXCRWiIvFJeJD4lJxmbhcfFh8RHxUfExcgY6gk+JK9KX4uPiEuAqs15NgxZ4SnxbXiuvE9eIz4rPic+go+godQyfQF+hr8XnxBfFFcYO4UXxJfFl8RdwkvipuFivFLeJWcZtYJW5XXIpb8SipSpqSrngVn+JXAkqGElQylZASVrKUbO4R7lHpFm661E5qL3WQOkq3clOkTlJnqYvUVeomFUvdpR5ST6mX1FvqI\/WV+kn9pQHSQKlEGiTdJg2WSqXbpSFSGbdCyVFylYjSQGmoNFIaK3nKD8qPynnlJ+WC0kRpquRLD0lLpWXSculh6RHpUekxaYW0UnpcekJaJa2WnpTWSGuN1MgZeeTFl\/Bl\/DM+jn\/Bv+Ir+Cr+Hf+B\/8R\/4QiuwddwLY7hBhBbIYIJIZRwhCcCEYlEZGLADYlCVGIkJmImGrEQK0khNtyI2IkDN8Z5xElcxE08JJWkkXTiJT6I0ZZAvJGBm+CmJIjzSSYJkTDJItkkh+SSiFKgNFOOKceVr5WLyiXlsvKz9C5pQBqSRqQxySNNSFOSTwpIM9KctJDek94n08l9ZAaZSe4ns8hsMoc8QB4kc8k86QMynyyQPpQ+kg5IH0sHpUPSJ9Kn0mHpM+lz6Yj0hfSldFT6SjomHZe+lk5IJ6VT0jfSt9J30mnpjHRW+l46J\/0onZd+ki5IF6VL0mXpZ+kX6VfpivSbdFX6XfpD+lP6iywki3iNt0g10jXeyqdItVKMt\/F23sE7pbiMZCwT3sW7ZSpzMi8LsihLsiwbZEVWeQ+fyqfx6byX98lG2SSbZY338wE+gw\/KFtkqp8g22S47ZKfskt2yR06V0+R02Sv7ZL8ckDPkoFGQQ3JYzpKz5Rw5V47IDfhMPiQ3lBvJjeU8uYncVM6XC+RmcnO5hdxSLpRb8WE+S24tF8k3yTfLbeSo3Fa+RW4nt5c7yB2VX5Rf5VvlTkbRKBllo8GoGFW5s9xF7ip3k4vl7nIPuafcS+4t95H7yv3k\/vIAeaDRaDQZzUZNLpEHybfJg+VS+XZ5iFwmD5XvkIfJw+UR8kh5lDxaHqNckcfK4+Q75fHyXfIEeaJcLk+SJ8tT5LvlqeQhspQsI8vJw+QR8ih5jKwgK5XfyOPkCbKKrCZPkjXkKfI0WSvfo1xVflf+UP4kPykvKM8rLyoblI3KS8rLyit8vvIXuUgu0Tn0QTqPLqCL6EN0GX2UrqCr6FOQAzxPN9KX6Sa6mW6h2+lO+jp9k75N36cHyGX6Cf2cHqVf02\/oGfoDvUAv0Z\/Jz+QX8iu5Qn4jV8nv5A++JV\/It1I2Ka8qm5Ua5ZpSq8SUuIrIn+QvUkOukVoSI3GKKKaEUsqRnyjPZ\/MN+NZ8EX8zH4W7b+Hb8x35TnwXvjvfm+\/PD6I+\/nb+Dn4kP5a\/i5\/ET6VZ\/HT+foiLHuDn8vP5hXwFv4Rfyi+HGOkxfiX\/BL+aX0Mj\/NP8Ov45fgP\/Cl\/JV\/E7+F38bv4N\/i3IbD7kD\/Kf0Ib8Yf4L\/hh\/kv+ONuG\/58\/zl\/hf+d\/5Gj4OeY8IMbxZsAgpgpOeF9xCOmRBfojoM4RMISxkC7lCA6GRkEebCU2FAqElZEg3Q7R\/i9CeSkIHoaNwq9BJ6Cx0EboK3YRiobvQQ+gp9BJ6C32EvkI\/ob8wQBgolAiD4MxtyhZlWx1\/qIEqVE3wRxgslAnDhdHCGGW7SlRBNagm1ao6VI\/qVTPUsJqt5qoN1Dy1QG2pFqlRtb3aSe2m9lT7qgPVwWqZOlwdrY5V71ROGF1GN\/4an8An8Sn8Df5WjhuQARuIgRo4A28QDKJBMsgGg0ExqAajwWQwGzSDxWA1pBhs+Dt8mrvK\/c79wf3J\/cXVKB8rB5VDyifKp8ph5TPlc+WI8oXypXKUnCM\/kB\/JeeVttAVtJRXC27gAbUc70Fv4DNqGqtB+5R30AHoTLaDdIe\/sDTlUL\/wQXqq8S\/vR\/nQAHUj70L6GmCGuIPQb\/l7BCsEtFKpwZC93P9qjgLtVREVTLOrH6kH1kPoJWax8hVahC2gfeh49gtugZbgtnoofxo\/gR\/E9qBrPUGRhinC3cA95R9mp7FJ2K3uU15V\/KW8oe5U3ybvkPfI++YB8SD4iB8jH5CA5RD4hn5LD5AQ5SU6Rb8i35DtympwhZ8n3gM6bAI19+L58P+qjfhqgGYDJYfxwfgTgtAffk+8FKB3Cl\/FDAbld+W58MWBtP\/82\/w7g7SP+AP8xYHcyP4W\/G1A8gZ\/Il9Msmk1zaC6g+T5+Bj8TkLwI8LwA8LwY8D2LRmgDQPXDtCFtRBvTPNqENqX5tABQeoX\/jb8KiP2Jv8BfBJxqgFQreyfg1CuMBayOE+6k5+mPsPwEuGwLyGwHSD\/Ff8N\/C+jNAQxnAYYjfEchT2gCmA4BnhsCilsLRcJNfA6fQ5vR5vRXegUyEgElSgrwAdeGEPm3+BtOUo4XREk2KKrRZNYs1hSb3eF0uT2paelenz+QEcwMhbOyc3IjDRo2apzXpGl+QbPmLVoWtmpddNPNbaJtb2nXvkPHWzt17tK1W3H3Hj179e7Tt1\/\/AQNLBt02uPT2IWVD0R3Dho8YOWr0mLHj7hx\/14SJ5ZMmT7l76j33Tpt+34yZ98+aPeeBB+fOm79g4aKKxUseWrps+cOPPPrYipWPP7FqNVrz1NNr161\/5tnnnn\/hxQ0bX3qZvrLp1c2VW7Zuq9q+47Xqnbt273n9X2\/sfRO9tf\/td9597\/0PPvzowMcHD6FPPj382edHvkBHvzp2\/OsTJ\/+pofxTQ\/mnhvJPDeV\/qE78U0P5p4byTw3lnxrKPzWUf2oo\/9RQ\/qmh\/FND+aeG8k8N5Z8ayg01FH4XcsPi4V9Ebi6MXAjFv4flHNvGxsTPsfNsS36EWLw6uSC0AW3CYyCqfgPtw5cRiyB3AgreQ07UHq2BOPgxtAAJaBAcWYR6w5eH449hd7wKNYYImcJyAK4dAJHyLuTArvgPEDXPo4fhrnnIiDJQW9QTYu2HcLf43WgwOsk9iFqgbhCBT8Sz4wPjS+OPxJ8DXOyk78VrkYI8ENsPQwfiF\/kv48dRQ7hjBWDnJH5E3o6i8JbZcOVTELWvpqUcjo+K\/wUtCEDsfgBxqBgdwHtJBJ4+An2PXXgGbQdPeTZeGd8PV6WhUsgEVkNU2wzfSgL84Hhx\/ABywDvuhaeuQltBB3YAT15HX2GVvxx\/Ln4ZuVED1Bn6U4U+xntprHZOrA1wjAcu5aBCODMB\/QsykEMQPb9JJvAq3xQs4\/T4Z8iGmqB+0NoX4c6z+Hfw5eDN6Ttcx\/gtyAR8eZhxG70N0bwHoooeuD\/EChPI03QSkuCNTeA7HHKVRegJePoJiFt2QExykD7LvczVCOmxU3ETSCSMnoTs6U3IEVwQ00\/GD0Cs+h1pR4aAh\/mWPsZt5D4Vh0Kvb4eM5yH0MuQfVtwS98K34dF4Bl4A+rcKIv9D+BxpS\/qSceBrRtNy+jp3C3z7cJO5BwHji4VzsYGx\/bFPYr\/Hm8bno16AhznQ+hWQl1UBTg5CNHkUnUTfYh4yHRN8WXbRD98H3\/vBajyj5zpV8JZD+Fv8A0Rkv+EaiLwQRFypLGqCb5BMIveAl1wDms10+yfyJ3XSDNCqZrSIltAJ0KoFdDl8t9NvOA93EOL8pvBdya8Fr\/Eyv4+\/LKjiAxKSPrr2bG1u7YkYii2MrYxtjVXFv0F2kKEHuOBDRdD6ofAdC\/JeCYjbjA5DbuYCCeTim3E34MwQPBaX43uBk3Mhr3teb\/urkGkdgBzgErTZCDEfa3MjiNZuIT3gezsZQcrB0z9CqsgR8hcVwSuYqZ3m0ltpKR1Bp9BpdCWtpB+BN\/6WXqXX4BvnDJyPy+DCXIS7lRvC3c09zX3Pfc8PBvtzRjAI44X5kAH9LDYXbxZ7ir3EUojxd4ifSWXMRoOlfu36lBqfggihA92OlpJ8zg3W8WPA8xA0nBYTQCrZgBeSmbiKZPL3Cq1Ja9wdXebCwOt3yFqIA1rTYtwV90FjSZPE0wQb9xJsiri30AVuD\/TtY3jyvYKK7yeXBBVtxYgUwjvfpnlchH6IvqInscitR8c4A+SeF8iLtCeg4HXuZn4gCtA16FVajmei7aQDQoYaaQnguDt+CexCX9wU\/0HjiJLugKIW9DvI\/MeRL8FD3IMWosfxcG4UWory8QzI6F8Arcjh7wIbaMfvkzFcBUnBVYhwG6F3hZCzUt6G5uJSulq4RI5CJn+QM6AT9BVo\/UHyKi3mLvO98WjQgJloPiqPz0HT+IHcp3gUOO7+KMSdAus2gzblArCdBVZlMNi0HaDdu8AOtKXFcMQFyOkGuOgHFmI1fJ8AO8EBgsaAjg8AK\/YxqhL6kmo0ijdhsDoIcR\/GeqNB8RfQqvgodFf8EdQQ7MGC+Ax44gZ0Bi1DG\/C82H1oIvKC5pzA3fiO5CDfMd6QVJCjpA9ZeaN8gdshyOp\/hO+rsHMzvxtVcF+gPqhNfEn8c0B3NljYVegO1AVy9PHoIryhE92L8mPdyZZ4RzoR+nsS9Yq\/GPdhAxodvxP1QHvQ8yKPhooRkHEl\/hT6ex8aQXrHp9ARsTHAh2XAhShw626wP4ui7fr1bRttc\/NNRa1bFbZs0awgv2mTvMaNGjaI5OZkZ4VDmcGMgN\/nTU9L9bhdTofdlmK1aGaTUVUMsiQKPEcJRg06BDuW+SvDZZVcONipU0O2HxwKB4Zed6Cs0g+HOt54TaW\/TL\/Mf+OVUbhy5L9dGU1cGa2\/Emv+IlTUsIG\/Q9BfeaB90F+NB\/UaCPRD7YMl\/soLOl2s08t12gh0IAA3+Du4Rrf3V+Iyf4fKjlNHV3Qoaw+P26IY2gXbjTA0bIC2GBQgFaAqncGJW7DzZqwTxNmh1RaCJCM0qtITbN+h0h1sz1pQSUMdhg6v7NlrYIf2qYFAScMGlbjdsOAdlSh4S6U5ol+C2umvqRTaVYr6a\/xjWG\/QYv+WBnsrllRr6I6yiDo8OHzo4IGVdGgJe4clAu9tX+mcftr19y483Npu4ILrz6bSig6uMX62W1GxwF+5rtfA688G2LqkBJ4B95JQx7KKjvDqJcDErn388DYyr2RgJZ4Hr\/SznrBeJfo3ItiBHSkb66+Ug7cER1eMLQPReCoqUe9pga0eT3Rn\/BTydPBX9B0YDFS2SQ2WDG2ftsWGKnpP2+aO+t03nmnYYItmSTB2i8mcJFTj9cSI+nM6pV\/OqK696zmLWYuCnQEQlf5hfmjJwCD0qSVbjWiJKoa1hMvgU4LhrsrhIJExlXK7sgqtFTvO7q\/kQ1rQX\/EbAgQEL\/x045GhySNCSPsNMZLhpB5qcL6OroxEKnNzGUTEdiBTaOPN+n6zhg2mVpNgcKLmhw2wD\/UE3g4tadUY2B8IMAEvro6iO2CncnavgYl9P7ojdSuKNo6UVJIydmZv3Rl7P3Zmdt2Z+tvLgoDkKn1MzV4phev\/zJojpcPoVpXY8f9xekTifNc+wa69Bg30d6goS\/K2a98b9hLnW9afS1KVKe0G0lSSpEgq1c8CKAfXX8x2BqqVXAj+BB3Uw6tFCVCpH8H+jpVaWafEusQQCPyXN1XHL7O79M3ftyWbWdkqcuN+6xv2b2ieWkGhweAqu\/YdVFFhuOEcQC3xws7JDSAe9R0Y8LerRP1AM0PwVx3f25ItJamVUWBZO3YB4C9xKLl7w4WpSboEPgydDRt0BENXUdEx6O9YUVYxtDo++46gXwtW7CT7yL6KiR3K6oBTHd+1OLWy45IS4NVo3AqUgqBbtgTxwl5bonhhn0EDd2oI+Rf2HbiVYNKu7JYSxkjSru\/A66Wnq0RJQ0ADwXqAy7NqvYhQwBKwhGCFweld89O916Ks9O3n9rIR2UF0G86CrIJH4agd8RTzFwmic\/x4OSZ4rFD+oiuiXS29gNpcwBZrYWGTvBTaLN9OFzY6kAd3Wn\/7LXYRnjIj1ouU8YeRhm6KGrLMGGlWUdK0apy\/Da01SbCNWsS1ptsR1SCfo\/QVy1NL9AfXXr2gXYWnF7UpapKHS3GYWApaNG+RL4jwtWsYn1zxcfGgPXOmZd0UjOBIrNce\/Ac2XfyqtuZQScXK3a\/HfDH\/De8fEVWzSbZGZIOGkVVmLTCspRi2VWgtvd0EuKrSNNIPiD+qzGadOF1lNOrET1GzwUD6mU0+EzG9Yk22MQKff2tnShBZCrLC8M13gMfUSO0cHIlk3JQ1fc6eQcUHY71Y7r9n58qKQZ\/W1H51MfZLTIJWRukw8jm00oXmR7tAzm1IxakGziCrbChcFBRMXMz7ioijktNqFMH3Mn+su2PwxjZOpBI2CDwk7Zrfhm1vCDxSnheq8YqokX8eRS0pBcjtngit7q5diRRfqT0NDa4tLSpsXGR1FsIfiFDfsk2TPFSa0sLhhC4IYvMWTkF0OMVwliBmNW8RjjZa2ykFP0xto+Y1mjX9pgn3turRpeXUKU3ncJuWtszZ3n7YioIGS3NNzRb267HwoS79ljVyMyy9FDuBH4QszoC6bzcA9F6GpvWMhjEtIgQbcBEyEAo7SGgptuoBEe4EiNfWAfLWKeufAE5fKb1yWrtQpBUB2GCtXdBqddA1ycsHyNlYy5q32HGg54Cmhc3pgQPli8PF7qG3wXvb4moylowHtDeIuieSiZQU42J4ZRARDz8RLnBzEx9iTDldqp1FjYsvQN\/LQYjNAva2JAdXb9\/OWr8LVgug9RSFoi7CGluUaOJmxK2D8+s4vZVXS3VtSDRq14EDB\/R5DfHvSSFIlqI+OxGNn9hqKyTV8RNRv63wcYoJXUs3U0KnImxjUyMwXGeg5xA5B7jcCC\/ntk2HJxdpVy5oCYwt4BtFSmdq+xnWIhE7zsd44\/LYQDf\/0182Nq+iX\/x7zsLvBbyn435bCDMFUYPHy\/E2r9HolKvj53RsMyLqZuCWLUhlR5BDVWGtsmOoMQD7AKwOQH9Yj1K3CP\/5pCvwJIE96SxoiU5cjLoVRWCP1NgRpKkqW7Nj9Y\/8+5lVgt+tpYHabSV+5V8QSjhgscJijp+K3sEJC8hCZaH5fRMvi4qLdEjpZu\/ibpfaN2WwfbC7d+o4cZwyLOVO+zh3Weo0co8wVZluXiA8Ia7U3nd9RY4IR5RjZk99cyfL0UCwIE\/GSNZkIi\/3WSYjsMhRExz1Q0BM0HLvu4sTSg36XFoeuZBsJi4tR6WoJftgWEpKUjRr8\/ymDocVlFsIZmSFUzRHftPmFi0czBCFfuMOr5u6dcotYw+v\/2zawzs3zpixceP9M7qUksOYwze9MmRbLP5VLBZ7a9MTr+GnYo9fugz5+tiLY+YzrJwEAdaA7Axoc9RPo0ZLwThuFllGVkncKxyWkcATKvNYJfgDg956A+sTwszOVcdP6dYLiB+jFl2gabpATbpAgctRNxNXnUx0+XhUPmo0F\/B1nMjjsZ+P8oR3K7twEZ6HEqpRHgG+RBIf2CkqrgVFbMOMRiHjDyqNBIIWQRCbgRbmk5qqtof7Pv5t4yncfTfP8L166wdDWN+KAMsi9M2L301iSbZoRldKitDPyKBksejExaisaUB5bbyXQdTJLvB62VlvmgnOeFXWcm812R1VicHp9Ps0CyF+H1iDxp8dYOsDqPEF1tI2bL2\/KQMvqX+harUS\/YVR2Wwhde85FVWsKaSf18aOsWdvhUczVVEU0s\/JrL\/Oxf\/pbQzP7H3sbfrLos1b862F3fwbwm7xXen9NLGzWqL2NY1Th5umW6enLLLusZ7xnEm97FHfUF5LIalampaueTXhX\/HLSATwS7CVQVoer0GTBOGDNI8tLc0jpXnAWkieNGr0atXkuW09LNhSjV3bWQ+Qzg4zJqphsvMwcJthHe8mc5AfabhlVLVsb0OGkAlkFuHILpKJfHjZlgTYwa5cjTDzwvxBUZsLtaWnLXXuYIGpUcQEpiZhaVGdBrREpbh0UklJyB4ItwCJN2\/erACgrxth0Aswx+CgBZETr7UgztCzqy9tWHXfA2vwzpQ\/Pjl8tdOL+54Z7N20qW3RsL337z8zctyjaypSDh79cdPAl\/Y8t3BoE0BK\/\/hZzgFIieCSpOAUtyvK+O9KQ5hBNaLCDs4JGoxm1ew1GHLs3jTOm5PG5xiDRtXlBvfu1xj4\/WKYSZFdHm7MrM+BxuyLrIVt2oATuQDyu\/CO9o61UNsfacoWJr9s3ugwdjDON3IdLAMsU1Npb8ed2ljbcMfdxmm2+cYK26LU540G3k913LDpapyI4b2YiSUKHdiNWQHRiJtVqaqdc+0izyE3GR3Nglby0EyjdfIQ\/wQ\/8bsYkv2zxclh3TaFMQprYQItvvIaOxNe3tBVjVtudR\/Gu3BLcCR7o8rf1qpBNX5kS53B0qXIbNaVSGnCbtWeZuAEP8nkmRAnqCoIELQVl5eAe2c2Sxec2KKerJMhE6LI1iiYEe5f5VsxbtbmZ2bmd7NZlcnV88eOWWKrCvz46r0fjBs5\/IHlsXNH3ozjB12rFlQ+MGO97Wly78xhD8yd69\/+7qitw4esaeR9fene2G9nodEesAEaRJQGYE442tw6UB2trlY3qu+rfDfazfgYR62AcaQKVOQNChWRCsr+AeVslHLUiIhqhDhnN9mNJAhk10UNiOPgEvSBgasmI1\/jeUM03VdgqLOEhoRj0omLuocyVOMWUaMYzQgWiLMDzcTlZsLgpBhtBYhoxE8oYTeze4A4vYPdQ7abqvESndM\/gfXTDeEVZl6KtLOabge1K0VXiyyFhXoUvKBRhAOVMZvNwG7IZ3YiI\/h8ayGYnM+iSn4hzWhYSLn09CL2iBIQBlwTtalRpVCd3bNQjYYL1Yw02DYs1K1tCQTnzXC+Jd8etFALJitr55KnHn3nnapYMzzkebrjWpfnY+tBqVfUjgPgMd8f4F8AG9s\/oTk7EYb+GVmHcJrJ4LXb06zMVChmjvOmGU0YiS7wF3pEoBO6ljGbxrSE4QhAVLsfNIMpRo5Vt71mfd3VMy29In1lyospb6lH1GOpkpziMuV6qJzH5ym7wI5R0A4txWC3pqR8YDLbTCk2k9kIKhJNYQ2JmtZBIG0yR+042ajXzBw+zNQHrFrUz5pnGaJN0GZpyzROAyVx6UriwsiluYirTklcy\/3WPbgZMuMVAKqWW03b\/ydl8d2oLH+rSymLKEFH9I6WWmABs3B6gdQowoMUkW74dJuHyyHaukFtQFdSAvYABX1BdpsIkUC43+v2VXc+ULVpyYAl2RuXkqO1r\/WY+\/BeLE156Mp7tXi2VrF4\/zOrt\/Zo4yA\/vxKbOjh29ZN3H956ikVtxSA5O9i8dJSLeyStns+MfXgIpjg12xs1YqMRXFUqn+G1GQ1ejEIac2J6BKd5nRqToFO3eU49gnMmw60Dnx3Q3q6TZOkFbX8pk2TDcW7cXoza27vb+wdZ+\/rH0eHicGmsdbh\/inR32jxpftoR6TOHRfQzFmcldELoF9QNHqMC+gmRncjyB\/0BdsLCWtnTSKCdqfjwECZIMHpyXZshnm0ZtaLtocmaLkjIwTTQUujF5ddYRKItb2BgkvPiwqijjXOIc4JzlpNzOtg5p4O9zllNMrdFEkEaaOKFeiEmLZ5u6aCPSYkx9WHWrgRD7qKHZpDMgLCszEEFM5BFa8FMHbZdJ1Jas83VoPO4\/m373UHa7hlVVXvPobnfxE4\/tejcpq9rW\/RY2n3Sc8\/cN\/0lro9pbF5x3s0Xjw8ri\/3+acWF+3FXPANvfHPDvmtfl75UUv30E5s3AwOGgr1z8C8iI5oYNe03Yg7+iMTJYMuYFuYRzMmqcTKlhLGkh+6iKfGYpcnyedQDZD+E0DawmYBnQfDoNiVRDClcaXlR8ZUL3bWrLBpjmQHz3oWWwoSrBrCyDEZAVBCDza3WFkPp9iWxC12bm3fSB35dxP21acmKmDVWU31sE\/4Rv7uGVQP6AALdgEAnCqI8ghIYrFJRqrcRs5EQh5F+jRpZA16Bz\/ZajV5ZZWBjWcAOPYuImFn+zGBorgucGKGfNLtoXXJN666i9fClmXaVXW7Xn2jX4Wv\/O1u4MRVhEdcFVmxIZiSv6Q0R6hoiJBpyWs9MzHU2PPl+dgyIa9EMdpC9lt1p182ZXe\/p3\/2rexm8CzdONqBuYRrUopkD5zg6OzqHz6o\/5PFyHp6JZuIZ3BSpXJmk3m2c7lyMKvASbr40R5mrzjc+5PzI8k6KNQM0ZWua38M2fn9jtmnoDzP18eb4VeR1IRWasa4Rvo7Tk9+QsVxNRkW1yGRz1A+6Y8bIrJmJuRo\/vKOpa3IlpM5wfmvmZHt9SmOP2ol9eZP6lOYK6P6VhMm7kOxbqd65ROlG1xjdzpVOKkflJSU4HG5WkAzn6iIBBEdSbNdpy\/Wqg8dOvPPsG3t\/HDd+wUOxq0ePxq4+fMf8caPnLRo5amGrzsv7zNmw6YFZL9LUnCfGrvvq5LqRj+c02L9wTxxhvHfZm7jv6LkPDhm2YO61ePHyHi\/MfuClDXW5LMOkF6ziq0l5Kz5wASELOICrukCZJ9Ctk4ulONlMoi6LLlKLnulYXJYGESXbyyo3PUzUZLKhnhjrYaRRg6wCM0+TwYJoxpX9kdKmuhFpqjMGpM3gpzEr+vXb9ZnEdY3423dGc3XnadFR\/L+89cZ3\/durGl\/\/omhBK083RzR4m2NAcCS90zHeMyo43TPTu8Sz2LvasdGzx\/Oj46z\/qj\/lJsfTjk0O2ipnuECymN8NAphcAb\/gz\/b2MA1hTjaNvRIf7pkwyVWsEb5duBApYJEtN7rV5Q2Yna5iZtpSjyVL1EIsyyPvXh9tMihduN531pldVFqOS0uSnvJm0qwgi1lb2CIAk9Wip8xhrEPGrmNp4ibHjKF9ZvZsjpvvHr\/jGhbfWXbhvuk\/P\/PKV+TD56fcu3XjjJnrcR9t+l3dZn05UXX1H4elL09ibXXsu9gvse9j2159gxY8uWP\/miVgcgEzOyH9mc+F9fpmS4gjeCSIMhGKOFqEBc5AiiCuQYRlzOulZG2pnNlPyAZ0OSQqmayQCcvOAwcO0JIDB669eOAAIvFahPgSiF9FZMKjdmCTWdMDxV+qksQfOhAJs2wlulHSDQyvrxtredooabRcpi2ky7X3+XeEvdplTZH4Etyf9NRGK5Xar+qvxl9NMqdyRs5EFYPMcxxkF5IgiirQkqCKGEEm\/0fUrGf2flG1wSlCKTtmZ8eon1NtcJfs5XnJK1ChmkyMykhSf4iy+ZC7sAIKp0Stqh+NEGnvntxB7iRHl3OYq8Y4qvRU94onVbpcxSrb18ziQZHMEmeLRHzUfOSLBLfcsMCfCzjmcWuAAlebIs+FNqeLWIXuAqtPRSB2WtDIpW91pkJ0vEDbv9+0f\/8CPrEFtHStVPp0rfT2GjSwijNTSdwFiS+K\/8FAVIInlZcm6g1BnI+DNEBTApSVICnJ\/4QM\/Prl2ifXH8U\/r+qYkZbP7\/qrI94Ta08G4ZU773loMfNmK8Hz\/gCSsugRVcpOxIFMbmV1KI7rGOwfHBmcLM+VhTGeu\/mJ8mTlQf5BRchyyNSVlet1pMtyitWbm5uTg9LSvcA3n9drQZIrLKjMhQmQV0TzmdoLVqbygsA4L0js6YIua8HGcCD0DYXVNHaHamDXqQwXdnaV6mmQ7vXrZRt\/smZzVbcjOpGs1\/xVpQs5QQiJCo5Br9qURloPdtVXZErB83fXd4ovXEkWaZLZPCygmkWQphQ2thSyPDCRBrKKTb4lcF2eZyJBHGiaSOXDQUg6mrZgusvolSS84cPJI0fNWzZg9ptLYo\/im+a07NK14wNPx47h8beH2w1q1XfFktgmflfJzhG3v5CftWf2qC1lTWhvi2NkcecJOTXrRLXluI69pzVhVaCR8e\/5qfxhkMrh7cPI2HSCE8GC3r9z0SGM8qOmxmFoIpqSPhvNTV+OVvMv0+eNO2mV8V3jIXQ6\/dd0i8mabklPp7lCtiU3ze+71djfNsDe3z2aH5d+n3WxdTVdZVqdtgE\/RzZYPjelIBvyaDbNw7HC69bsQt34N8wu1MwIc6kpXpWmejlZC5u7oLAfrLTH5wz7JSyprDWS2ztscKJsXlrMIi5YJyNOi85MkACrEEKwOQk7BS6YkQmMs2bmN+WcYpiZOWK3WZmh46r23RR768yF2BdPbsbt9h3HDVq\/kb\/v0Y3fDR5\/dv6z3xLS5FLNm\/iuT8\/gfltOfdhw3SPPxC49vDv2Q8UeZteeBtszCBBtBt6diTb2+3A7KYFOi+Y1IwmaLGOfXiaRdVDJBr3O69KP6NDTTZLHl67919D7vQ56f9RBz\/vv0EvSpX9Drkleu2nR5jRVlASJlziJE9wuj4sIiVmNVLA7bI4UBxVSqTOArSZYuaS0AHYYLAEEXIxEcuEzB5cyhDodTgcE7ATwGQo0TdaaIJoPPI3\/fHnQ\/SVTJnef\/vCBebEtuPDh55t0KH78zu6bYh\/xu+zp3e6IHdz\/Yiy2cWjTTc2bdPjhhbO\/53qh18+AZWBz5RS0ImoXeK8kiSKiHGOkQfYqSBIZOtI1a4HYl3bxG\/xGYvAYOfn\/h7qqrW9LACjJtGJdYUuLr5yO\/LueNsmDXtsDyeUZLvPa0zRy7XM6l9+1KdbmlZhxE9MiCI64edAHGT0Ujeh9WCbi+m5AF9b4iV8hxKP8F+2OKom6f1IJY\/\/RfEPrwdc1\/7r2n06kHcz7\/3vbN9Cvr50hlbU9WbtbbaodCW0YD7q\/E3Q\/hFOinlRbqp2UZeHbpRRspZmZKGB1khDyEl05\/awNGAtOr4lCHCxjHM4KZfophX5llellmtN6T3Tvm6zXfKVLQPe+qex+Mml2Fs5KD\/sN2KCHggZ3eNht9apcrJVeTfYHGs9Sx\/oEo0jfT9TNCllCBYBuzwVT0zxp7jQqqGEtZA\/7wlKICwdDLmN6ADnMKQG42JbiF2Evgw8FcJoCyLZZYOWVAwGUSWGF9KQ0wgZ0iiJ1H4Z1VIqbhSw3WA+HU2xEwHyw0U6blQMD0sJCu5Hxy2KH1n0ZW1u1Dfc8thbjR8KbA3fsmDBv3z2Blgswefj+yzeTNq\/g2lOTJu\/Et395BE+uGlX9WN7E2cW95vZYuHZ\/7I\/ZQ1tgC8jjObAoGbomfMmqVHujnhR7AUe9smGd4ZCBGHhCFAk02C+KAqug6R4P+M1KAEDpxQaBpS4u3fNh3fOVzma\/dlH8yTGJvVEDPPS\/gJ+UhN91FseR1B6\/EfuNPY1lxolGrnWJC3L++sGIhAVKyDFSpJfjQJsgs9HNEAYnB5CEJQjr5\/aRv\/btqxX4XbUvkEF\/dSTbaouhjW+AQs0BLlD00XamO4QNhmxreZM+KLItvyCxbZiX2GbnJLbBUGKb7k1sXZ7EIEquUSvw88v5zTxgFYK1ZWgdqkRcYxRFPdFJdBnxVj8cXI4on6g8Mi64ktz5qY47F+u4czWqJSI9nTvPcEdKrjO+7QYP3DobwrnSkvJJRbWldSxhJUmmivmWN\/ax0Aj6CNEQ35tJGseiXprRolCSW2UZmgnNDbcaBtD59AsqTjUcpUfBODPt0V1GNr+Eq+Bf4n6UeAOHm3FHOCIzYcvWQAH1sxU4021qoZUd3Qb7UnLLsW26vt27zepgx09Eb3LDO0OhmyTZ7b4JIC0bZMnAU47z8wYbz8MewEyAaFYwGBBPOExERUKSgRIFI66atIqa83i8jq\/k9\/KneI7vIrFjSp6I\/RCdVopUrCbzo6ri\/3810r\/8baQ3sPA2yVvIa8ovsMyAaWoRg1VREVvAOrAAl42KwNal13pFSSuSiiCcdUE4mwrhLIs2v2xZkkhY2c7lbaqF8ety1AmEoJksBZJm0gpkRhk0wAxKvLdEjyf0D6sLW+QM4FsDdyHHlozUQgDNiR0OIB2FAmOrYi2UMmyFXNRWyNi8PQSkvTDy96eEPRiXTyqNIBZQM1TgAIY\/0bJyH\/kSi7WryANxVHv1MqhFDvmi9tVrT5CzP8a4BGq4XH3+x\/ioiglYBh5JfpYqkBejZpHQ\/9olXv2PMEL4jzDibGnCFyagG7BD8z4F+P66CV7xBEKCGVqikdN1dW0JdEO3HJLJaNGtPigNEDwbQsxmlGplp3mzSmWEiSQrJiTJxKAIrL2KxtqoQBt3sKsUDbHBgmRP\/qjrybWqGwbDWQmqzd692qFDe9l4SiSSkBaqGxz3ibqeCvqa6mtOX\/P6WmJoCzKK6M4WHAnzUqa\/M0WDvhbrEkmJMcynDwXxWPUbrAVmfcWrFGEThCoSxCys4+xpOqE\/ZDfpj6zAq\/5RY9KrC3Xs1x+LWEErcqUxYF03l0WJzpT+jb1IAo6p0VmImCUbSZW4qep89T1gpdpZ7WymOVzI2MA0kN7GTTXea1pglBTCS4XG5qYepCttL0alYuMtJsMTZBVdKa6UNtAXRcFKzCZTHk9A24mkGo15vASkpPY298ZRSE0l9q8fwB6aTBqTU5l1tpVYd5ENyIibbOX9UjVuEjWossEfVWcpWNkFnTRhBc6QakhoZTMA0TxRw1o16f+any\/jZ\/NgYsmGbRbmMtxsBklpkQtwpuesQHvqd06XQgYLbNCu+3ogr2WKvmCmnsjCpkke+jthfR2p8RrA4BFE4kf0fLVrpQrnsnXtN8b\/2GIysKPJAaDPdgQKTQ0C+iDQjhaFpqYtdHJ7QziaHOiJlEDGCzrKaicAf+xwNm+BA+C4cBBbnsCZ+LY8h7sZHoL53bH+m2MD+V01vzzcqeeT9NpfHbkPa5pxp2qYMq4BS+9jkSGeucWq1PlfyaU69IrruWiAURIB7yRKYG4lIlIqyRwhsihx1C8IfJ0f4utdPZ\/QJHDOUY8O51K\/gv1KT6VMmajMVnhFgihTd\/ZGeNl\/F25y\/+nv68PN65xcpDSie\/jyKzd4eCsrXBYWLuB0CdUZWho\/9RrYV8kPK6QbUxZsgQyqpGjHQuj+3h0dC6Vo0wTZtFAE68pSwh1uIJsmSHY0mJihowQLRZMNlhS2f2VHCpDpCTIdSDsj\/9hSb27xdaoDIszHLO7AljXvUrLr3WsxENgcbhYIa3bNbJbPDYNo+Gv+M2RCqeiDaE+PGds0my3VmZrKcRpnU5xKKrfRucP0jok6na5U4k+PWnqk9HBGPQP5gfIArZ9lSMog5xBXf8+A1MXOVURzeym1ehXZHvZDMsDSaiYEsS6aEFkFnLFeZEVLxn2xrnIqMrEEdNPjmZ2O081hJkPhOtPhTqvLgRNJcGmd5S6+YZYMJMIpGgo05VjKpseyLTSU3xRZCggkwmgYXoibf4g7vlwV2\/HGwdiuDe\/h9C+O4dRpPzz8cewL8gEej5\/aF3v++MnYuu3v4UH\/iv0eO4gLcOo2rDwaO5PIgblaQLcRudDWaIMRlnE20lXrartNu83GKaoXLAxyuhI5kDUs6VUXSUva3mRWIHn8Hgx\/Hpfx\/zU1+s\/Mzn29G0tWYspLE7WY+uQoEYtCiK8ntF4CvAkELEDX57Ik55HiOx8puRh7P7YQ37fn6dJuTebGFvG7TNYRO8bvjtXWvkLxklmDH7QbGXIGxpfyFwE5dpSNR0dXDAmvDRO3q4WdKGmcj2UpNp8tKOTyDZ2RcGu+yNkq3I3v5uwcLuX7BQeGJ\/D30en8ErqEX4FW0+fQy\/Rz9LnjDDrjPOPypPERlMu35rlS\/hHXyvDnYS7kyA0XOArDnV2d0zr4OgS7hvtLAy397IPSBqX39w3wD8gYw4+0jwvfF16atjR8zHU87FZc2A7WbWtqIWKD3i1TCzmXzZXLt+I5Qh3ZVMwOuxw8EgI0xcMTtoP4TK\/XTImU6RVlTzjFxSSRUofcFH0Kh6oTl3XkptQhlxHREJNKShfi8efOziW5gTBYJ0XPSRQdvYo759\/RW3ylvk52oY1eyEnmes5CZMnX3tfeL01WdtAkZpPLJ4USUyCvy88YxuFo8yS4LQzpLcJZ3G8LJhU+\/dSzb78b27O5End4nwH+rtqzG8a\/DDg\/GvsWpx4fPfi2EU+VRhYU3nfbXjz4q6N4+K43Y89\/tT128qHGpWtw4VZseDT2RQwujn2c1doNMl8Pdn0TIN+FMvC1aMCqmLC1edog30hpvI+T9clckr4W9XUmGDidZfrUKkaodYRSR1ir499us3oKYHt5W0ZWgYXtp2cVaMmtObmF819uSw8nzsP1WnLLzkc7AxEydUnr4u+jDE4bnzZJvtc0zTzPsND8uHGjudp8zvS9WYMIx28x2ywWs8WsytZUEvA4DIKVzcbiXbLscHrcXidzH\/rkQacTBTJ0HXYBDkySN2xaI9RNWxTq1FNPPDP0FFTQi62l\/syJmbMzaWaG67\/Va+F\/9UFBlgz8W8kjafTcp12s1MWChKR+R+BcUWFjfdZUYtIUXz8\/87oPSuZsUYMUNReatVYWayvmKnC5HiWYwON43IUW8ElWWEzRtEINQnstwwdLvZMpua5s63Q4U4K0EQETEtTNiT4SF1hPKvZ\/NP2Dw8XZ\/brFr+zrd9eAhoGu3+D181Z2f\/zZWB6\/q8d709YcSQ9ldr87Vo6bzF3SUhFr76b5LabdOlqfhTg4\/j13nj+M8og9mjWMDuMm0ykcF8pqRgvT2tHOYrf0Dr72mR2z+tAScXD6gOxFKaYgK8MwfmfWEaE6IlxHZNURQV0UiYsTRKiOCNcRWSz37ciobGM4k2TSrFBzc0GwfahD40H+\/sF+oTuVscZxppG2Ea5pynTjdPNM7e7MyaH5tEJZZKwwP6TNy3ww9IhxpXml3ZuMzhsGwtbUsEcO5+AwQjkeK9e0SRiNAOUyNpyWuiiVpIYcxoberBAO8Q6eGZbE6I23oez1Oqju5yJgI0oTpSG2KdXnVTW+kPimRhuGMk1GhQ+kpXtTJVHgKBFwKDMDjgm8N7WhJ8pgtwx8zwUHaqgXuvTISsN+3BOX4Yl4ORZwNa6MpjRkr2SvhhZ3kcMoB+cwt20ykX45rGlGdl+Opyn0CYetLGRjp6x1ILfWDxJZ+zJdcDdJFr5Ki08zs6dd0EcM\/i5la7WlkdNsdYX1yMLmgRfqowUlbDJ4+d8oBluY0sJL8psmK7GZWfpAsT5pLFnvttucDs6pg5TZy\/Dg14xD3ps54aU+PQe3jt3Za8yo+3957Nk\/5\/O7zJs2Vq4vbImPDpw9fX7NU+\/Gfl2Fv9DuemjALZPbdxgVdA6NtHh2xIQ3h4\/5aI5p8dI5t\/XIzx+X3Xr71LsPTp7yA0NqHsQDu\/TxuEVRI0+8wHCk\/yxNriaTt\/kTo1qvCX5MGrMhcoy342Rd6lxU0c2DlLQNv9Slqt\/WGYlrdUYhlkia2BOlHauuz1qBnRCRni49q+kz0xO1bzZhi1VASUosnauIpfLGTZv++pW1dj1EfKzeZkNHo4aweSA3UHpf4hwMBg6Imwu41lJHros01fwCf84sqohYqsnuKkG2hUldTE7qY3KiJYudp6JpekpZ6ndgv6Ong5Q5JjpmO6jDqBc+61IAgz85JS5hDg11SDHUm0MDl0wjE+bQUG8ODaV2FpL\/bQ4jpax4WlquMyIRAeoRTgSV4nxLMvJrBuFvYn6AhSvbNzxW89nHsb8m7rt108wjO\/hd17Z8Hbv27FJs\/IH2uLb1je137NPnvyMZ\/FxHNkMQ35ycBWXlMZL0iM6AeFniMeEbf31A+\/qAJT8feN5Gn\/CSGs1szONclE1DhsZqnlqmLpIWycvVveplVfGrPVXCEUUiySkEMlYheYZHtmmjj07C3QZZ9ku8TZJ4BBAhvI0QXoZX\/eA3QDY6QsIjiKQX7LILe0p4trRcgn2Mo0YSzS4cQvAyspYQwo5Y\/HxPnuRBBrqc38tf5nnIQhduU8o2JLLQcjabmi0uLTGj3+O+4ErM6k8OmrIx00SmaYNscisygyR+3ipbMdtAMg5hUWKqBks6s+Gy5nrSifSfF+mBOJv0FMD5iRwyH5O2te99imc28mU0xEveqd0HmcgXsyfeey+X81dHxnM3QuJUFlvgY9FwDgpbcqxhVyFqbim0Nnd1RrdaOltvdQ1EAywDrQNc2hPSE+YkI6P5Gva4I\/YCvkBtz7dXu9r78n3V2+zD+eHqOPsUfop6n93M21m1wiqBqhFdjm3a6FJz6taTMd9LOZ4nggjMNwASZaPJbFZtKVYr+\/+PLggli7bxyOVnW9VqYdvoIDuknIgnBPJOG8bIxUuS1+6y2e0uqyrLXrsVSKtFNZv9msWmaRarrEouO2+2aKBX0CSeujSzWZYliUCbXFarxYIkj9Pp0drKuBfyIxXWdliiiMe9dvjZsKDbXY0Xb0kEBqUed3Gtx1Vb63HXurp3GNH+bH1MUFdCYPEAG\/quWyBdLb6+oHDjBjRpgUnbvx9WRfvrqOtXIGwzCNvCMGE1sOkvCQSE4GDu3whIFilMcGSbGuWjLROgmFQKgEhJACLFCpuUfBzEbEAd46dj9717MtPT0oCdP37aI5jW8Oxbsbt2xz7MEp222Pugq20eX3E+k56o9cR++nVxFX0VktjSJf4Rt9Y8y9LEpMaqeOwOSW5FudZydfz7bVYnK\/x+HzUBwblhRdlKZrGkS68VfxltDQSXDStrmMuRcg2NTdxoPFoYrZwQOJ6jVJBEWRBkgcoGlY1n+g2KzWBQBCrIlIUHDnaU+gkGZcWCqggYzD9Wqok7KhsMMiVgM0zVxBWVVbl31DDbQAzVeHvUqCiqH9HePcgyXWW3R2VAkK0uWowquktQk27g26RjIK4dRtO+AFPjyNVELYJNqapNbM4y618EtF5LA7EvaBSJSKDJvD4NglEL2OQHDVZdK50goDQ27UFSZZXbFb+CaPyKPnlG97ZYjxJlvfYLC1cdP7HFzQLAknovHLD8rd4W0rr2w59woGeHW27Had\/WvkbG0+JYxxkzJi\/Hm69tq32U6XgOeMpKXUrqFquJWTKz0VLQCd8qdZKpQVLkOpU2qchkxIpXBW30CqCttUVtavcnNTXyMgc8xpiTDZxkMITTAwXZBvwnuBk\/5kAPOUO2klaA2YpJeBtsOSbpFHYUbuG9okAUg1cFY74bb4d2ccD+VCTmSVEwqF3UNpC5eUwY8UIv5DYybwu6VnwFtIkNOBYVXykv0k5r1+pHTYsshXrZRf9RVDnTI5OWVJdJJfo8SL2OLpOMQCF2BQplViR3F5IMnZ8QTTfDzVswf43FgD2HXOrZ6drHnOfa+yV0QxV9eXiXTZuuiaM2QYjYJX6OS+NuRtmoBWkYbSAb5Vy30ZObY8zNLTQ2t7dIbZXbObfUWJo71jgmtyyvwjg\/Z7XjSc9Goz27boJDlv6LK0a94H4pe4d7d\/Z+98HsT+1fZ0vtHdjLojoLc7xW69+Thpox\/96PUT6nzxVpkFtQyBU26Mx1atBfKomMlMZEpqoL1PfVP41\/RiwtCkyY0xpnFjibBmyuITkTckhOWmNTG9My01pT3MSvNW02XTJRk5r8beOPdb92vBK1s9\/cmPRZcyaBzaozmdKos5q8tMO1wpaWJiJ2kUcPiDpkGZqmUSVnqDYUCbqShAKZLD5Jhv8\/JeKTTI7pTSYbp2VzOzNZ1sn6DsRxFnsBpb8osy7Syqwmt0VNWVH2Gwh\/OC+8OcwXsiyWxbWQFhzZoRNNCvUyozdYkFe4t5CsK8SFTta2tuyJzpAro3HmG8JBgfiENgIRTHrKqKuy4NJzRX2iqaAXdASTnjfqI8NCk5bX\/cAJguKIBnDSZxnXBz1FtZEzZ1isczpS9\/OKuuvLEylB3c8skJ746TPGUXmIBcF6iNxC\/zYryEpMHr+Z6DGzw263OZzBMBVEE0nMiIOLaNHwnWM377l1cqdm474ahfM7LJw1Lb3SddehRQtf6qnJzow9ac479k8Y3HT8mNHPhNMf7Nfx5Xnd53S3mYyezJDhroY3lZS7yhd3jQ7t0ujeyzXzbmqJv85O07KLG3cqu63HTfeA5vWMn6MXANEePCgZaRWYZpmxWcFsqHIiooizpimiK41TsMkuSoz9os5KUZ\/hKGqMlaLOgwOfvZPIIvaXNmULC8hulVXsS2uX0s7ZJ6WPsyylzPkkeZKuNj6nPedRJaPbMJaMoWP5u9WJxtnGF9Tt8g7DdlV1qPPV7wg1ZQwxTzDPMlMzBhBGp+Xp46dl0KzlaB06hS5DoGg2K+jvNqZB0zNNko7gjFToX6YS8YFdx2xaG0gbRxlCcCd9YoGHXYY7p9kzD4rYJ7YRiWjSK6IGdpGoK6DYJLVgfzLaZ+OAibkCk5I\/q9Z\/WNGy5MKkK5ELk+rmDVgKG2ulp+FPz5kgECvBzsRU8wL9F4P1+RETMi3akn7p1a9iv0\/6YdGm477N7lmDFr703NyxS\/E852sHcTo2vILJnM3rU8fd+dbhI\/seYJW\/jiCzk4lZbbhf9DkD4YwhY4GxvZFvZmuWNoD0NfS29UkbRYbzI+RhtrK0vb7P+M9TvnafSTlju+Q87z6TfsoX9zl8voinyFHk6eqZ6FvuExuRTGMjRyvSzNiVdDB2tHVOG2DobxxlPCN87\/gLXzFp2E5NimZGqcBrCzLYQf1d+Wz+qzmkaYcsWLNELWWW2RbOF2WYSExCsliZQbDoZo2poUVgCLLoY8sWPY1hHLeYGMctdWNXFpZ03KJP3p1izXxDPCieFOMix0TUQ6SiV4ecrsmiNwFFXWy64RJ1+yS6vQU9r59tU158ofbv9LW0XP\/xcNFpPWlhiz4vTne7bPwl0IxpK6hrQmBsuPT6Cc8tR+yf9fndYz97sGxl4221\/lfunvr8hvvuXT\/\/6SU1z67FtKJXW2L6qyOxfvTBm+989dF+JrOu4Dm8oGd2kFmfqNOH0uwQtZTypXI\/ZQQdx0+QRyiSPfFLc50Bp6O9GZWepv\/2wnqU\/8t21cM1sbZyN0lray32tE3rZR3s7p021DreMzTtXuFe+1Vy1aUhBzYbnc6eDpb\/UUeaebm2TiOaxqWmGUS0i7zEEKsbab3woDG+a6AdK1JAe5xRI9hlPSE01v1Yysg8BGOpkV0vZ+UWVBqx0eNjw\/qhcAHbRtsyQ+zDPke+lilGM3ML6iTlv05SabqkEgqWpstIn9nBJNXieklFimtPd9fKIb4qr08s2bSG5ATjotryouQM3eQURn1ku07FEgMNNjGg55w4oP\/mQ6C372pwcecPsUvYdvxzbMLXzhm2zhu2pPYr0ktt2X\/RjI24v\/PZKuzDFKs4O3Yi9qfm37xrNF4xv93oF8CKpIAIZ\/OHkRMbo16bjM3uxu48d9Q90f2kusa40Sh5jNnGSvdeN+dm\/Mj2+ArSJSNVzWkGbCcRWwpHBWRYa8O2eEqUc4Y4RMkjWB8s29akZYE+aBZJ8xUsR9gdZWrijhpBTZLhaLYeimYwxUENkgHpL8nipS1ZvGReXCfO6tPhWXlT\/z0Netbl3oN3oQC6ig2oLmqtUwM9foWwCnLQC6WJ4JX9+rPQkpjsZNMsgiwKEvhQTbamIotgTsURHMmdMwdHQE8m5VuCzfKbFbRghR8wa8yq2dlv1LauXZvieXBqt8GpLZv2bn\/wIF29pHxcQccB1qcMHf9Pe28CHkWV9Y2fWrq6q7o7vaSTdNbu7IEggRCIgUgaZJMoiywSBEEFFBBFQURFDOMCKu6jouPIMo4iOC8hiRjQecmM44YbM6\/ojCuO6LiMI+MgM4pJf79zqyo0DYjOO\/\/n\/zzfl8Cvzr237q26de+555577qnqmeet\/m4ORsTQzvHKZxgR7NV\/SWym2+0I9XIXh053Dw9pem5mbi93SahXYY17QGi0e0RosnOK+0L3t8bXaSm9C3uVDi4cXHp66R291vVyDsgf0KOu1wj3iPzhPSbmT+wx13l+\/vk9ZvZq7PVW6Sf5fyv8sjSQka6ltclbW8tyUp1iJvFHqY+YRxqpnXYTFBv5mlilIyfHZwwvyPEY6Wn9ivsZxeHw7gzJnxHLmJnRmKH2QpPLk3oJsZYhxFpGl1jLEGKNX1ASqZ+ZYo1z8QtLlljL4JdORot3mBb7pGIqiBTt9L3me98X96kRX51vLCY6MWJ8Wdy3vgLx0oyw65gv2\/mEbPNllvdanM\/irXxMgng7AIF2pITr2HeQ32vbZ7nn7zPNM5diUspgh0qhYpSaXvks5zL69wsIW11J4tsdc7a4K09dfM2qcIq0pOnt\/Rf\/\/tanr3pk9tvr\/vuz+x+5ZtnGX121dOOUrPHFlbOmVjfdItW+u0aSVq9p\/G7ev15bulnp+fv2nS8\/89wzvPZYSaSwx2VIOnc7pYPx0zKqxLuzQgErVvsrw5UdXlUkDczIrMpwBTyBkOKQyJfjcIbchqdYj\/UbUBXXpXZdShdzTHpMuLiWiWOIu0Bn1TMgnF2F6qlncT5drOjENwlC3CU6TzDiFTZ2jxXxg9uEA8YYYYjLqBpQ1ZS+P11emL4uvSk9nq6my6Fic3Pbjzrs5y86RME5e0kVO4LWsvHbWIYYpartzJawxf1tLF2MTFkMS1lYE8ekjRyXsHMo3qoX+9zlB8oTx6n4DAHPUwF+uctyRUzRUpzFKZonW\/K6MC6Jt55XEAa16fBmvsAbKAyIbtTSAitbl7cv+a\/61svnj7u11rGj46u7pj\/8YMcMef3Kqyfcdk3HUxiTq9BRtcILzkmvxM7RB\/ATjNXv0NfpTXq7\/r6+X3eSHtEX6o36Witprx7XjYgOHcupygrW6csl0hyaamjOYgepa9V1apParu5VtXZ1vyqTGlV3I6aq7IjC7aZ2tZsq2k01+K6qkGyqLdlU2wKr8iAyuA3VMa7k1rusVryKW2t9i8Z6qWn6ZZeWi1c50CqrWltb1c9fe+1Qmlpy6C3mSzyz8i\/2ipPPjWVrpg6hTdam6orP+w\/HQU3RbXd\/c8PMsAO6HRAeFWLDbZJyhSEHtWiqsG3sbwmWsq1jfyto0CES8kVC7HqkaKrqULVqfaTqKNZOMqYYVyiXG28pH2rORzSpUCtxFrtqtJP1Ou9Yb4PaoE1xNujXqFc67tef0\/6gvqHt0z51\/lP7xpUWNAwHf7yX\/el0rMcdustVbHrRKapabHrWGegYlY2d4udVwJlkqG2SL6Y7VLHOLHBxLD8qtGC\/6QRwByZ6dzHJxZKEiamOxoJD0A2xvoLHhesUmY6JoscoKDhdqM0kVHDK9Hg\/yB85J0FSsWA6wy92Hi49KHYeyg\/vo0ENy6jhRbxqO9axh53T76p11SriaJknvPW6FNGvV2Q97GUnD+jY5nvWMUPvlVuju3Jza9kzrjmXHeReb44KsjXfeptaeNhcSsK7bjtp8fbmfOEM0pzO5L1mv3CrAxExjyBb3baHDpsa+FbBd1XJFUrH3UKhWnHgbcnmMBf+69bsGmujpMFcB\/KWiel410+SCiUnOFHa9GnnPGnne53rr3Xs+O5pqalzSccsOXJV59nMl9fhUC3G4ofbHGIgChfT6pNNV9Oq\/ibt09ekBaYraqwYYtXniDjWOt53qGNx2O9QIo6FjkZH3KFCahmyYgoyvpIQaGmYwdeS1I7llJwo1f51WKrlJkg1s69NvcNlKR325kg8bm+XWGOUxqhHjlEepLyINt1TJRHjP26Z61qFo6o5V2gl0A0KpefZceqA7Qd3wP7CzB9jZ7i9VcXqPnWf\/kHGR1HHHsfBqJzhihbq4eyoriiFeTlaGk+dTkkrzMr0G7uLJf5NFbk4IyMrpfiOgBRQxcpEOBkEhMFCrExC4r098c0RftCALNYnHrE+EaaKgO0BErA96QJt0vSYJ1x8R7aULS6X3XW5bHG5bPZGDPDlssVskC0WmNk8lsQklO3hC2fbNpBsvl46yf0Ki6XdJPFaV44Qjz9FjL\/co8afsGdQujXTfGfrggdiITHlmF2RYg7JouI2aWlL\/shE\/cESntC8\/QkpXyRMQtM7hHn70stMH9g6cxAHMhJ941M8odSSkCeQLQW9afaEZKno\/O0CsT2YId4mFdOS0BcTJ6j1lY\/MW3JfZPmuhza1FE4bvPCnrVNmnb5ioFpyz5gZ503ZsWVbR6n884tmDLzn4Y775OalS8c9cGfHn2zd4mPwS7p0TSzVoWip8kZ\/m\/9D5S+p+5WDqZrKIrcWDHOlX1rj3x3eG46H1agrlBJKD0K3kLR0r+FN8aQUhYU+ERa6hVtoFW6hVbi7tAq3GATuApGDW1hoFW6hVSD+jdmhbqFVuFnrEOLQLRQXt4T\/7jFhHnRZrGGE94flheF14aZwe1gNK3K\/tHQxNg+2BgKW6+wxFQsjSbEIJCgWqjUS22PBZEVlTIZ4YbPrD6PwgFA2jkjFn\/mJrVp2ienSNtK1gG64DKehaP4SrOKzJZ8RtDqZX124lKWw6GXLnpXQxSs3XP7uzPXj\/EZrz\/mjFj2qlty3ZfjCMyqv6Vgk33jxgiF3vdwh3m0ahjVyKXrRS5nS\/G1pYcu15xMxyPgt8tgiDmWKE0GnkekZqY1yTdYaXBdoc12uKv\/A4MD0\/uHh\/vpgffrw8DTHNP1M\/\/Tg9PQzwwscC\/RZ\/gXBBemzwldIabrm8J6tTHRMNM72XKTMdsw2LvIYGTmqMwCRESrKFjp+tmADZ9eHlJzCaGEZvGwfJBGwvOfMV8stDzsRaI+lFhVX9XFK5PQ7o1gQ930fMoLTT+MlM8IpReRJ4eWdeIeQhE2NckT\/iqWyNWqF\/CHxFQSK4ZIsDmTqm8VLZ+sDdGbPYeE8\/eD0BJeTLs88tmsIK\/gExwT9PMd5uspzE2dJFZ9AIOuDCInK\/7CHb3r2bSn96s9veb\/zi+3NK29sbrlhZbOcKpXetqTzg45XPv+JlCd5X37p5d8\/+9IuVGhl51w1Hz0YpDzpvNhtHv9J\/lP89X61LtoUlSPRHp7C3Mq0ytyhuQujd0RdAzMGZo\/OGJ3d4DrbMy1jWvY813zPXP+CjPnZ7dH\/Cb0bfjfrf\/L2hfbl7Y3Go+mFarm\/PK2\/OtA\/Qh3tn+r\/yP15bqffHUhR0nNyWMqn56S4KSWzaLch+Y2YMdNoNNSo6MJozNri\/tjc1THC9pa3rdB1+U6b3zIzmNcKxfb3Yim1n9wvWEzUDi1IWic1SfslNSLVSWMlReJ5TkhjSUhjSUhjSXCIJGxSEg9mYXLkrGIBIAmTPkQkGx8zIyOrw1LipropiP0dB\/YdXs5ZryaL8WhZqZCLLk21hWp6Wki8UF0aUBJ6b+XDA++6cNXueZe\/f\/XU23sHHlmydPOjixdt7Zzr+PXN48evjq\/5ReehW04f2HFIefiV372056Vdb7IsvQFD8Tn0YYBejA2qSJX8qlSoVqmnqhPUOepiVdMDLt2le1MDupcUl+QWjU+GXnaHS3IVRFOlVLkgcPy1UpdW8a9YIEGkaYLlj5i7zOWSlqBOjgmO\/N1Ry6V9\/ukHLuN30Lh1auwP8JD\/xZUpwl17+mX8DqHZUKaNwgmRdMOGwXPrzj5n8NChg84J5akl6y8dNfDR0pF1My\/reJ1boS7+ibIVrdBHyYhdrRaECgbqo\/VhRZMLZhcs02\/Try96JHVzr98qXj0jK5zRp77XGxmObHmSLPsrJSM8zTVNn2ZMc0\/zTPPOc83T5xnz3PM887ytJa2lPnaWKeoxoGiq0eCeVTKrbHHh4qLGoruNBz13ld3X654+DxuPeX5R+nBZS8mzJellts5TYAcK7UCRHSgz1yFWHg4U2oEiO5DLnszBvJqprtJij6FmRUvSVHfv3Cw2hhRk9hL22sy6zLGZMzK3ZL6WqfkyI5mXZL6fqUYyb8+UM3+NvkkDXwjrYSzE2f3sru+XdmNJIfkl8b5eSyi9yrQqpgSqJKn3tNyLcuXcnDSnam77iKXex\/Zy7uNYKnewmtPbHcmSsooyY6nhqkouXiEsYGHzyOMqU3yTMDPKJTOjXCpTLFEyhQUxs00+u9lZ1BNFn8ip2d1T6sl34RI9bX\/BnqbvqMaBz8S3QHpmiVvll\/asmlnZXinXVTZWypVsCS2isKlZCZaLmq0MIcIBrkBUfLGEKxEt8omh7hPV80WFuYbn46j4\/ol4o8My3BS8by+gMvta5s7pl3a5nwJ+kMvGWNtN5eWXJrzFXW7uLZTzx+UuFdtNrDWzmxaTrjcUM8x5OlZ6Ul6hI9SrJOAP+lP9ilbgjWaTXubMlhwn4ZAXQjQ\/pTCbCgq9HlcPI1sqK9UNrVzNpog\/l2d0871EcRDbqj3LV6xYQQkCilfU07s+glRaUtpb7l81oPoo9y\/8Yz9nYVOqa\/bddPWypf2L737u\/rFDTu5554Rrfj010ORZNHfZvPT0iuzrd943ee5z17z2J+mUnPmXzR52SmG4uPK0FWNGXlkWKR919QXhM6edWV2Yk5tqFPUbsmza1LVnPc7jtCj+ldzTcT9l8NuLBr+SV8Ir7PbYEAQaMyWSPF5DUijdr5f7DEwSitvnL6ACyRss9khxp2u4Pnymc6Gz0XmHUyXM0eucTc52526nJlzmLd\/5A4KLnOwgJjbATM3fClje9N8K7uDZn2cZNiJYSoCpvzh3yPMoLA3YOidpOSQ+adpR6993oFbsRnTUspAP9Ovnf9F0Hi3OMDcj2NYaqBbfABMeVbI\/6\/Ta8y7qdf31LU88kVpelrd+rX\/w7A3y+asl50Wdt67uuPuMXlliJQlZtpd\/K0Qau52y2IqPNaIcTU1n5939sX7BUFV5qlTkSk33SKnpbgjzAJqJ+qUXhzNYcc0SWnGG0IczgsLQ2bXBmyHEd0aXJpwRskyeln0tQyxtMlgT9nJ7xDOk9gwpY0yWWHmyEpy1P0temLUuqykrnqVmeYr1romDv9IZ1Xfre3VVtycOvWvisOx7hrDqCUcQYckTWrAuzGv6mMwjFp9sRjta3a3tELtAdbU11meTMIiyVD\/\/RBR7I\/HL61B5VU82eV2BbGKFt2fPFZiCUdbaJyotEW5uGWJADOCwUrdszzm\/GOt3t7oDF48ff9ug1gdbRy0Y23+RfFdHy619R46fcPsquebQW+idLLaLoncM6TNrBzbD4SLDpUlal6tbkXgTp6I80eNNOLw92d8hUUGgxmD57g3U6FjQVLn4IEPStYBKFjV40azn5VdRGQ5Cw9ELiqsoHQfE3ootL+tdRVEcfJ4eVKaXGDXU3xhFI43J0mS5wTVFnyPNkee65upL6QrpCvlK11L9CmOltFK+UbnJucp1s\/5zWqPfaTxOG4xf05POrcaL9KzxFu0x\/kofGofogNELj2OEKd0ooxKj2hhLMUN3xILpVQ6wSpX9NVD289NYoWCW8gnHQxIylNuC04TixK0iUmWHw+PmTfh3y9E2wCvlr5RTRZdDYLXhdLmKdSOk6wYpslxseoo5DIMM0+1Lcxq6QpKjwiN5ClyxWExv1GW9Tcp+IuZodMgOhGJ6VI5JBe7P\/sDc9EVWZsf0julZ4S\/2Tbc+FdNlwQrUHPm6GHvyWD4Ah\/9MvzzhhpXaT5L+q\/Oi\/95XHAmX\/3V758VqScf1F1wycYm8yrROsl\/Vk+COoJprv\/MY5E0HIX1MxwvN0mZfFx+4VIVXK4cCUY95or01xTSzYmrlUCAm4kZAkcgDbUjSfGgNr0d8wMQTkGTVUAOGZQcxBV2AP3j1iv+NV\/yvi9cfLd898XT8x4MhGyMwJPVUexjy6MDZgdsCSiBqfm7R+nCcagcCLHb0SH6VPyfXtJDGnowUVamaR0\/VsvXMoEMlVXPr7hRX0E+pSsiZ48p252KtVOzs6SpPqaL+zoGuQSnDlJFazHmGq959qm9kYHTwbN+ZwfnOWa4LgldqVzkXu7ZrO3zbgl9rh\/Qyd6CMyrylKWW+0mBF6GSqDl7hutG1RrnP86i0Ud7ofsTzBG3TdqS8oL6h\/Un\/RP3E95fgAe1bPcct3ivwiKNfM11jxJQujkGLbbONFJ8apIDL6Sp2+opTeMGQ4lS8kqfY2xZ\/I1bNUsoL7uspVgVeKZSqGe5AiVEemKieaUwLXBRYFrg5YAQMFbzI3WF2TLKbZEX5gQrTOdu\/j\/+Zsz\/+Z8dCinCfdDp0w3C5PR7DHwhAvte3OCgIneW02BzDlxJ9JuB0RZ2BYLDc4Qw5HM4U9HOxNyXk9aa4sMotN1whFGefSmukkCw5g6rLF\/CkeEX1gpDj\/LUMHjpBH79rZYQO+r0Sv5jf6FW8bdKjMSM61pAuMa5lXzt5UkwfG5AuCVwbYFfmSTG33yHNFBZJBYPr0Sekg6kH5wiVKPOMA9Onh6HX4D8PsunhY\/tTWqMuII4\/wJ3SmeKvZay03MLqmyITprR6o56o\/HR8L3TavZQS391KfXzRIHi06ytoDfVNVRPEW8a7tzr5u1ZIyJ9Q39RPuH644nu3OqNmatB6I5Rf4Ni9Daogrg1ptbvZ2Yev2EwnyzvMO3VdvKtchigXiO9tMaJqlE62fDWt10Fe3xasoV5B8RLV1tTD\/n+m5ZSHn3hblAWKkCepGcKpUylVpPrOp3Y8Vqf2e2z72v6nbNvS2frUYz3ehID52b7ALvnijjUvvSLPOfSWvOyJ716DpPFhHvo7JI1feseah9J8kltTZV2TNS840ic0cl9FuWBK8dWb7Cd9QclXkGm+hj4us2aq7171Xtf9KQ\/42h3tWrvzJZ\/ui6XXZCmpepo3y99fGuheId3mdlUEz1IbnA3uKSn3SWuMNe4n5TbPC+5dKS\/731L26L\/3vu3\/yAjag8vtoWDAF\/ZCseA3gGIpHPJpJHvJMGRNvArKLAExZDooztE0xenSdUnTdHYhhT6G+dwr+XxevxtKhex1Kx6\/oflkn+F\/jp7TZX8x6SEiXZG9z3klb7FHCXk8iqHriiJrWAl4PGSMDUrB07zLPQWG71xNXx4zMDM8GdPGaY3iA1unxlKiynK5YCza8rTAst9Z31UWkwXmCv9H\/gNfiLfbD\/Oz8Fe0uHW69aHRGp9vpUtwqXkEYdatddVaTNGaEs6tcYs3U3NrPAUZNQrA8eb8Gr\/w80+rkQrya\/RYTtcnABqEeU7sRmDC6ZfBU08170MopZJPur7z\/g9+0TunV3HLm513Sre8+9bAzk\/lMqnzm5F9hvY71OnpeFUa3dA5Hc+V3zle+Rt4JEv6p8UjuUbIp7iVnExfUHNrqbGgL+qOeaIWr2RWlGe9mxV+JSvTz0Qs0sW0kd3iy5F8\/BALcmrKQpN9Wwwl5o2hQ6Jlfar8fHB69GC6NxwsdZd6Sr0DPAO8\/VPuD7jLgmWpo9Ibgg2pDWlzg3NT56ZdqS3xXhm4KnRV2g3emwOrg6tTbwqtMTa6n\/Y\/FdgR+sz4S+hrb4f\/m1A8J8\/mqPRUd0626hvmu96n+DK7qm8aEYJdLunVPp\/HD1kJzSEzlJpaHDRCiPg8EIbFbgPLYCOV3TTdGl+Acvw5ckXOzhw5p02ue8KHtoiF2uSJMXddMBaUZwR3BuVgmzR0m08qoOHZBp8SrRWLevp4xnqUcZ64R\/YgR0uFD20j17VmR5dBMKLxOvhLa2Aifk897D+wL5O\/xv5FVtj\/hQhRmBcONke5EjfPmKVWCv6B1EuBtAlD2jxFnvgn5I5\/IiXKmlD8vW3VNUZBdU0KRtkTaTUB64WzBtaX+cMRYJ\/UUtNvoFq4kFsqDH\/ou7Dg2tCgXrWjMgIlDnfngt++W14QKf+wtfOiIUV9lk2u6rzgMX9ZUfZ8X65a1nH\/5SuWLZHnH3phy9CGCeLnr\/jnSOTb7\/pq9cEZvtqvXdku8atYGz4sFb9K\/4y68I5vt3Rc4CeXB1Ed+SWyyjkHd46hU\/307ZZvr\/KTld715+2vWUn8m2YWmuQ36Rx1EaUBpzlz6QrHZJoiraSp8iZaxlByKaY+Tpch7ybEh4Du4LLIPwl4H6gFJgNZVtoZwLnABI4j73Yui2ss5OsIuoimuiJ0iWNyvAP3u9fxPM0BHkJ4g\/ohbdRqaAHiD6PcTpWomvOgzL3aJlqD9Adx\/nykPQQ6BfH1CE9DuT5WWHfeSplMAQ3pPXCdW6znLVV+QwPURfEP8CwNuOZo4EbcYxzoCKAeeVJBhwIrpedplfR8fAPOg9J1uP9KTgeGWXQUrnMDztehXBHi1yGchXpooD4gHyiTH6caOURPg1bg+c8ynxt4ni7kZ+56JtTfqtPRMOtYnwjc89dAoVwT\/whUT6hbMq5LwmlKP2oEnQ9kA+PlV2iBejpJaK\/7HR+RwgDncTu9B5yizqIxiEuo5wRHKz3AceAMgUXxDvVBWqccoJNx7irtXjzHLLR3X+AgVch\/pZO0YroW\/DUM118BPIRrfiL4YRZNxP17g\/ZTPxI8dCOwGvf60m4nbhvEV6Bfz8S9vuMRgfITgJHol0bgIq4P7l\/Bbc79Lk3urEHefcgzjYH0DAE8O\/Mkl+HyuFaxxYcbDlPagDy3ol33gqpAGtfBhuAzCzj3HK6TCWhALtAb+AjYAMwHBgL1QBnuTbivIvgVPMO8KfgDvOF4Hm2IugmeNZ\/hIdGf5phZb12L75OvPU7zLeTzNXm8MM+iLlvta\/OYYp6xqeDv+YLv\/8bPyTzVRTH21M9pJNdBjEHwlk153KHOPB7uxQJrFegD4OPrmGe5fjbldmFeE22CMWHR2oRn7SPGCKhCVGjx+nU2tduii15ID+OaM7XzIFPW0Sh1MY1S7qTz1P00TOlBvR19kIbnQd4m+XM609VO\/dCXYxG\/P4muYTj3SPMc7XjOzWjPPfRztOml6h65QN0jORyb4586SHrRsVleLsJH0WRI7eY5pozEcz82\/d+B\/IZjM2Tm5vhnjj3xOJ7nLh4Tzs+lPkDUpkhvBhoBLBWlNa75UptzEvmxkD4AXKLGaKAjRtVqO\/onDXIeYwHpkxwf0E7lVrpJ3RP\/k9RIjfIeutGZRufK90Km4V7yG3Qdg68PujCBj47guWResqnNr8mUZb7FUxFQDePvVQv7LBwEvgYf1YMnM3luYPks5gfIaOBGk1\/j33bx54v0S9BbbP5M4tP5SfzpSebLZCrmFsh3e5yiHjfZz8\/ykWUcy0iWcyxn7PzJNKH8zfIm8DHL4VdoqjWuCyyMRh3\/bI19yGH091nxuDYi\/qjWGt+oBOMbtUqE\/wg44o\/iuZd2zalT4p3WfNrDnkvNdHLb86ijHy2w5NnDQt58RT8V8+hkUT9d20LXOg6h3yEDRX3XWWMQ7Yl6z1dnos0foNV4jkxlJcYj0oFp3CaiL4jCPC\/wnKjcg3bmuehWuk55G\/oCl+1HATFf1NFZqPuLIg1zKlNOc5xFG7TPqVKdBFnbTrO4r\/g5uD7c967LyetKg5zYQ33Vx5AnjQzkWyfaIEaPCr7gsvOhUqEtnOeTEzw7Bnn4eutFmRgFrfZ4WLSFKA9dhHmY2wLX1NLoTKFPfE5rHZPoLIyh9c5GWq9NwphLo424xi9RbhLXBeWyxHx9D52N8bUKsmkVZA4J\/p8aP6RsxvMshVwHlEa00WYKOxrRhvPFsw9TTRm7ksePsolKmEe0eyCHWZ+4h25Wy2m4Np9uRdqtDshJ3PcWpF2P8dsHY\/cmlI9Ycptw75uQzmXrWJdhHYHHizNGqVqj0ANI1IH1FNxf+ZTWK6NpFfh4iOsetMMNdBJYmpXGPKCvCRFfbmG1CZHmN6mUr\/jpGk6X+9EfcAc3UZzn0O3qCpqrTqZKpS\/GboBOUn+PsfoN\/Uzx0Qx1F\/1MbaPVHFdTqUxpwvO3Qrfk9NdoHKfLf0B8DU1Va1F+FV2szqBFylbw3utkqHPQ1yjnuA18UoTyX+G6FqQPaaoyGWPrRoS\/iT\/O+cQ9WuNnMdRRdJIolwBRVxtJdZbr8VSj0aeoL4ePqC\/q2lVPu47HqJ94Tr4uynEe9Wf8e1Dxd4Bik3aOl2+lzcA6+S06VTmDrpQ2xnegXUckYVRiXO0vLQN6q\/3pSWAFwr1A\/xvYYsahu\/Wnt4EbcO3fgLZowrgqkTyUBjBF2kPAGuAl+1wi+D7HSk+EIzu+44j4E5hrAOlAfAcjOT\/aeQDuN0A9Jb6DAV4czdCupZBzCYWUUqTnoVxS3JGN8fQEFSkU\/+eJ6vR9wF+fhHaMJT6j3R+g6T8A7yTQKFNrbvi36\/bvAv17LTBdtO\/fKM3kIUqR3oi\/AzpZeoP8yuXgQQDxkxBPtdvT7iek3y3Sk\/oPvELc5snpyfHkfj1RXG6hGYmw+aCLH+6iwQy1DvmB5LjrRRrM0J7FuWePjquPngBTqafyANcJPFh6dFwbS6UMuQh1zeIyGHNAV\/w1yAiA84ryXhrJ4LHLkFuxXgO6zven4YyEdh3A7ao8YJ63+8ful+T+Qf1i6qt0GmgJaA3oBNDRNk0cs8njNjnNliXHypM0Nvoc75r\/NwFjZxfwPPDc\/9f3kgi8CvgB7R3oIXXQI\/dAPzmbvZ87IEu+qwAegRyaCPom0jB7d\/YAvAgHkHYB6M+JDn2N8GVI32MiLqvZtM7SKzORts0q67KuN8Esf+gFom8PAFvM8oc2AfMQ\/juA+fzQu6C\/AV2D\/J+h3PWgvzXPd8xAfAnwNOKfI34RMAXhO0DTQHsBqUAQ5e9lsD5y1Dr0P06Pvf74oRQ6y\/moZ4RtXqDLktcQP5ja\/XkCmrzWsPv\/RDTBZpBEzXbAmunP0PuaEtc+37fGsSn6szMR6qR4B3RKD+vRrMuy\/iz0R4uK9ZvQY3FfopBNWXdm\/ZV1Z9ZfQdcLm4FD1GcSr\/NFvax5I1G2SgfoIcAPZFt0PvJ8I5fGX4Xs8YG\/v8ba6GEG4inAZBPx1zB3+TDX7YTc\/Rr0FcRzQb+25zRbth4lY08wp\/2n4z92jvw35tRKCzOScLx0GydbOI2RPBf\/WJxo7v635\/LjzNGJ8\/T\/Nm7P8zb0wVTJcMbiOxjJeulResAJ4ifSc39sPFnv+NHxJL3EjifjqPPJvGfrM1mU1YWkcfdjwWsL9YnDur9dh+Rx3DXerDjaaHgiIAfKrDl0A+QF9P94LoA5Kn4X0pa7vqNK16+oEvEnAMybnV+AzuJzoGulW9m+zb+B1PkTxP3qKyLvFAuzTsTPyXzL+rnQD9FmQg7ewfWnCmAQEAS2AgvsvuY1JO79JxmzLq9z1anxr9VXgSQd8IS0P10K\/ApxH+I+yOKQFoDcjtGjbI8HNUANyPfxh2188Q7tKpFntLAtL6ZRkPMXq3vY9hX\/nbDpdRJ\/tY33Ua7DHBqx7XSIp7FtyBlle0m8zbLPzdS+wjx4FuZDnecO3Hey2BOar7Id9yv6qeKmYZYNOWTbktk+xfOV1htl2I6RaEf+kPqq02gYUKea+1ST2P6ifCT2alay3V0ZQ09b+1tNxiZ6SH+eHnLNohGua8V+073Kg3Qd0h503kYPauVif2WSPa\/ynHgM2x\/bMrO6bJrWMyfrBKJ+0+h0tsck3tcu5xqBufQrYYcy7Zgn0G0wx98MzDL3K+IHj23vjL9s2T0vtOb4JV1zfrKdfhqNV5Zj3WfbZB8BfYPOUW8ErDZOrot9L7RLx\/F0IVs3QfgsYesz93vYBpWasA83QrTzp6K\/TuM+c3gxhn3c\/\/Htqrk\/N1RdivwyZapfAqbtUezPsW2YbZAM+SGM0YsxVsCD6t1iD+96C8gbf0SUu8jcN9MmAHWo1xzcZxPvHdmgGw4jvk+dRDcLCLtafIMcim8HvUx+Sewx+qy9wEx1Nfp5prBL23uCYbVM2K3L1IkA+h+4EvEi8ewWFW0VQzkf1nX8jGyb602Ecy5lkGUjtfI6n6QRzhj41U0jHC1UpFwC\/aUdsi4HfTca\/eqj65Q\/U556Mp2vBGgWQxoRf1X6HBSaOkP+DOl\/Ar0Tcd77fZPOsffVTPs0HRLYBV0BsPZyGbMZ8iYp39onbLDCuWYYaTW0TcC+xiZ6JAHIF\/8zcEj+Ke49lGbJbbjHOtQF91H8GH9JQJnzLJRZ9xmpnoUxdiROTQbKMq1IBtKZFifDSs9KBtKZDk0G0oceox7Hy3e8ehwvvSQZSC\/5D9TjeNctTAbSC7+nfvXJQHr9j6jH8dq5KBlIL\/qeeoxJBtLHJNcD8gnr2M7nsDZ9HPSP1nz\/KejpoOC+zt8hjPVFfI4V\/6OV7z4A69\/4\/QDWyvGhFiDz4rwGXgn6VwDr6vj4w+h8ETTH9MOw7xO\/G+gJTDbvxWU7nzLvLWDds7PFLN\/xK6u+CfHOdOBj837i3ix7d4AWAg9Y+VdZ920y69559+H8fJ6fUZRrOoy4ApyJ8xHQCYfR+YSJ+DOg\/wWwXfR54AUrnGe1Bz\/zk3ytw3KBvhV7Rby3g7nauYlIzNlX0+lC5r52xFxl7ll\/SBuFvItD9tVSpeaFHvJzGsp6A8twx2yR\/xbHLMxNBP1kstjPm6\/uJYf6LGU6PqIZ6sU0TNkGvXgk5C3uIfZlcG2W26xzKDfRGYDYqxR7Qrx3spRWGq1Cf\/EjT0j9C+p7P+3Emm0V75+xPHf2RvwOPMt6Wuq4mq5yLaCd2n7UdQ\/NwXwV0WZQjeMnNMpe22oLSHd4oBdY1C3R+XoO0tk34WMapq+EXrebxqHNqu17d7WDk0JIf8S0r3Si5TrR99+VA6eLOqO+0MNUrK1Dtt+AYzraZJaozxix5\/QYqVijk+NLzN2nUZlTh+5VQav0MK3TDuI5NNyrPMFfgPfpN1GJ8wLq61hJJfbaXduHdp5Ihk15P862B0B3W69eKPTFoNjXsuwBXdS+Bu+3NdJq9pVI1mtsPapLp7BsBF02B\/t5QHn+7Hp+iyboG6ZNoR36aRqV8z6esIkkU6tOYh+vHbxk6bPOnTTaqYA+QnO0G2mC4wy0SypNcD5DQedICrN+5nQKvW4Bz9GOb6CLTqAS8P6p1ni\/AuCxNNIa44uR\/ibwuDkeeXxxuhibSOt4wEqfBywD5prn+Vz8WjPc8aV5fXFumZm\/A+MwzntwcoKt5n0TYh0STdRTLV+qG4+ih\/fumX9GnJD+QBsaj2H2qTrGHn8yvRv0QjsOPe99jNG7UDYKaLYenUxV0z9luUmFbsj0lxb9BfMa63rJNNl\/5Xj+LN+jx5rjzKZH+r3Y9ByLlnT55ZyAJvrJHKbxuBVP+aG2O8vmlmXTY\/gfmDa5w1Q7av2USEWfkGLpsay\/jxb7\/Oyb8z3o8uH6CXjgSExmsD\/BsaBhJmE4LzoSlp5\/XGi3oxzgiiQj\/g8G6rzCRPxnFj63sIGhSFhLA+qdyYj\/Q+DY\/nXDtJ\/jvoDrJBPOF00I\/f97gDYgJ0awKyioxnPh9wJaBsP5pYVbbMTjDLvd7Xa02wXP9jGe+8KuOtv3t677v+3H\/22\/\/Kee+\/vqngjLR8+m7LunHbPe6B+Bf5gQvjSbKNWChnZ9CtgM7LJwNwNjJYt9lZTZ4KfZwl+xq8xRfHAr1qYMK27532gaNDtn2BwH7PtjghqO1T7O2Sb\/OUvNdhJ+O6bu9RGew2v52M6xZF+RPo7WW36yEZYtmHd5nPdRf0NzjtT54hPM9XR8A+ZJB\/IHHItphPxS\/BeOqyAT9sdfcFwLXQDAva638KKFdabuF99i+UFqwh94Ez2WCKxt8xicB\/dbBPzS0rdZj73MROdfzPTD9bJlr\/IvPMchyhT+pTGxvh6nzsWafi5lKp\/jPPQF3m9SzqUhPGcoA6Bbsc\/NUstflm0P74Ga8KJdxikbE8Y3+9ewXw0gfHK4n57DHMD5nxPl7fV9mbAvzYccf5siwvcH54RPD67Bvk6sFylYUTjGgi\/GI+\/4+O+VNaCjLPwLuBj1nUxz5evpJGUO1sO7oe+kIf1S4BKEw6A+oAF4EFhCfUX6IfDJt8gPKCriL4M6sLZ3IO0bC6tN8Hmx3t5Gs6ATz8L1zHx7RBkTGs2SfivuNUsZiushn4yVkgKNQkmzwhrO34ByO831O9sVOL84Z+fRD+dxfEEjjDk0QksFborvcAyJ75A+pVp1KgXQp16gP\/r6VWv9wHrUawBaK\/4Q4rvkZL8Ae5\/coo5f0VzHKXSSowP6wTvgg71U6zhIP3PUUZk2DvPY48S8NAjgtd0c9icWvsR74q\/atm8b2hRK05+lkehDYv8Nm8qb+RMteN5JYj4SvvQSa2+bTY1M+E+bY03ouc5hdB3G8QhglOX3PcfcH4MOirGnmn6qZeovKdfU43gN1YnWivN4mADZ0GV7Zco+bcxbli6IovHH5T\/wujZezXsV8jj21xJlzzbXpXG2V\/8UYJvlgwn7T\/cy\/v\/e35KT9qGOt190It+ME\/lqHBX\/kXsqyb4bJ\/LlOGE8ac\/lRPtl4FXWkUdgXtmpbYrvQfxJ4E7I14cZKsXjwj5q6ms3KW6M7cVYg55GRZZNlO2keZBfeepqYdO\/0bwepUI2DTVt8\/HvrPcchD2VbXOslyph8R5ElvVeA19\/tGW\/Fe9NdNlpq2gSy1qWqWLOYN9urNMgb2axbJFfpH7yd6YMkvYIEMsiYZccijoOFVSE5Z6WTBlKutwPz3K3CcUXf1HIpBRTZimE67WxPMP8a8qrXCXLlF\/y66YMkt9DHhsHgM94r0asp58255zOx8Tc9K0pJ4UsZDskwuJ9FHP95OMxyO\/BnEhfsnTLzUn0KZueSC+0ymy2yhyd39q7wVySKubk56kH2ya61l1E\/YRv9MdivTIK51kHOazn2\/Z20U\/oI3NvX0peF\/B+DvetvaY37WadryfQGSbEPM3t+BfoZQbm3dPFPSDjxH7PovgBq568PskEn97Stfaz13L2WoNokPoQPaxcAF2oD\/skifn+6YT17cMM5jPr5aaePxALgf3gKshKeYmFv4EDqwCcU\/ZCej8IDWopJP0GIgNrbPc7RF7k92H14cfzB7EeDyFfWu3xkQ7NLQyZm9lGlI1bZv+OKOcqojyDKOIHDpgoQJ0KWomK3yMqxbOU4Rl7\/JaofBtR7wKoYy8T9UW5Ssx9VVghDBhnovogUc2A46PWZeIUXK8OzzWkN9FQaLHD0Ecj0olGGiZOwzOOxrVPx3w7BvPDuMlEZ2aZmIBZfvILRGf9lajhZqKzNxLNRB3Ow\/Vn3daNbnSjG93oRje60Y1udKMb3ehGN7rRjW50oxvd6EY3utGNbnSjG93oRje60Y1udKMb3ehGN7rRjW50oxvd6EY3utGNbvw\/DYl\/sYm+olr6OTlJJj9V8FdN1QvVXHKQvJ0mKmUtJeHI7qeVHrQXkJUezeW5ke1KqZLbPCgSa1MKW4Jplb4hJylRXK1CHKM4XgJsAXYCKs1Q8pDux\/FaoBHYAuwEdgMaEY58NgpcAqwF9vIZJVfJaY5G\/ENKlUyUzUQdfUoGfQnEAYUiOFYAY4EZwO3AWkAT+TjlEuBaYCewX5yJKRnNd\/VD3TOabxGkZd5FlSJ6rhmdNl1EW85qMOkZ40067DQz20AzW98qM7n3UJOW9jJpsLiykanhrWwfkq6k4yHTUfGFOEry78gnSRShdUoaNQGyolkpMSXYUlRSuXanopKkyIpEsygSb1ekZm+gcoghx+UvKUgR+W\/yF+YZ+YuWlEDl2iGj5T\/TFmAnoMh\/xr8P5A\/oWnkvtzmOdcBaYCfwGvAloMl78e99\/HtPfo988rtUAdQBM4C1wE7gS8Apv4ujX36HuUUcOVwHyPI7OPrlt\/FYb+Pok99C6C35LVTtf5qrayq3i0B5hRWIFFuBjGwrEEyvbJP\/0PxND3BUCXoaHPWUUkCDqZ9S0FzcN9KmhJtr50ba5A9bouWRdUP6yK9TEyCjJq\/jzq9TFBgHzAQWAhpCbyD0BjUCdwDrgCYAXIajH4jKu4CXgTeoDxADxgEueXczbtMmv9ZcMjQyJF1+VX6eMtDir8gvCPqy\/JygL8nPCvoiaB7oLvm55rwIDXHjPKGMH9QPWoHzDvk3LUXBSHxIQN6JtovgWAHUAWOBGcDtgCbvlAuaZ0WCuMhTtMtFyNlMnwr6CG1wUWxeJFZyKhgwyoeSgacghMPa6NoSOVZy7\/2I8qHktrsQ4kPJ9asR4kPJVSsQ4kPJRUsQ4kPJrHkI8aFk6gyE+FAydiJCOLTJDz1ZVBqpHjtfig7xyVegla5AK12BVrqCVPkK\/kffqFy3nzX37IkWeyBW3qNnpHGH1Pi01Him1LhBapwtNS6XGldIjbVS4zlSY7nUmCM15kmNManxKelkNEWjFGs9IloTC0uNu6TGX0mNi6TGEqmxWGoskhqjUnWsTc5vPq2fIMMFaRnCgw70lMGQPj45Hy2aD57Ph0zYieNrQFzEYsgULTAzZ+YxLWjpWWfGew+svGTIKPkZFHwG3fAMvQ+o6KBnwEbP4CLP4AI+HOuAGUA78CUQBzTkLkDFbxdHH44VQB0wA7gW+BLQRHW+BGS6xKriFlGxCqvSYzkmP4N\/BfiXL+fHcv05\/nL\/KOX2HMmXJ43Ni+fJ1ZSeTkTBgCvQJnm3\/dP7r396SR+iy7fJt1MuOuIOi97e\/E1upE1a01zyVGRImnQf5angOqmGSqRi0JNpkYj3pxwX0yrKkTeDVjbnTEYxX3NJr8gOKYVLbYt8k7Mv8mlOm4zgJzlPRd6MtqlSc2QPUjZvi7yec1PkxYo2F1KeLmmTQHZERdbtOSdHfrVLZF2BEw80R5Yz2Ra5JmdkZH6OODHbPHHOIsRivsiZJVMjo3C9YTnnRWKLcM1tkbqccyK1Zq7+XGZbpA+qUG4Ge6KyPXLETQvzxAUnVbdJF8Z6Oe91TnGOdQ5wVjp7OfOdEWeuM9sZcgVdfleKy+MyXC6X5lJdsotcobb43lg5\/4JhSBM\/ZMivLEukirBf5qP4\/gL\/Iq9LptHUlKrUy\/UThkr1Te3nU\/150aaDEwrbJGP81CZH4VCpKVhP9ROHNp1cXt\/mjJ\/ZVF1e3+Qcd\/aUrZJ0WwNSm+RVbRJNnNImxTnphuym4KlTtpMkBW64NZtp2Q23NjRQOH1JXbguODhQM2LYMQ4zrWPCz1uHjwjnNt1bP2FK06bchqZKDsRzG+qb7p4QnTZlu\/SVtH\/4sO3S35k0TNmuDJa+Gn4mpyuDhzU01LdJk0U+ikp\/Rz5wzN9FPhcmZs5HUVeeme8BM18xyiNfERPk03UqFvmKdV3kUyXOt3VR0fBhW4uKRJ6MKC0SeRZlRBPz7CpGnuJikSe9kXaJPLvSGzlP02CRJScHWfJyRBYpi3JElhwpS2SZfDhLhZXlpq4sN4k7KdLhPDlmHu9eO493L\/KU\/9C\/2UPLy6WWQQ3nTxs+u3D4zMLhs4GZTbcsuTDc1HheNLr1\/AY+EW1SSmaed\/6FTM+d3dRQOHtY0\/mFw6JbB007xulpfHpQ4bCtNG34xClbp8VmD2seFBs0vPDcYQ0tI8dVVR9xr5u67lU17hgXG8cXq+J7jaw+xulqPj2S71XN96rme42MjRT3IsHj46ZsddHQhlOnmbRFdhvg15nZ+Q1D0\/0LBwvmHZQfXp69A9rKRnKXNzR5Coc2eQE+ddKQk4bwKYwpPpWCZJ91Krx8UH72DmmjdcqP5EDhUCpffPmiyyk8fO4w8\/8i\/CFp8eXc4OaxfNHx\/nBueFPs3GGLFhPVN\/WcUN9UN37qlK1OJ1Jn8iM1DbTT3O7hbfF2M7E3EgdyoqJ0ZeS0Wk7TdSvj0f1\/uUXF77g2yk+1SLE8aTEtalCa8uonyhAFE6fiWadNnbIDuhRPD4sa8ICLpHJpkX0Nq9rmb0oz4We2sfhyK2S1xWKLmiVRZJHdJF1\/3FjlXS22GBek\/wOhIM2vCmVuZHN0cmVhbQplbmRvYmoKMTcgMCBvYmoKPDwvSXRhbGljQW5nbGUgMC9Gb250QkJveFstNjY0IC0zMjQgMjAwMCAxMDA1XS9GbGFncyAzMi9Gb250RmlsZTIgMTYgMCBSL0ZvbnROYW1lL0lNQ0laUCtBcmlhbE1UL0FzY2VudCA3MjgvVHlwZS9Gb250RGVzY3JpcHRvci9DYXBIZWlnaHQgNzE2L0Rlc2NlbnQgLTIxMC9TdGVtViA4MD4+CmVuZG9iagozIDAgb2JqCjw8L0VuY29kaW5nL1dpbkFuc2lFbmNvZGluZy9GaXJzdENoYXIgMzIvVHlwZS9Gb250L0xhc3RDaGFyIDEyMS9TdWJ0eXBlL1RydWVUeXBlL1dpZHRoc1syNzcgMCAwIDAgMCAwIDAgMTkwIDMzMyAzMzMgMzg5IDAgMjc3IDMzMyAyNzcgMjc3IDU1NiA1NTYgNTU2IDU1NiA1NTYgNTU2IDU1NiA1NTYgNTU2IDU1NiAyNzcgMCAwIDAgMCAwIDAgNjY2IDY2NiA3MjIgNzIyIDY2NiA2MTAgNzc3IDcyMiAyNzcgMCA2NjYgNTU2IDgzMyA3MjIgNzc3IDY2NiA3NzcgNzIyIDY2NiA2MTAgNzIyIDY2NiA5NDMgMCA2NjYgNjEwIDAgMCAwIDAgMCAwIDU1NiAwIDUwMCA1NTYgNTU2IDI3NyA1NTYgNTU2IDIyMiAwIDUwMCAyMjIgODMzIDU1NiA1NTYgNTU2IDAgMzMzIDUwMCAyNzcgNTU2IDUwMCA3MjIgNTAwIDUwMF0vRm9udERlc2NyaXB0b3IgMTcgMCBSL0Jhc2VGb250L0lNQ0laUCtBcmlhbE1UPj4KZW5kb2JqCjE0IDAgb2JqCjw8L0NvdW50IDEvSVRYVCgyLjEuNykvVHlwZS9QYWdlcy9LaWRzWzEgMCBSXT4+CmVuZG9iagoxOCAwIG9iago8PC9OYW1lc1soSlJfUEFHRV9BTkNIT1JfMF8xKSAxNSAwIFJdPj4KZW5kb2JqCjE5IDAgb2JqCjw8L0Rlc3RzIDE4IDAgUj4+CmVuZG9iagoyMCAwIG9iago8PC9QYWdlcyAxNCAwIFIvVmlld2VyUHJlZmVyZW5jZXM8PC9QcmludFNjYWxpbmcvQXBwRGVmYXVsdD4+L05hbWVzIDE5IDAgUi9UeXBlL0NhdGFsb2c+PgplbmRvYmoKMjEgMCBvYmoKPDwvTW9kRGF0ZShEOjIwMTkwNTI5MTAzMDAyKzA4JzAwJykvUHJvZHVjZXIoaVRleHQgMi4xLjcgYnkgMVQzWFQpL0NyZWF0aW9uRGF0ZShEOjIwMTkwNTI5MTAzMDAyKzA4JzAwJykvQ3JlYXRvcihKYXNwZXJSZXBvcnRzIFwoQ0lNSUVGb3JtXCkpPj4KZW5kb2JqCnhyZWYKMCAyMgowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMTEzODQgMDAwMDAgbiAKMDAwMDAxMTc3OSAwMDAwMCBuIAowMDAwMDQzNzAzIDAwMDAwIG4gCjAwMDAwMDAwMTUgMDAwMDAgbiAKMDAwMDAwMjQ5MiAwMDAwMCBuIAowMDAwMDAyNjU4IDAwMDAwIG4gCjAwMDAwMDM3NDEgMDAwMDAgbiAKMDAwMDAwMzkwNyAwMDAwMCBuIAowMDAwMDA1MDA3IDAwMDAwIG4gCjAwMDAwMDUxNzIgMDAwMDAgbiAKMDAwMDAwNjEyOCAwMDAwMCBuIAowMDAwMDA2Mjk0IDAwMDAwIG4gCjAwMDAwMDcyODYgMDAwMDAgbiAKMDAwMDA0NDE2NyAwMDAwMCBuIAowMDAwMDExNzQzIDAwMDAwIG4gCjAwMDAwMTE4NjcgMDAwMDAgbiAKMDAwMDA0MzUyMSAwMDAwMCBuIAowMDAwMDQ0MjMxIDAwMDAwIG4gCjAwMDAwNDQyODcgMDAwMDAgbiAKMDAwMDA0NDMyMSAwMDAwMCBuIAowMDAwMDQ0NDI3IDAwMDAwIG4gCnRyYWlsZXIKPDwvU2l6ZSAyMi9Sb290IDIwIDAgUi9JRCBbPGI4OGQxM2E4Y2RlYjAyNWZiMzJmNzM1ZGNhOWE1MzNjPjw3OTVlYjIzYzNiYWZhZWQ1ZDBmODVhZWQ2ODczOGMxZj5dL0luZm8gMjEgMCBSPj4Kc3RhcnR4cmVmCjQ0NTg3CiUlRU9GCg==";
//						var strBase64 = "/opt/ibm/WebSphere/AppServer/profiles/AppSrv01/installedApps/localhostNode01Cell/CDMS_MyWorkplaceWidgets.ear/CDMSv3.0/REQUEST FORM/2019-05/CIMIFORM 1-01-2019-0000244 05292019 103001AM.pdf";
//						window.open(strBase64);
//						objbuilder += ('<object width="100%" height="100%"');
////						objbuilder += (strBase64);
//						objbuilder += ('" type="application/pdf" class="internal">');
//						objbuilder += ('<embed src="data:application/pdf,');
//						objbuilder += (strBase64);
////						objbuilder += ('" type="application/pdf"/>');
//						objbuilder += ('</object>');
//						var win = window.open("#","SAMPLE",'width=700px, height=700px, status=no, location=no, resizable=yes, menubar=no, scrollbars=yes');
//						var title = "SAMPLE";
//						win.document.write('<html><title>'+ title +'</title><body style="margin-top:0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px;">');
//						win.document.write(objbuilder);
//						win.document.write('</body></html>');
					}else if(item[0].status == "Not Started"){
						console.log(dataStore);
						formsLibrary.createRequest(item[0].wfId,0,dataStore);
						
						//TODO - START LOGGING TO CI_LOG_WORKFLOW
						var userid = globalUserId;
						var strWorkflow = item[0].wfNo;
						var strwfAction = "2";
						var stepId = "CDMS_01_1410_01"; 
						var wfResponse = "";
						var wfTaskStatus = "0";
						var requestNo = "N/A";
						var stepRemarks = "";
						var routedTo = "";
						var completionTime = "";
						
						//alert("start log - create WF");
						formsLibrary.setCIMInternalLog(userid, strWorkflow, strwfAction, stepId, wfResponse, wfTaskStatus, requestNo, stepRemarks, routedTo, completionTime, function(isSaved){
						});
						//alert("end log - create WF");
												
	        		}else{
	        			console.log(dataStore);
	        			formsLibrary.createRequest(item[0].wfId,1,dataStore);
	        			//TODO - START LOGGING TO CI_LOG_WORKFLOW
						var userid = globalUserId;
						var strWorkflow = item[0].wfNo;
						var strwfAction = "2";
						var stepId = "CDMS_01_1410_01"; 
						var wfResponse = "";
						var wfTaskStatus = "0";
						var requestNo = "N/A";
						var stepRemarks = "";
						var routedTo = "";
						var completionTime = "";
						
						//alert("start log - create WF");
						formsLibrary.setCIMInternalLog(userid, strWorkflow, strwfAction, stepId, wfResponse, wfTaskStatus, requestNo, stepRemarks, routedTo, completionTime, function(isSaved){
						});
						//alert("end log - create WF");
	        		}
	    		}
	    	});
    	}, true);
		},
		convertDataURIToBinary:function(base64) {
			   var raw = window.atob(base64);
			   var rawLength = raw.length;
			   var array = new Uint8Array(new ArrayBuffer(rawLength));

			   for(var i = 0; i < rawLength; i++) {
			     array[i] = raw.charCodeAt(i);
			   }
			   return array;
		},
		getWorkFlowType:function(){
			try{
				var comboWf = dijit.byId("workflowType");
				var workflowData = [];
				var requestParams = {};
				requestParams.shortName = globalUserId;
				requestParams.callingFunction = "getWorkFlowType";
				globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FormLibraryService",{
					requestParams: requestParams,
					backgroundRequest: false,
					requestCompleteCallback:globalLang.hitch (this,function(response) {
						var workFlow =  response.workflow;
						console.log(workFlow);
						for(var i in workFlow){
							var WorkFlowId = workFlow[i].WorkFlowId;
							var WFCode = workFlow[i].WFCode;
							var WFName = workFlow[i].WFName;
							var ModId = workFlow[i].ModId;
							workflowData.push({strWFID:WorkFlowId,strWFCode:WFCode,strWFName:WFName,strWFModId:ModId});
						}
						cbStore = new globalItemFileWriteStore({data: {
							identifier: 'strWFID',
							items: workflowData
						}});
						comboWf.set("store",cbStore);
					})
				});
						
			}catch(err){
				alert(err.description);
			}
		},
		getWorkflowDetails:function(wfName,callback){
			var data=[];
			cbStore.fetch({
				query: {strWFName:wfName+"*"},
				onItem:function(a){
					data["strWFID"] = a.strWFID;
					data["strWFCode"] = a.strWFCode;
					data["strWFModId"] = a.strWFModId;
				}
			});
			callback(data);
		},
		changeGridDataJsonWF :function(dataGridId,path, myIdentifier) {
					dijit.byId('txtCusName').set('value',"");
		        	dijit.byId('txtCusName').set('readOnly',true);
		        	dijit.byId('txtWrkFlwNo').set('value',globalWorkFlowNo);
		        	dijit.byId('txtWrkFlwNo').set('readOnly',true);
		        	var wfType = glblUtil.getVal("workflowType");
		        	var strwfNo = glblUtil.getVal("txtWrkFlwNo");
		        	var wfData= [];
		        	wfData.push({id:1,requiredForm:wfType,wfNo:globalWorkFlowNo,customerName:'',requestNo:'',status:'Not Started',wfId:glblWorkFlowId,wfMod:glblModule,wfCode:glblWorkFlowCode});
		        	
		        	dataStore = new dojo.data.ItemFileReadStore({data:{
						identifier: myIdentifier,
						items: wfData
					}});
		        	
		        	glblUtil.changeGridStore(dataGridId, dataStore);
		        	dijit.byId('cmdWrkFlw').set('disabled',true);
		        	dijit.byId('cmdSearch').set('disabled',true);
		        	dijit.byId('workflowType').set('disabled',true);
		        	dijit.byId('cmdLaunchWF').set('disabled',true);
		        	
		},
		
		 createRequest:function(strWorkflowId,isDump,dataStore) {
			 if(strWorkflowId=="20182204000002"){
				wfDetailsPayload.wfNo = dijit.byId("txtWrkFlwNo").get('value');
			 	wfDetailsPayload.isDump = isDump;
			 	wfDetailsPayload.dataStore;
			 	wfDetailsPayload.isWithApproval = 0;
			 	wfDetailsPayload.isRequestingOfcr = 1;
				reqPayload.pageClassName = "CMTOS/"+solutionPrefix+"/InternalRequestForm";
				reqPayload.pageType = "casePage";
				reqPayload.pageContext = {"solution": thisMainObj.solution, "role": thisMainObj.role};
				reqPayload.crossPageEventName="icm.PageOpened";
				reqPayload.crossPageEventPayload= wfDetailsPayload;
				thisMainObj.onBroadcastEvent("icm.OpenPage",reqPayload);
				globalICMUtil.closePage(thisMainObj);
			 }else if(strWorkflowId=="20182204000001"){
				wfDetailsPayload.wfNo = dijit.byId("txtWrkFlwNo").get('value');
				wfDetailsPayload.isDump = isDump;
				wfDetailsPayload.dataStore;
				wfDetailsPayload.isWithApproval = 0;
				wfDetailsPayload.isRequestingOfcr = 1;
				console.log("CMTOS/"+solutionPrefix+"/ExternalRequestForm");
				reqPayload.pageClassName = "CMTOS/"+solutionPrefix+"/ExternalRequestForm";
				reqPayload.pageType = "casePage";
				reqPayload.pageContext = {"solution": thisMainObj.solution, "role": thisMainObj.role};
				reqPayload.crossPageEventName="icm.PageOpened";
				reqPayload.crossPageEventPayload= wfDetailsPayload;
				console.log(reqPayload);
				thisMainObj.onBroadcastEvent("icm.OpenPage",reqPayload);
				globalICMUtil.closePage(thisMainObj);
			 }
			 	
		},
		getRequest:function(dataGridId, myIdentifier, wfDetail,strRqstDate) {
			dataStore = null;
			var wfType = dijit.byId('workflowType').getValue();
			formsLibrary.getWorkflowDetails(wfType,function(data){
				glblWorkFlowId=data.strWFID;
				glblWorkFlowCode=data.strWFCode;
				glblModule=data.strWFModId;
			});
			var wfNo =dijit.byId('txtWrkFlwNo').getValue();
			glblWorkflowNo = wfNo;
			glblRequestNo = wfDetail.RequestNo;
			if(wfType != ""){
				var wfData= [];
	        	wfData.push({id:1,requiredForm:wfType,customerName:wfDetail.CustName,
	        		requestNo:wfDetail.RequestNo,status:wfDetail.Status,wfNo:wfNo,
	        		strStepId:wfDetail.strWFStepId,WorkFlowDtlId:wfDetail.WorkFlowDtlId,
	        		WorkFlowId:wfDetail.WorkFlowId,Context:wfDetail.Context,StrName:wfDetail.StrName,
	        		StrUiDisplayName:wfDetail.StrUiDisplayName,StrFileName:wfDetail.StrFileName,
	        		rqstDate:strRqstDate,formattedRqstDate:wfDetail.strRqstDate,
	        		wfId:glblWorkFlowId,wfMod:glblModule,wfCode:glblWorkFlowCode});
	        	dataStore = new dojo.data.ItemFileReadStore({data:{
					identifier: myIdentifier,
					items: wfData
				}});
	        	glblUtil.changeGridStore(dataGridId, dataStore);
			}else{
				glblUtil.alertMsg('Please select workflowtypes first.');
			}
//			this.cellDbClick(dataStore);
//        	myFormListGrid.on("CellDblClick", function(evt){
//        		dijit.byId("myFormListGrid").store.fetch({
//        			onComplete:function(item){
//    				if(item[0].status == "Completed"){
//    					alert("INTERNAL_REQUEST_FORM.pdf");
////    					var pdfAsDataUri = "data:application/pdf;base64,JVBERi0xLjQKJeLjz9MKNCAwIG9iago8PC9Db2xvclNwYWNlWy9JbmRleGVkWy9DYWxSR0I8PC9NYXRyaXhbMC40MTIzNyAwLjIxMjY0IDAuMDE5MzMgMC4zNTc1OSAwLjcxNTE4IDAuMTE5MiAwLjE4MDQ3IDAuMDcyMTggMC45NTA0OV0vV2hpdGVQb2ludFswLjk1MDQzIDEgMS4wOV0+Pl0gMjU1KAAAAP\/\/\/+MAAOMBAeEBAeICAuECAt4DA+EEBOIFBd4FBd0FBdoFBdkFBeEGBt4GBt0GBtwHB9oHB9xcYlxi21xiXGLVXGJcYuBcdFx031x0XHTZXHRcdN8LC9Vcblxu3VxmXGbXCwvgXHJcctpcZlxm2FxmXGbcDg7bDw\/YEBDeEhLhExPXExPUExPbFBTdFRXNFBThGRnNFxffGxvaGhrDFxfbHBzNGhrjHh7gHR3XHBzOGxvLGxvLHBzYICDVHx\/IHh7GHx\/gJCTWIyPHICDTIyPVJCTOJCTYJibhXClcKdEmJt1cKVwp1Ccn1VwoXCjPJyfWXClcKdcqKtgsLNwvL9kuLtItLeAzM9szM+A1Nd01Ndk0NOE3N8kyMsUyMrsvL987O988POA+PsY3N98\/P+JCQr43N8E8PL08PNNERLg+PtZKSuVQUMFGRuNTU9ZTU+ZeXthZWd9dXdZaWtNZWctXV9pgYNxmZuVra+NqauZtbe1xcdxqatBnZ+p1deFxcex7e+x+ft94eOl\/f85wcOyCgsNtbeyIiOeIiN+FheKJieOLi9mFhe2SksR5edqOjsqEhMJ\/f+ubm++hofKpqeGenvCvr96lpfG2tuqystmlpdWiouGsrMKUlMSXl\/fAwO24uNyurvfFxea4uOW4uM2lpc+oqM6np82mpua8vNCqqtGsrOS8vOjBweK8vNSwsNOvr+rDw+W\/v\/PMzOjCwvnS0vfQ0OrFxebCwte1terHx\/TQ0O\/MzNm5uejHx\/XT0+vKytu9vd2\/v+LExPvb29\/Dw+zPz+zQ0O7T0\/TZ2evR0ePLy\/ng4PDY2PXe3vPd3enU1OjT0\/vl5fji4u7a2vzo6PXh4evY2OnW1u\/d3fzq6vvp6fvr6\/np6fHh4e7f3\/zt7fXm5vvt7fHj4+\/h4fjr6\/ru7vPn5\/Hl5fTp6fvx8fTq6vbt7fXs7Pbu7v739\/ny8vjx8ffw8Pr19fn09Pv39\/z5+fv4+P78\/P37+\/7+\/v\/\/\/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACldL0JpdHNQZXJDb21wb25lbnQgOC9MZW5ndGggMTMxNS9IZWlnaHQgNDUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDIzNS9UeXBlL1hPYmplY3QvRGVjb2RlUGFybXM8PC9CaXRzUGVyQ29tcG9uZW50IDgvUHJlZGljdG9yIDE1L0NvbHVtbnMgMjM1L0NvbG9ycyAxPj4vTWFzayBbMjQyIDI0Ml0vU3VidHlwZS9JbWFnZT4+c3RyZWFtCnja7JpRaBxFGMf\/M3ubu+SS3mybNpFgq5SS1gdb1IhKrC8FH9QHjRRfahARwQcrKPpmsQoKgihooaigUiqIAR\/0xapQjSCSVtMEsYg0ttQaTDJfrmkvtze748Pd7e3dze5dUjkbe8Pd8e3M7Nz3m++b75udO5bFNVM42qxt1jZrm7XN2mZtTUmUBV+DMxSUr1h6qRNcw9Jgeb9DcdsHV77tu7bnq27uJtc6qwYDCjPPfa8a3HD3a4OmekFXPSsr75syIB9qz1TjW4Y\/r2KsaqM1sV4J4Hi7CVSMh0lFjXXXhA8LCFn4DgA2DXYEtVaeJcAV0wwAvPlJvwGauIpNmwjJSk8DGHxrR1cBAHRCLSXX+Rc67VzaLnhWHhn18qE1Y8UYVhLkHp8H2MO3PD0DwFKKudtufcJ7\/dgySyQ9i7Mb79uXMqFSHLgodygLouYWQp1cPRhVfyHVXwVSlVfVRctKzoH2Tmqgs\/fIp0EoPjX5wJGjwdXM7GMzALqNqCABRKgRFkRFjzrUQD1hjPAxfYIqAVDUvFdyzoIzOwFg+z3vqMzuFMtz4AvXTU6rzCO2m1r2L36i7fwd13VYGyJchOJ8+0rcPS6d1bcFqBTJyrVUUwB2DHyDkQMcebH41fjfOzOTePSgzzXY0TF1e+pxoIDMosGsZnTRpI7NTIVotkFEqBXaS7gTcwC7oXAeRz7WNgdbUomhD86ndhfH+nY\/H8luWY1dqG7Ka1UUTUxWRHYrT1rNUqe4\/OqBj2tAbDzkcq685cvuJYW7Rif11uE5AHLOvvf57h4AwGKD3UNpXQkhRFxyqrmdTOgisk+8fSl2vRZsPQ2g\/\/59eGi0k\/lInnnlN7V5EEPgC4yJnw9MPTt6CQv838o0whCrq1y7PszTat2\/hlX56icAt2VOsvRpO9mRTpwjbHrjhUTnj4sb\/tg+dvgYGz6X\/ezL3j0yVndqwpdXFrcqMfsKY13A6nk\/\/Amw7e\/n8REYB0ssa7brrMK77yVgF7CMoYEP38yx\/hMrRaW6XiRiQ0llxYkG4aYyUE2iMYbuUH6d0MC6zSd6s76Gp1GAtXfv8V1THny4TNs7n7FOzwPZpDYFVGFStSapGnSkSDtRxKRU9yFDnWho160XTgG4\/pcX91+053py2cV5b9uQ++DI7xZsZsuerh4cHgMw3BvnTdRMxmlqvYnVeSzFGDZgXVDTAKanX40epz8H4GbbgsERoxekMeNQVIQ26EiGPrUDUZ3TGAYKWC+nOxrN2V8A+p7K9SAClla8aaKqbCiMvSly9JXG48pzDrvz1yYe7Z9MJCMmnMJTEBGiSJBpoijSNSgyMJm\/rrTKKf5comCdPvi12wA1NfrS5fVr9mwtYPXcVPZMTstLHXaOpTSYBqBszVzV1TmP5S0z6wsD6ZvW7MFamFUvpi09l+mjPLeY4uDwLM\/rA0jM0kauPd92ZvvOZvA\/YI0ujiy+Q5cwXDmydVoL86IsBmiCQEmIPINxpIPql4QDSDiQKEulSweQDor1VY2tQS1GxRIXSIRPPAQEQZi2GaFzfxn6DERZaZAOpKwVSq1Sto4UgCgalcqUVIn0QTCOP1tzgKIpHek4ZaeUYX6nTkDtXLWiUOgkhkCi7inXnHQifs+RMFE55XqnDsxpZZARVZskQaBKgqUSqmjEGnJjWTJ0dbMDwHGkrNRLp9hNthS25lEjdCggAFH6XEUcbqI4LSVdbbmWfpNk7f\/8tFnbrG3WNut\/Wv4ZALtiB20KZW5kc3RyZWFtCmVuZG9iago1IDAgb2JqCjw8L0NvbG9yU3BhY2UvRGV2aWNlR3JheS9CaXRzUGVyQ29tcG9uZW50IDgvTGVuZ3RoIDEzL0hlaWdodCAxNy9GaWx0ZXIvRmxhdGVEZWNvZGUvV2lkdGggMTcvVHlwZS9YT2JqZWN0L1N1YnR5cGUvSW1hZ2U+PnN0cmVhbQp4nPv\/fxTgBQAX\/R\/vCmVuZHN0cmVhbQplbmRvYmoKNiAwIG9iago8PC9TTWFzayA1IDAgUi9Db2xvclNwYWNlWy9DYWxSR0I8PC9NYXRyaXhbMC40MTIzOSAwLjIxMjY0IDAuMDE5MzMgMC4zNTc1OCAwLjcxNTE3IDAuMTE5MTkgMC4xODA0NSAwLjA3MjE4IDAuOTUwNF0vV2hpdGVQb2ludFswLjk1MDQzIDEgMS4wOV0vR2FtbWFbMi4yIDIuMiAyLjJdPj5dL0JpdHNQZXJDb21wb25lbnQgOC9MZW5ndGggNzg5L0hlaWdodCAxNy9GaWx0ZXIvRmxhdGVEZWNvZGUvV2lkdGggMTcvVHlwZS9YT2JqZWN0L0ludGVudC9QZXJjZXB0dWFsL1N1YnR5cGUvSW1hZ2U+PnN0cmVhbQp4nEWTS0wTURSGR4W2lD6UFloiDx8gYIIujBEIwURlYWJcGDVRVqgLTIzRGIyiItQU6IM+hxZbaKUIoVaicYNuXLhQ48KlGw0aHirl2XZKZzrT+b2jC2\/+nOQm5zv3nJP\/IgUIABIcvyhilcdKBj84rLMAw4MHNjIbIpBMcMhBErlkQQ8OeZwDVnvv8EjQ1G812foc\/hGrc\/qB6YnNE4hMTfVZPKMjzyxm2jbglZA0RugYwZd+s3wWHIdMFmspJBikWGSA1TTSGSSTEHkMeSYIIqThtj9LJVC283gedZ6iLpfq7RR1Qya7k19wSaZq3qas0Rtb8mT1C\/Pw0lMEIazTGeMFKOQny3WBAup5seLDDtk7tWJaLrdUVnXmKU\/oDGe35jdwOQRCUdIXL8Ljn05sgqKOletfaLZ8UlNfjNpvRdq3htKItvgWmTvJYqviBCPgfp+ZIEtJbigcTQNy1ekSXaRk+0et8n1h4Uye0leyyzm3hsUNsjRSsJkBXKFBATwZsJ8OLG1CVXyqSO80GF8W75zQVw4Za0xxAfNpLGeh0t3L17T95mEJ9grIkvq9Dh+pQKmP7D\/kmF9HPAfDwbYl0gAQF5Gvu1ZaQVOy9gTw0H33H2Lzj6+woBSHqw6YF1JYFKTkWV6K1PaLVQeDZeVRTVH3zwxcYw7SGCPikSPC5CDXnKmrfyzXdv3iMMsgDijLrtQ3RvfWzjQ1fC1QDsyuwhmmBeRWGNjpWCIDje5KR8dcU8ubkuquZQE7dt1sbI22nvrcfom9cI5Rq\/uTInrsVmIuDmTJsQwPlaZ9LAyfD1dvfK2otR45+txsh9ePyUm8egl5wfX5FQQmogQhxrvdZY6vobH5Ye0+t6HUuqfukXFvZ1l1T0WNaXfd\/ZoD3Vp9R\/X+62kRnQ8GCMLmNv2jQfLW4jLi60jyWBWxTgwMfFuTIlkU2ef3uOS3Qe+4KHmZddIOi8Pt8kWGQ6+7LWGTxzMY8tmCw\/aQxxy41+O95Q67LF7a5XvqpiWE\/AFRkmRq4a\/4\/8rxYAVJxIP4l0POH4SxN98KZW5kc3RyZWFtCmVuZG9iago3IDAgb2JqCjw8L0NvbG9yU3BhY2UvRGV2aWNlR3JheS9CaXRzUGVyQ29tcG9uZW50IDgvTGVuZ3RoIDEzL0hlaWdodCAxNy9GaWx0ZXIvRmxhdGVEZWNvZGUvV2lkdGggMTcvVHlwZS9YT2JqZWN0L1N1YnR5cGUvSW1hZ2U+PnN0cmVhbQp4nPv\/fxTgBQAX\/R\/vCmVuZHN0cmVhbQplbmRvYmoKOCAwIG9iago8PC9TTWFzayA3IDAgUi9Db2xvclNwYWNlWy9DYWxSR0I8PC9NYXRyaXhbMC40MTIzOSAwLjIxMjY0IDAuMDE5MzMgMC4zNTc1OCAwLjcxNTE3IDAuMTE5MTkgMC4xODA0NSAwLjA3MjE4IDAuOTUwNF0vV2hpdGVQb2ludFswLjk1MDQzIDEgMS4wOV0vR2FtbWFbMi4yIDIuMiAyLjJdPj5dL0JpdHNQZXJDb21wb25lbnQgOC9MZW5ndGggNzcyL0hlaWdodCAxNy9GaWx0ZXIvRmxhdGVEZWNvZGUvV2lkdGggMTcvVHlwZS9YT2JqZWN0L0ludGVudC9QZXJjZXB0dWFsL1N1YnR5cGUvSW1hZ2U+PnN0cmVhbQp4nFWS30tTYRjH\/4RuoougIgoCL4wIq4siuumHZBR1VRdFRYFSpAaRm1lLcz88287O2e+Nbbq5nIq2foNiDlExosIfrSLTNjV3tuV0m9vO2fn2HrWLXh4e3vf78vnyvs\/zQIgjH88V8qtABiA5l8uSBBSISJQUEC9I5\/SfRYhpiDz4tMvMslZXs7FVbe9Umb20yWG2ODQtdFOLSePoUpgDDfpWvc3rcbnpFiVQJLyZ8RC3+Tw4IAEsE9ss1v1jwCIkPbIMoQiWtoGsAijK9zOBsgrZzqPVWw9V7j1eU3Lk5q4DV7YfuLrtyJ3NZZWl5XWlx6p+J+DzvoIIfhW06Tnx2XOi7qZ2RNY2rWgL1zs\/kWhoDT\/pjdf7I3etn3Yfvc1lQOm8oogCjybd06iITWU36gOzj4MxWftXdXBO95a77\/9+2\/39XiCiCs6XlNeSdyoptwgIgMroWQB2nalW98dkPdN3PGP13ZPyzkl5z7e64Kw8ONPQNb7l0AWCWN1PRen\/goKiyR93nLyu6f+lH+JMwzF6YIYNRdlhThNa1AwuGEOzpWeupYFmiiIIxLzF6Y4UUHr+FvNu1jYas49ELYM\/7EO\/7KML+tAcMzTX\/pHbf\/bqnwJMFjMhsokkpWWWgMOX7vVOFZ59FYKTK8HPiY73Cy\/Cuc6pvPt90j8WO1hxPQ9YLBtFZulW0ot9p269nhBfTwh9E7mB8fTAeLZ\/kn\/zBX0\/EJpG+UUZX4RGyZAiI082zoyI05ebpzP4mUEkhRkOsTSmovgQxVRKyucuNwoCDFrnOmLQ+ghSVecJcwj\/RjyFlQwWY+BSiItS6z\/Po+ahL0s6qHWtIw57N\/F8ZOi1d40pqA497WP1LhPjZYwBudpf2xx4YHipNL9aysBqaSfI0tKyw+OPC+BEaahSRUgjkV0prq7yApI8kmuDR+qTzIEx2UXpvkiq3WJ1GdwdchWtNhi9bS5Wp3LZWINBr6QtJv8zudbWaHTqbQ4dw0p9kShpBvi1vKYU\/8WGzv93i79YUpgVCmVuZHN0cmVhbQplbmRvYmoKOSAwIG9iago8PC9Db2xvclNwYWNlL0RldmljZUdyYXkvQml0c1BlckNvbXBvbmVudCA4L0xlbmd0aCAxMi9IZWlnaHQgMTUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE2L1R5cGUvWE9iamVjdC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJz7\/39kAQCOiO8RCmVuZHN0cmVhbQplbmRvYmoKMTAgMCBvYmoKPDwvU01hc2sgOSAwIFIvQ29sb3JTcGFjZVsvQ2FsUkdCPDwvTWF0cml4WzAuNDEyMzkgMC4yMTI2NCAwLjAxOTMzIDAuMzU3NTggMC43MTUxNyAwLjExOTE5IDAuMTgwNDUgMC4wNzIxOCAwLjk1MDRdL1doaXRlUG9pbnRbMC45NTA0MyAxIDEuMDldL0dhbW1hWzIuMiAyLjIgMi4yXT4+XS9CaXRzUGVyQ29tcG9uZW50IDgvTGVuZ3RoIDY0NC9IZWlnaHQgMTUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE2L1R5cGUvWE9iamVjdC9JbnRlbnQvUGVyY2VwdHVhbC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJwdUktIVGEYjRatIlwUghG1cFME9gAXaWRFQ1pEUKRtTDAqGAyUFlbUZIEULVq0aKUgUliZDWW+QoXGykehjg8qx3Eeznjn3rl37mvu+87pu8LPzw\/\/951zvu8cB7xipx0oDqAbcEzwadiq98jnYVhwCnDoOw\/JoLIkPXVXcmCzWcOxEHyX9l\/v2VdSV7Sj\/MD+s48CnctLqpiD48KBIRqxvKURMoHIIvyNwe1b61qb+z99jE5NbgwP\/Wu62b2nuPbVyx8acdnUYlOx7SIWxcmK+8cOPUtH4OiIr8E0IQoQNhCexnlf++NAL1EIkmW6BZLXHgiVljRzCTAJiDxmprN9H37Pz2oSD4XH33mU7Ly8uJCnFtPxoPYWN7zv0iPLMDV0dAwnk7YiIx5DX++CwMHR8CXIXr3SxjKwbIyNRnYV+bi0t5P+z2GW1zJZhaBiMUtVMTmZiK6pmoYjZfUklcS87fl5usrPpMBzGBz6xQo5zdYlBVzWQxsYnMqbznpaOVHRJHNe\/ZvXE4fLakkJCZieWU1lGFmX5HyB5Vwhh9D3RV5SBdGtqrxtSJAVWBZ2F9esLEOVEQqtJNIZVuD5nK3poEFSKZflsLQkXboYID2W61FUn3r65N4Mz0CRMDo2921ibnYuMTISHh9bXaeNcWhvG+7qnCJDNcuk0eIr2Lblwtd+w9YhiuAF7xBOjvfsGAwqleUthg5itAGNYmNjYlw\/WNp8t2UoGvHcl1SXybg5Dg9bB2rOPCAHNyPhWSzINJ1DaH\/CuHGtu\/xog89Xf8t\/p\/pc3fGKxhfPRz0W4pJ1G9Zm6iicmmqYBhFZ4Bjv9mLpoSGZUqlYVmEUZAPMf2fmUK8KZW5kc3RyZWFtCmVuZG9iagoxMSAwIG9iago8PC9Db2xvclNwYWNlL0RldmljZUdyYXkvQml0c1BlckNvbXBvbmVudCA4L0xlbmd0aCAxMi9IZWlnaHQgMTUvRmlsdGVyL0ZsYXRlRGVjb2RlL1dpZHRoIDE2L1R5cGUvWE9iamVjdC9TdWJ0eXBlL0ltYWdlPj5zdHJlYW0KeJz7\/39kAQCOiO8RCmVuZHN0cmVhbQplbmRvYmoKMTIgMCBvYmoKPDwvU01hc2sgMTEgMCBSL0NvbG9yU3BhY2VbL0NhbFJHQjw8L01hdHJpeFswLjQxMjM5IDAuMjEyNjQgMC4wMTkzMyAwLjM1NzU4IDAuNzE1MTcgMC4xMTkxOSAwLjE4MDQ1IDAuMDcyMTggMC45NTA0XS9XaGl0ZVBvaW50WzAuOTUwNDMgMSAxLjA5XS9HYW1tYVsyLjIgMi4yIDIuMl0+Pl0vQml0c1BlckNvbXBvbmVudCA4L0xlbmd0aCA2NzkvSGVpZ2h0IDE1L0ZpbHRlci9GbGF0ZURlY29kZS9XaWR0aCAxNi9UeXBlL1hPYmplY3QvSW50ZW50L1BlcmNlcHR1YWwvU3VidHlwZS9JbWFnZT4+c3RyZWFtCnicNVJrSJNhGBWFAqF5WcvUIZbZtPSHqAglMRv+ELr9qfwRRbFMM0sTxbKLaYFFUCgZSgQq6iAlqRCTkGbbvGCaoXPOy5qfzsvUXdzt23c5vV\/hy\/nxvs97nsPzcI7HDxpg4PfwNh5g\/YAX8AA+2KwQKgQstt0CjcD+7+LlaA9LDr72UFdzG6PDz+8KSM2W5yuVVcPDFLPD3\/Q4vCwRx7aPdbpQcEO1LzS\/KE\/b2Y7+PjTUGx9WjB6KvfX2jYbhiDLNgLT63AxDnqlp11JSKtVqrK1gdgbGWaxbsWRCXw+OHystK68jsj6ed3qWyYTVNZ9lCfmTc5g0oeG94\/odXWbOq4LS3vYPMC1ibgFiSebPMYrlyUYuMlt0ZG7ti6mlLfRoWVHUg8j4+kYVYpKehkTcb1HBYMSnL\/N5yuccDbfbS5npwIAstwfaccjPdARL2uKSxgvKcO6SJTik+dRZjdmCaSOTcOAiXOBZdHeNZqTdGxvDHytCpbW7Q3rF0YYwqU4aPxIQ2BUuaVqgMLvAyTMqODv8XmjVFllc0fw8DItITG8Li9SJJNOi\/VpRRH+Y+Lss8dPKBtHn0o\/ehQPgYNTTB2NuDg1h1QFlyUTQnhax9EfU4T5xTGdAUFNZueu3Xlj5wunXNkpw0OdDTnZdYaH61wwMFiiL9bFJ7\/bGVUXJah49s+lGsLGB3NyXHa163oc16yrLwTANqVTZrFrQjGPdiTEDJkxYsqF\/ACYzPnY7FIoylrjFCPGw2j3EOfWAPfFIUXXN1OCg4BRlgXkJlAmVFROKk5Wk4uewtU27aNbl9xPvGB4arbv4dndUxGVFVnVJSWty8hX5icdPqr7NzHDkl3C8vPd\/6mw+isYmC444uLoM3g+nYyecQnoFOFmXk7P9BVdiCawKZW5kc3RyZWFtCmVuZG9iagoxMyAwIG9iago8PC9MZW5ndGggMzg1Ny9GaWx0ZXIvRmxhdGVEZWNvZGU+PnN0cmVhbQp4nM1dW3fbNhJ+96\/A26Z7Epm4ECT7pshyql1bdnVpT7rZBx9aSbRLXyorvfz7BUAAhESRGFJwV8lJMLQAfTOD+YbAEJJ\/PXu\/OKMcpVmGFvdn48XZj2cE\/UP+FKNI\/JX\/ZzRGi4ez80uMMEGLz2dvvlv8R\/atukQof3AHUYzSmA84KwcShJkcKEZvzqIB45wn6PezSPWefdDC5svZm9n4x+V4vkCXNzM0mo0vJgs0mf4kfjL5MFxMbqbonbhejGfT4ZVUIkJfxD\/5puiDAP\/9gFb\/+rdo75VVvyISpYM0Uy+xSGmZyE7ofP3wJUIXT+jHfSvE68IEO0446Z17ofDkX6G8xJcw1iwNLd+GRujhLE6Jkgor7bd5+QpLTR8h7be5ekPVRQu7TW4ACyPsNvnZ59NTaW6c1RJTVPSNB3FmYipzQoq2h9P0ZtA9XJpVwRE7pEuFi99FWMQJzt5F4g+OqEHvCUjwEcZfDBfjkNaT7KAyFXDEzqPkXJp\/pNk0xt3N\/vlm9s\/Lq5ufQ086E2mw1eyL6\/m70eRazXvEokTNPYuAPpC21HMHwXgQKw49GFnRaA4ZLNxnB2sZPhhHxA7WMnwwyarBWoYPZpTawVo+NBiQdQVrdIoTUmGl\/VanODGisNJ+q1MYNimsvDtUTW4ACyPsNibrnpRKwKyL016JZzL9gG4uLyej8ezvQbMvP6hThT8fDafT8ewtGg1vF8vZGC1kGpwPjmIiZkxFIpZ8KGXl2p2ojAYcmX\/tsZlkTAeClAor7bc6EDCzwcLQfqsnmpmJZmi3yQ1gYYTdRsfmaakEi80kywYptatM7AZn8ypztJwvbq7Hs7\/NxWpSLDWv1dqyT4z6k1DCY+NVIRVW2m9z7W\/bJ9OvOa32Wmy8FqPdJjeAhRF2GzPRJ6UScKJT2i0JmTlG0+H1GAVNQFKdJBpkXKqjfjggmMR8\/yWpaepoSpoj8vJpgyaP9+vf1vff7gr0Pbq6e9mi6d3D6i26XG+sfL2+vy9W6uKgRXaNRvCAJo4u73Cayp9Uu5YeCz8xAUnCmxPvcDYbTkXuR8v5BVpcoOvl1WJyeyUSsPg5Gl2NhzNxTxiOgIkYQC61SFCxaDcoid6YuK2OZM5ttHO03+pI5SZSOdptcgNYGGG3MeQ6KZWA5Iq7kmtyiSYXfTh1+ObKRVApix60qGyaw8KSp4cMcJSVW7A4Zvy4+39KrI5a7qIkYXG7llhQlh29Y8Ip6zObaLq8fj+ehZtQwqj1lpa7eIvyHkG5+Hg7FgtOZDJ\/OGsox9YaLXexhqkIjQcMN0Xo0+b5aXO3XT89HhWjzOERayZSw5TFiRyQybWBltVtu\/O2K8F2eYHt0gHrJYPT5qAs6ctwGrAwwm5jkvJJqQRMyl0LH8OLi9l4Pg+90iHR\/12NLDrkjQqSJzESlB\/O0fXwdjlE88XgrfhvOECj2fKXZkoJyxrIkGaDRLJH5a9MLN3KC8mG5kFSTcZl3wclUyzfpH2MBqLEARIX7YOIi0R2ocAOrc9r5dC3R\/hM7ZCtKRjgM6G89RnmYJ\/hxAESFwCfGSSyCwUse+LunBxNFh\/PRSQuxkEJoXTpSszRzXK6mH0Mmh84a2emtF\/ek6+H08nVsE9UiaVARUWWEBgVlWKGIaWWADIaLMVGg+Vlo+hYYamLjmxU+rXR8faHYzynCGmt8RHSOKvyHISSBktx0mB5OWmcVXmuIydjZVLbg5io7dlLs2YxYVXUxSnwBhCXvUp7St0AUWewVNQZLG\/UiY4OVtr9HsCSg75rzyG\/TG7R6Oaix\/MkeGmUZ4lerEmpsNJ+m4MWdL7FmAYsjLDb6PXjaakEWD9isYxPoqhHbXQyGSDz5FDtqHqVzvy7hJgR7VIpFVbab3PtbG7dztF+q13Gjcs42m1yA1gYYbfRs3xaKtlZ\/hXh0n+iwVmKeIrNmQVSO7NgOsjKpPyJPLBghNYjGwQTObBbOpheTubnI7HoRqOvq\/y\/68cv5y99zmXsGShLW6WB7LCBnPc0kNeql54102Z1v96eXz3dPd6v\/ghrZYw9VsZ9pzHuOI0Xiwn6abVZf17nO0WIIEtVqRDt6Pb5eHSkQjVvU19M0caYct9LmUNaZs506D5zhMuB3R01395tvx0ZkErrqMVFpkM\/s6KO8\/9h9bja3BVo8vj5afOgQgDNv65WW\/TpzUfx59N3R4cofBmdpXJdxculLc3kiot7l7Y0y2QvvYyWFxEBLKM1VkQdrIj6ltHUwVIXFVYAB0g9KgeU61O\/AxiLHKXkBcQBBqt0gMbyOyB1sdIotAOEHtYBMcFAB4i7sKMUBjpAYykHGCyvA0THCktdBHWA1KNyACcwB8SEuEoRmAMMVukAjeV3AHexOGlwwH7KizNPJpcdeqU8MbBj2fSbWGis7tHl8YWizqktIm668e08TTazqS1OE3Bqi9O0wpIXgNRmsOSFgxUwtZUOMOnGW\/DR2cymNpADNJZ2QIkFcEDqYqVRaAeYdEPcdON1gM5mNrXBHFBilQ7QWH4HmGxmU1tYB9h0Q9x04y2+6GxmUxvIARpLO6DEAjiAu1icNDigltoSz2pOduiX2upHQDypbbNd58XqBT19Fiu6vP6ws9+aVaWeNitNh85WMnkSs7OVD6vHe\/Fve+zmUE0O992YeN8bE+94Y3r\/J7q6+\/1Im9RUtNlkOvSbq642hZ0r5mMa68s0dgTTbu82W7GLevm6fg4wd202mg795q6zjcfMXePpnkwmYJ6p0+5KjlntdG\/74AQzO7gs\/EEf\/\/Qu1Q7Q7XJ2ezPvVaS1U5wNaCo\/DiWrf5yaaea1aa66dJ7oOO5eW7zdPL08r\/Lt+rcVGhVrMeEhbOTca2PZpZeNXcuLy+f7u+0Kjf9Yv2zXj18C2hm7c5ketDPuP5ddC4yjb5uNMAwN8\/zpm2hvnlePwt4QhlL\/hNL+E9q1cHmz\/bra\/HUbOFYuXssPJaTl6t37hJfJgqx56Cq3zYDnu8wpABggbwEAy22CQVIXBx\/vwp8MypW2fkBD7AMaoh\/MOG0OeojjewCjAQsj7DbmmdFJqQQ5WcZE36TH3eZqMl\/IoxzyPP0cLW7Q+zH6aTybXE7GF2HP17NybxwlHR9GPQGVaClSlDtUIvnEsRI8VQ3VSZdChBxh+H0\/SQdic9LZzMWfzyu5vht9e9k+Paw2YN83W8Eds3HCAHZzx27e0W6cZoOYdTf88ltRqE8+oE9v\/B+P+PRdAMfghFaeYRgSEdp\/OunJiy6+YUnS3THD+\/vN6uUlgL0MO5Eg0pLioddk7Rh9R8FVOLSdXiHVEHXRyUvyQDlLa26qXIJ7HZgqjY\/wblC3sz+q2K8LXJ4xqo8smikQKcA\/6YDbrQadI\/emgQjvRW57GoiqNAByAHccIFE6eaAc0OKC4z+C5M8GEQbHuXZjlQ1ALtJApY8kUCcflQNafNR+XBr1OvxrMkfkZg6ve7QTq8wBco\/GKt2jsYyHPCknclKOgxXiWcphXrcmD5Y6yYPDkwc3INwXFh25X2dlK\/et\/hyoP3f0VyjhDGjkTDs5rQmlOh3IyS1QOCP6Rba21mERxA6DxV0sDmGRxVIX\/BVYtB\/g7SziDosYnEXMgLDQLKrFdzuLuMMiiP7c0V+hhDOgMbg9LOIuiyA2GCBmgcIZ0S+ytbUOiyB2GCzmYjEQi7jLIvYKLNoP8HYWMYdFBM4is1dmJDSLavHdziLmsAiiP3f0VyjhDGgMbg+LmMsiiA0GyO5PAxrRL7K1tQ6LIHYYLHffybz7zpI4LovIK7BoP8DbWeQUg1gEZ5HZczLvNrgri2rx3c4ip6gD0p87+iuUcAY0BreHRW7xBWSDAbL7uoBG9Itsba3DIogdBsvdgzFQKYa5pRgHKxyL9gO8nUVOUYXCiyrUbL6od7vclUW1+G5nkVMTAenPHf0lSkADGoPbwyK3aAGyQQNRuwELaES\/yNbWViwC2aGxqLsHo6DqAnOrC\/QVqgu1AG9lEXWqCxReXaBm80VDVxfq8d3KIupUF0D6c0d\/hRK8ulAP7nYWUbe6ALLBANkNWEAj+kW2ttZhUYfqAnX3YNS7ByuJ47LoFaoLtQBvZ5FTXaDw6gI1my8aurpQj+92FjnVBZD+3NFfoQSvLtSD28Mit7oAssEA2Q1YQCP6Rba21mFRh+oCdfdgFFRdoG51gb5CdaEW4O0scqoLFF5doGbzRUNXF+rx3c4ip7oA0p87+iuU4NWFenB7WORWF0A2GCC7AQtoRL\/I1tY6LOpQXaDuHoyCqgvUrS7QV6gu1AK8nUVOdYHCqwvUbL5o6OpCPb7bWeRUF0D6c0d\/hRK8ulAPbg+L3OoCyAYDZDdgAY3oF9naWodFHaoL1N2DUVB1gbrVBfoK1YVagLezyKkuEHh1gZjNFwldXajHdzuLnOoCSH\/u6C9RAhrQGNweFrnVBZANGojYDVhAI\/pFtra2YhHIDo1F3D0YAVUXqFtdIAerC\/CTtISb3\/4hpcJK+21u0EyfVL\/mtLkmEiqMsNvkBrAwwm6jT9KelkqQk7RSn7jHSdr57Xg0GV6hyXS+mC1Hr\/fd48T+jhdif8cL0b\/bxW1zkNt9LtOAhRF2GzPLJ6VS0yw3u70DxbC1FFsrsNbeaXOQN3yWaMDCCLuNcf5JqQT7GlSC+1BMf4PV+AK9D\/qFhzjBPTUaLhc\/3MwmvwRXibGkp0qjH4azD2N5lP92NAqpEo2yniq9X84n0\/F8jpbTySLgx\/t4Ju6thGRyyVHK+MDyoWn5l9jBWoYPZiy2g7V8aLA\/l2NmvoJOSoWV9tscxG8fNzVgYYTdRqeT01LJSSetQaByYCmX79clCNTgUu4w2Ex8ZIPg4OBGOqnvsMqavz\/cHHo+8svjGUvbcWhEWg7Ww2wRtnPc9lXoj9u7fIumTy9\/\/\/7YL8MXm4u\/DixLB1mG5K8GaMR7Tu\/uH9aPKNgvSBM7O\/ZamA08EPOXyAiWHDIykAZqPvRgGrGmwZ5cmAnUWH3UmjMlFVbab\/PylSQyfYS03+bqDVUXLew2uQEsjLDbyFx4cioBllYZF3hRc9xgQlnMkzTM72oh1LhITbzS3Uj7ba6DIzJ9hLTf5uU7qj5G2m9zi1pYab+Vs3e6ugGmkdCQ8\/g\/XRlAmAplbmRzdHJlYW0KZW5kb2JqCjEgMCBvYmoKPDwvR3JvdXA8PC9TL1RyYW5zcGFyZW5jeS9UeXBlL0dyb3VwL0NTL0RldmljZVJHQj4+L1Jlc291cmNlczw8L0NvbG9yU3BhY2U8PC9DUy9EZXZpY2VSR0I+Pi9YT2JqZWN0PDwvaW1nNCA4IDAgUi9pbWc1IDkgMCBSL2ltZzYgMTAgMCBSL2ltZzcgMTEgMCBSL2ltZzggMTIgMCBSL2ltZzAgNCAwIFIvaW1nMSA1IDAgUi9pbWcyIDYgMCBSL2ltZzMgNyAwIFI+Pi9Qcm9jU2V0IFsvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJXS9Gb250PDwvRjEgMiAwIFIvRjIgMyAwIFI+Pj4+L01lZGlhQm94WzAgMCA2MTIgOTM1XS9QYXJlbnQgMTQgMCBSL0NvbnRlbnRzIDEzIDAgUi9UeXBlL1BhZ2U+PgplbmRvYmoKMTUgMCBvYmoKWzEgMCBSL1hZWiAwIDk0NyAwXQplbmRvYmoKMiAwIG9iago8PC9FbmNvZGluZy9XaW5BbnNpRW5jb2RpbmcvVHlwZS9Gb250L1N1YnR5cGUvVHlwZTEvQmFzZUZvbnQvSGVsdmV0aWNhPj4KZW5kb2JqCjE2IDAgb2JqCjw8L0xlbmd0aCAzMTU3MC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoMSA2Nzg0OD4+c3RyZWFtCnic7Lx3fBRV9z9+y9Sd2d3ZzfYkW7LZTVlKIKEEoixSpIXegkSCdBAhgCgIAkoNCFhAQRSwgooECBiKj4jYRVAURRBQAVGkqIglZPd77uwmwvN8Pr\/v8339\/nU3M3Om33vO+9R7NwgjhAxoNqLIP2z80IkPfPdxYzjyCkKBp4dNneJfn\/bFeYQyuiEk9B05cdT49256As5nr0OIvzjqzmkjr7Yx7kCo0XKEhi8dPWLo8C\/eO70boUf98Izmo+GANd8eg\/2BsJ85evyUe6\/eHq+B\/RkIFXx254RhQ3n3Y\/Cu93rC\/pfjh9470dqNP4lQbTZc7584acTE0JHiN2C\/E0LKv+AYTS5piLUbaYNgDyhLGeK0mxHCBbAjogJ0P44TPykhm2iQ9qAT6N30flpBl9D19GN6lTNyPbj5fAr\/Lv8jf0Wggl1IFXxCK+F2IS6OTx+bPi79rfQP0uPeWd4nvT97\/\/TZfem+Dr5i3wBfie82X6lvpq\/Kt9932HfMd8l3xRfzm\/0Z\/rC\/kT\/PX+Bv5S\/y3+xv77\/dP8E\/y\/+Yf3uAD6QEnIGMQDjQKNA90Ddwe2BuYEVgQwbJEDLMGdYMe4Ynw5eRkxHJ6JQxNGNEkAS1YCCEQiSkhrSQLeQKpYUyQw1CBaGi0J2h2aG5oYWhJaFHQ+tDr4S2hnaF9oT2hz4KHQwdDZ0NF4Wj4VvCZeFh4ZHhceEJDe5scE8j54ueFwM1pKZ5TVHNzTVta9rXbKn5oSZ+7Y7aNrW\/1F6LBWPX4tficcZxtI4gEiCDyKs0k\/akU+h0Ohe4tpQ+Sw\/R3zkT15NbyD\/MH+IvC0hQgGteISBEhTKxZzoCrt2Zvj895kXe2d513l98yOfy+X2dfD2TXBvim+3b4XvHd8T3te8X31U\/8luBa7nAtab+wnqujQWuLfev07nmSHKtONAncBtwbXk91yzANXeGN8m1sozhOtf8\/wvXetZzbXloXeileq59AFz7ErjWqp5rI8JjgWtlDaYA15wv+mtwTXpNS+BatKZdTceawzXXrt1ee7PONX9sNuNa\/DuEuEuwfAoacRMsOQyXsTFszR0CKhfpn2uHrn3Ir4ftp6j+c7E5Qpe4S8UInZ+F0FkOtvbzKect583njefV88p5w3n5vHheOM+fp+fJefQjkxE6NQ+WFbDMPfXnNxtO3fPTWKBf+6kQ1hWnZiJ0cuzJaad2nT\/wXYNTS88\/cXLDyZUnVp545sRihE68wO4\/6TxRfmII7OWdiJ7IP5F5vOPxDseLjhceb348\/3je8ZzjGcdTj9uO42MXj50\/du7YmWPfsruOvXPsjWP\/OvYaUG8fe\/7Y5mMdjt1yrO2xzGMZxwLHvKdXnXr91I4Tu0c6R1p50FNxjfikuFpclein8INws\/Er4yfqjzyiw5i+4qagxheBQ4OBY+1hmc0vhPUjfDVcrcLSXHhGrE7cLXlhyZOaSsOldfIJMFYOdtRgTS4d0f\/lYygw9Ib1RFimXnd0or7WjxjW\/K\/3zmeLYWFyb+7\/7V3X3TnYcHs9Pei\/uL6onhqpFCmj\/+MCip5Fc9E8ejtaic6i+WgpWoyeQhvRc0hDFcDSB9Gj6DL6GT2EHkcLMUbH0SX0NHoJ\/Yp+QVfQM2DR30PvoE3oDjQMLUfD0QdoBHoXvY8+Rh+ij9AB9D0aiT5BB9Eh9CoahS6ih9Fn6FN0GI1GP6DzaBEai8agcWg8uhPdhdahCagcTUST0GR0N5qCpqJ70Dl0L5qOpqH70Ew0A72G1qNZ6H7wK3PQj+gntBOvxI9jginmMI9q0DX8BF6FV+MnUS2KYQGLWEJxvAY\/hZ\/Ga\/E6vB7L2IAVrOJn8LPoKvodP4efxy\/gF\/EGvBG\/hF\/Gr+BN+FW8GVfiLXgr3ob+QJ\/jCrwYV+HteAd+DVdjIzbhnXgXNmMNW7AVnULf4BRsw7vxHmzHDrwEv47\/hd\/Ae\/GbeB92YhfajCqxG3vwW3g\/TsVpOB178dv4HfQn+gt9i77DPuzHAZyB38Xv4ffxB\/hD\/BE+gD\/GQZyJQziMD+JD+BP8KT6MP0O7cBbOxjk4F51GZ\/DnQoWwWFgiPCQsFZYJy4WHhUeER4XHhBXCSuFx4Qk+U1glrEYvCE8Ka4SnhKeFtcI6Yb3wjPCs8JzwvPCC8CI3lhsnbBA2Ci8JLwuvCJuEV4XNQqWwRdgqbBOquDu58cJ2YYfwmlAt7BR2CbuFPcLrwr+EN4S9wpvCPuEtYb\/wtvCO8K7wnvC+8IHwofCRcED4WDgoHOKucbVcjIvziMc84SnP8Twv8CIv8TJv4BXhE+FT4bDwuXBE+EL4UjgqfCUcE44LXwsnhJPCKeEb4VvhO+G0cEY4K3wvnANd\/1E4L\/wkXBAu4iP4C\/wlPoq\/wscUq6iJFtEqpog20S46RKfoEt1iqpgmpote0Sf6xYCYoaQoNsWumJWTyinlG+Vb5TvltHJGOat8r5xTf1Ovqr+rf6h\/qn+pNeo1tVaNqXEjMmIjEYNiphgSw2KWmC3miLlihA8pDsUpzhbniA+ID4pzxXnifHGBuFBcJFaIi8Ul4kPiUnGZuFx8WHxEfFR8TFyBjqCT4kr0pfi4+IS4CqzXk2DFnhKfFteK68T14jPis+Jz6Cj6Ch1DJ9AX6GvxefEF8UVxg7hRfEl8WXxF3CS+Km4WK8Ut4lZxm1glbldcilvxKKlKmpKueBWf4lcCSoYSVDKVkBJWspRs7hHuUekWbrrUTmovdZA6SrdyU6ROUmepi9RV6iYVS92lHlJPqZfUW+oj9ZX6Sf2lAdJAqUQaJN0mDZZKpdulIVIZt0LJUXKViNJAaag0UhorecoPyo\/KeeUn5YLSRGmq5EsPSUulZdJy6WHpEelR6TFphbRSelx6QlolrZaelNZIa43UyBl55MWX8GX8Mz6Of8G\/4iv4Kv4d\/4H\/xH\/hCK7B13AtjuEGEFshggkhlHCEJwIRiURkYsANiUJUYiQmYiYasRArSSE23IjYiQM3xnnESVzETTwklaSRdOIlPojRlkC8kYGb4KYkiPNJJgmRMMki2SSH5JKIUqA0U44px5WvlYvKJeWy8rP0LmlAGpJGpDHJI01IU5JPCkgz0py0kN6T3ifTyX1kBplJ7iezyGwyhzxAHiRzyTzpAzKfLJA+lD6SDkgfSwelQ9In0qfSYekz6XPpiPSF9KV0VPpKOiYdl76WTkgnpVPSN9K30nfSaemMdFb6Xjon\/Sidl36SLkgXpUvSZeln6RfpV+mK9Jt0Vfpd+kP6U\/qLLCSLeI23SDXSNd7Kp0i1Uoy38XbewTuluIxkLBPexbtlKnMyLwuyKEuyLBtkRVZ5D5\/Kp\/HpvJf3yUbZJJtljffzAT6DD8oW2SqnyDbZLjtkp+yS3bJHTpXT5HTZK\/tkvxyQM+SgUZBDcljOkrPlHDlXjsgN+Ew+JDeUG8mN5Ty5idxUzpcL5GZyc7mF3FIulFvxYT5Lbi0XyTfJN8tt5KjcVr5Fbie3lzvIHZVflF\/lW+VORtEoGWWjwagYVbmz3EXuKneTi+Xucg+5p9xL7i33kfvK\/eT+8gB5oNFoNBnNRk0ukQfJt8mD5VL5dnmIXCYPle+Qh8nD5RHySHmUPFoeo1yRx8rj5Dvl8fJd8gR5olwuT5Iny1Pku+Wp5CGylCwjy8nD5BHyKHmMrCArld\/I4+QJsoqsJk+SNeQp8jRZK9+jXFV+V\/5Q\/iQ\/KS8ozysvKhuUjcpLysvKK3y+8he5SC7ROfRBOo8uoIvoQ3QZfZSuoKvoU5ADPE830pfpJrqZbqHb6U76On2Tvk3fpwfIZfoJ\/ZwepV\/Tb+gZ+gO9QC\/Rn8nP5BfyK7lCfiNXye\/kD74lX8i3UjYpryqblRrlmlKrxJS4isif5C9SQ66RWhIjcYoopoRSypGfKM9n8w341nwRfzMfhbtv4dvzHflOfBe+O9+b788Poj7+dv4OfiQ\/lr+Ln8RPpVn8dP5+iIse4Ofy8\/mFfAW\/hF\/KL4cY6TF+Jf8Ev5pfQyP80\/w6\/jl+A\/8KX8lX8Tv4Xfxu\/g3+LchsPuQP8p\/Qhvxh\/gv+GH+S\/4424b\/nz\/OX+F\/53\/kaPg55jwgxvFmwCCmCk54X3EI6ZEF+iOgzhEwhLGQLuUIDoZGQR5sJTYUCoSVkSDdDtH+L0J5KQgeho3Cr0EnoLHQRugrdhGKhu9BD6Cn0EnoLfYS+Qj+hvzBAGCiUCIPgzG3KFmVbHX+ogSpUTfBHGCyUCcOF0cIYZbtKVEE1qCbVqjpUj+pVM9Swmq3mqg3UPLVAbakWqVG1vdpJ7ab2VPuqA9XBapk6XB2tjlXvVE4YXUY3\/hqfwCfxKfwN\/laOG5ABG4iBGjgDbxAMokEyyAaDQTGoBqPBZDAbNIPFYDWkGGz4O3yau8r9zv3B\/cn9xdUoHysHlUPKJ8qnymHlM+Vz5YjyhfKlcpScIz+QH8l55W20BW0lFcLbuABtRzvQW\/gM2oaq0H7lHfQAehMtoN0h7+wNOVQv\/BBeqrxL+9H+dAAdSPvQvoaYIa4g9Bv+XsEKwS0UqnBkL3c\/2qOAu1VERVMs6sfqQfWQ+glZrHyFVqELaB96Hj2C26BluC2eih\/Gj+BH8T2oGs9QZGGKcLdwD3lH2ansUnYre5TXlX8pbyh7lTfJu+Q98j75gHxIPiIHyMfkIDlEPiGfksPkBDlJTpFvyLfkO3KanCFnyfeAzpsAjX34vnw\/6qN+GqAZgMlh\/HB+BOC0B9+T7wUoHcKX8UMBuV35bnwxYG0\/\/zb\/DuDtI\/4A\/zFgdzI\/hb8bUDyBn8iX0yyaTXNoLqD5Pn4GPxOQvAjwvADwvBjwPYtGaANA9cO0IW1EG9M82oQ2pfm0AFB6hf+NvwqI\/Ym\/wF8EnGqAVCt7J+DUK4wFrI4T7qTn6Y+w\/AS4bAvIbAdIP8V\/w38L6M0BDGcBhiN8RyFPaAKYDgGeGwKKWwtFwk18Dp9Dm9Hm9Fd6BTISASVKCvAB14YQ+bf4G05SjhdESTYoqtFk1izWFJvd4XS5Palp6V6fP5ARzAyFs7JzciMNGjZqnNekaX5Bs+YtWha2al10081tom1vade+Q8dbO3Xu0rVbcfcePXv17tO3X\/8BA0sG3Ta49PYhZUPRHcOGjxg5avSYsePuHH\/XhInlkyZPuXvqPfdOm37fjJn3z5o954EH586bv2DhoorFSx5aumz5w488+tiKlY8\/sWo1WvPU02vXrX\/m2eeef+HFDRtfepm+sunVzZVbtm6r2r7jteqdu3bvef1fb+x9E721\/+133n3v\/Q8+\/OjAxwcPoU8+PfzZ50e+QEe\/Onb86xMn\/6mh\/FND+aeG8k8N5X+oTvxTQ\/mnhvJPDeWfGso\/NZR\/aij\/1FD+qaH8U0P5p4byTw3lnxrKDTUUfhdyw+LhX0RuLoxcCMW\/h+Uc28bGxM+x82xLfoRYvDq5ILQBbcJjIKp+A+3DlxGLIHcCCt5DTtQerYE4+DG0AAloEBxZhHrDl4fjj2F3vAo1hgiZwnIArh0AkfIu5MCu+A8QNc+jh+GueciIMlBb1BNi7Ydwt\/jdaDA6yT2IWqBuEIFPxLPjA+NL44\/EnwNc7KTvxWuRgjwQ2w9DB+IX+S\/jx1FDuGMFYOckfkTejqLwltlw5VMQta+mpRyOj4r\/BS0IQOx+AHGoGB3Ae0kEnj4CfY9deAZtB095Nl4Z3w9XpaFSyARWQ1TbDN9KAvzgeHH8AHLAO+6Fp65CW0EHdgBPXkdfYZW\/HH8ufhm5UQPUGfpThT7Ge2msdk6sDXCMBy7loEI4MwH9CzKQQxA9v0km8CrfFCzj9PhnyIaaoH7Q2hfhzrP4d\/Dl4M3pO1zH+C3IBHx5mHEbvQ3RvAeiih64P8QKE8jTdBKS4I1N4DsccpVF6Al4+gmIW3ZATHKQPsu9zNUI6bFTcRNIJIyehOzpTcgRXBDTT8YPQKz6HWlHhoCH+ZY+xm3kPhWHQq9vh4znIfQy5B9W3BL3wrfh0XgGXgD6twoi\/0P4HGlL+pJx4GtG03L6OncLfPtwk7kHAeOLhXOxgbH9sU9iv8ebxuejXoCHOdD6FZCXVQFODkI0eRSdRN9iHjIdE3xZdtEP3wff+8FqPKPnOlXwlkP4W\/wDRGS\/4RqIvBBEXKksaoJvkEwi94CXXAOazXT7J\/InddIM0KpmtIiW0AnQqgV0OXy30284D3cQ4vym8F3JrwWv8TK\/j78sqOIDEpI+uvZsbW7tiRiKLYytjG2NVcW\/QXaQoQe44ENF0Pqh8B0L8l4JiNuMDkNu5gIJ5OKbcTfgzBA8Fpfje4GTcyGve15v+6uQaR2AHOAStNkIMR9rcyOI1m4hPeB7OxlBysHTP0KqyBHyFxXBK5ipnebSW2kpHUGn0Gl0Ja2kH4E3\/pZepdfgG+cMnI\/L4MJchLuVG8LdzT3Nfc99zw8G+3NGMAjjhfmQAf0sNhdvFnuKvcRSiPF3iJ9JZcxGg6V+7fqUGp+CCKED3Y6WknzODdbxY8DzEDScFhNAKtmAF5KZuIpk8vcKrUlr3B1d5sLA63fIWogDWtNi3BX3QWNJk8TTBBv3EmyKuLfQBW4P9O1jePK9gorvJ5cEFW3FiBTCO9+meVyEfoi+oiexyK1HxzgD5J4XyIu0J6Dgde5mfiAK0DXoVVqOZ6LtpANChhppCeC4O34J7EJf3BT\/QeOIku6Aohb0O8j8x5EvwUPcgxaix\/FwbhRaivLxDMjoXwCtyOHvAhtox++TMVwFScFViHAboXeFkLNS3obm4lK6WrhEjkImf5AzoBP0FWj9QfIqLeYu873xaNCAmWg+Ko\/PQdP4gdyneBQ47v4oxJ0C6zaDNuUCsJ0FVmUw2LQdoN27wA60pcVwxAXI6Qa46AcWYjV8nwA7wQGCxoCODwAr9jGqEvqSajSKN2GwOghxH8Z6o0HxF9Cq+Ch0V\/wR1BDswYL4DHjiBnQGLUMb8LzYfWgi8oLmnMDd+I7kIN8x3pBUkKOkD1l5o3yB2yHI6n+E76uwczO\/G1VwX6A+qE18SfxzQHc2WNhV6A7UBXL08egivKET3YvyY93JlnhHOhH6exL1ir8Y92EDGh2\/E\/VAe9DzIo+GihGQcSX+FPp7HxpBesen0BGxMcCHZcCFKHDrbrA\/i6Lt+vVtG21z801FrVsVtmzRrCC\/aZO8xo0aNojk5mRnhUOZwYyA3+dNT0v1uF1Oh92WYrVoZpNRVQyyJAo8RwlGDToEO5b5K8NllVw42KlTQ7YfHAoHhl53oKzSD4c63nhNpb9Mv8x\/45VRuHLkv10ZTVwZrb8Sa\/4iVNSwgb9D0F95oH3QX40H9RoI9EPtgyX+ygs6XazTy3XaCHQgADf4O7hGt\/dX4jJ\/h8qOU0dXdChrD4\/bohjaBduNMDRsgLYYFCAVoCqdwYlbsPNmrBPE2aHVFoIkIzSq0hNs36HSHWzPWlBJQx2GDq\/s2Wtgh\/apgUBJwwaVuN2w4B2VKHhLpTmiX4La6a+pFNpVivpr\/GNYb9Bi\/5YGeyuWVGvojrKIOjw4fOjggZV0aAl7hyUC721f6Zx+2vX3Ljzc2m7gguvPptKKDq4xfrZbUbHAX7mu18DrzwbYuqQEngH3klDHsoqO8OolwMSuffzwNjKvZGAlngev9LOesF4l+jci2IEdKRvrr5SDtwRHV4wtA9F4KipR72mBrR5PdGf8FPJ08Ff0HRgMVLZJDZYMbZ+2xYYqek\/b5o763Teeadhgi2ZJMHaLyZwkVOP1xIj6czqlX86orr3rOYtZi4KdARCV\/mF+aMnAIPSpJVuNaIkqhrWEy+BTguGuyuEgkTGVcruyCq0VO87ur+RDWtBf8RsCBAQv\/HTjkaHJI0JI+w0xkuGkHmpwvo6ujEQqc3MZRMR2IFNo4836frOGDaZWk2BwouaHDbAP9QTeDi1p1RjYHwgwAS+ujqI7YKdydq+BiX0\/uiN1K4o2jpRUkjJ2Zm\/dGXs\/dmZ23Zn628uCgOQqfUzNXimF6\/\/MmiOlw+hWldjx\/3F6ROJ81z7Brr0GDfR3qChL8rZr3xv2Eudb1p9LUpUp7QbSVJKkSCrVzwIoB9dfzHYGqpVcCP4EHdTDq0UJUKkfwf6OlVpZp8S6xBAI\/Jc3Vccvs7v0zd+3JZtZ2Spy437rG\/ZvaJ5aQaHB4Cq79h1UUWG44RxALfHCzskNIB71HRjwt6tE\/UAzQ\/BXHd\/bki0lqZVRYFk7dgHgL3EouXvDhalJugQ+DJ0NG3QEQ1dR0THo71hRVjG0Oj77jqBfC1bsJPvIvoqJHcrqgFMd37U4tbLjkhLg1WjcCpSCoFu2BPHCXluieGGfQQN3agj5F\/YduJVg0q7slhLGSNKu78DrpaerRElDQAPBeoDLs2q9iFDAErCEYIXB6V3z073Xoqz07ef2shHZQXQbzoKsgkfhqB3xFPMXCaJz\/Hg5JnisUP6iK6JdLb2A2lzAFmthYZO8FNos304XNjqQB3daf\/stdhGeMiPWi5Txh5GGbooasswYaVZR0rRqnL8NrTVJsI1axLWm2xHVIJ+j9BXLU0v0B9devaBdhacXtSlqkodLcZhYClo0b5EviPC1axifXPFx8aA9c6Zl3RSM4Eis1x78BzZd\/Kq25lBJxcrdr8d8Mf8N7x8RVbNJtkZkg4aRVWYtMKylGLZVaC293QS4qtI00g+IP6rMZp04XWU06sRPUbPBQPqZTT4TMb1iTbYxAp9\/a2dKEFkKssLwzXeAx9RI7RwciWTclDV9zp5BxQdjvVjuv2fnyopBn9bUfnUx9ktMglZG6TDyObTSheZHu0DObUjFqQbOIKtsKFwUFExczPuKiKOS02oUwfcyf6y7Y\/DGNk6kEjYIPCTtmt+GbW8IPFKeF6rxiqiRfx5FLSkFyO2eCK3url2JFF+pPQ0Nri0tKmxcZHUWwh+IUN+yTZM8VJrSwuGELghi8xZOQXQ4xXCWIGY1bxGONlrbKQU\/TG2j5jWaNf2mCfe26tGl5dQpTedwm5a2zNneftiKggZLc03NFvbrsfChLv2WNXIzLL0UO4EfhCzOgLpvNwD0Xoam9YyGMS0iBBtwETIQCjtIaCm26gER7gSI19YB8tYp658ATl8pvXJau1CkFQHYYK1d0Gp10DXJywfI2VjLmrfYcaDngKaFzemBA+WLw8XuobfBe9viajKWjAe0N4i6J5KJlBTjYnhlEBEPPxEucHMTH2JMOV2qnUWNiy9A38tBiM0C9rYkB1dv385avwtWC6D1FIWiLsIaW5Ro4mbErYPz6zi9lVdLdW1INGrXgQMH9HkN8e9JIUiWoj47EY2f2GorJNXxE1G\/rfBxigldSzdTQqcibGNTIzBcZ6DnEDkHuNwIL+e2TYcnF2lXLmgJjC3gG0VKZ2r7GdYiETvOx3jj8thAN\/\/TXzY2r6Jf\/HvOwu8FvKfjflsIMwVRg8fL8Tav0eiUq+PndGwzIupm4JYtSGVHkENVYa2yY6gxAPsArA5Af1iPUrcI\/\/mkK\/AkgT3pLGiJTlyMuhVFYI\/U2BGkqSpbs2P1j\/z7mVWC362lgdptJX7lXxBKOGCxwmKOn4rewQkLyEJlofl9Ey+Liot0SOlm7+Jul9o3ZbB9sLt36jhxnDIs5U77OHdZ6jRyjzBVmW5eIDwhrtTed31FjghHlGNmT31zJ8vRQLAgT8ZI1mQiL\/dZJiOwyFETHPVDQEzQcu+7ixNKDfpcWh65kGwmLi1Hpagl+2BYSkpSNGvz\/KYOhxWUWwhmZIVTNEd+0+YWLRzMEIV+4w6vm7p1yi1jD6\/\/bNrDOzfOmLFx4\/0zupSSw5jDN70yZFss\/lUsFntr0xOv4adij1+6DPn62Itj5jOsnAQB1oDsDGhz1E+jRkvBOG4WWUZWSdwrHJaRwBMq81gl+AOD3noD6xPCzM5Vx0\/p1guIH6MWXaBpukBNukCBy1E3E1edTHT5eFQ+ajQX8HWcyOOxn4\/yhHcru3ARnocSqlEeAb5EEh\/YKSquBUVsw4xGIeMPKo0EghZBEJuBFuaTmqq2h\/s+\/m3jKdx9N8\/wvXrrB0NY34oAyyL0zYvfTWJJtmhGV0qK0M\/IoGSx6MTFqKxpQHltvJdB1Mku8HrZWW+aCc54VdZybzXZHVWJwen0+zQLIX4fWIPGnx1g6wOo8QXW0jZsvb8pAy+pf6FqtRL9hVHZbCF17zkVVawppJ\/Xxo6xZ2+FRzNVURTSz8msv87F\/+ltDM\/sfext+suizVvzrYXd\/BvCbvFd6f00sbNaovY1jVOHm6Zbp6cssu6xnvGcSb3sUd9QXkshqVqalq55NeFf8ctIBPBLsJVBWh6vQZME4YM0jy0tzSOlecBaSJ40avRq1eS5bT0s2FKNXdtZD5DODjMmqmGy8zBwm2Ed7yZzkB9puGVUtWxvQ4aQCWQW4cgukol8eNmWBNjBrlyNMPPC\/EFRmwu1pactde5ggalRxASmJmFpUZ0GtESluHRSSUnIHgi3AIk3b96sAKCvG2HQCzDH4KAFkROvtSDO0LOrL21Ydd8Da\/DOlD8+OXy104v7nhns3bSpbdGwvffvPzNy3KNrKlIOHv1x08CX9jy3cGgTQEr\/+FnOAUiJ4JKk4BS3K8r470pDmEE1osIOzgkajGbV7DUYcuzeNM6bk8bnGING1eUG9+7XGPj9YphJkV0ebsysz4HG7IushW3agBO5APK78I72jrVQ2x9pyhYmv2ze6DB2MM43ch0sAyxTU2lvx53aWNtwx93Gabb5xgrbotTnjQbeT3XcsOlqnIjhvZiJJQod2I1ZAdGIm1Wpqp1z7SLPITcZHc2CVvLQTKN18hD\/BD\/xuxiS\/bPFyWHdNoUxCmthAi2+8ho7E17e0FWNW251H8a7cEtwJHujyt\/WqkE1fmRLncHSpchs1pVIacJu1Z5m4AQ\/yeSZECeoKggQtBWXl4B7ZzZLF5zYop6skyETosjWKJgR7l\/lWzFu1uZnZuZ3s1mVydXzx45ZYqsK\/PjqvR+MGzn8geWxc0fejOMHXasWVD4wY73taXLvzGEPzJ3r3\/7uqK3Dh6xp5H196d7Yb2eh0R6wARpElAZgTjja3DpQHa2uVjeq76t8N9rN+BhHrYBxpApU5A0KFZEKyv4B5WyUctSIiGqEOGc32Y0kCGTXRQ2I4+AS9IGBqyYjX+N5QzTdV2Cos4SGhGPSiYu6hzJU4xZRoxjNCBaIswPNxOVmwuCkGG0FiGjETyhhN7N7gDi9g91Dtpuq8RKd0z+B9dMN4RVmXoq0s5puB7UrRVeLLIWFehS8oFGEA5Uxm83AbshndiIj+HxrIZicz6JKfiHNaFhIufT0IvaIEhAGXBO1qVGlUJ3ds1CNhgvVjDTYNizUrW0JBOfNcL4l3x60UAsmK2vnkqcefeedqlgzPOR5uuNal+dj60GpV9SOA+Ax3x\/gXwAb2z+hOTsRhv4ZWYdwmsngtdvTrMxUKGaO86YZTRiJLvAXekSgE7qWMZvGtIThCEBUux80gylGjlW3vWZ93dUzLb0ifWXKiylvqUfUY6mSnOIy5XqonMfnKbvAjlHQDi3FYLempHxgMttMKTaT2QgqEk1hDYma1kEgbTJH7TjZqNfMHD7M1AesWtTPmmcZok3QZmnLNE4DJXHpSuLCyKW5iKtOSVzL\/dY9uBky4xUAqpZbTdv\/J2Xx3agsf6tLKYsoQUf0jpZaYAGzcHqB1CjCgxSRbvh0m4fLIdq6QW1AV1IC9gAFfUF2mwiRQLjf6\/ZVdz5QtWnJgCXZG5eSo7Wv9Zj78F4sTXnoynu1eLZWsXj\/M6u39mjjID+\/Eps6OHb1k3cf3nqKRW3FIDk72Lx0lIt7JK2ez4x9eAimODXbGzVioxFcVSqf4bUZDV6MQhpzYnoEp3mdGpOgU7d5Tj2CcybDrQOfHdDerpNk6QVtfymTZMNxbtxejNrbu9v7B1n7+sfR4eJwaax1uH+KdHfaPGl+2hHpM4dF9DMWZyV0QugX1A0eowL6CZGdyPIH\/QF2wsJa2dNIoJ2p+PAQJkgwenJdmyGebRm1ou2hyZouSMjBNNBS6MXl11hEoi1vYGCS8+LCqKONc4hzgnOWk3M62Dmng73OWU0yt0USQRpo4oV6ISYtnm7poI9JiTH1YdauBEPuoodmkMyAsKzMQQUzkEVrwUwdtl0nUlqzzdWg87j+bfvdQdruGVVVe8+hud\/ETj+16Nymr2tb9FjafdJzz9w3\/SWuj2lsXnHezRePDyuL\/f5pxYX7cVc8A298c8O+a1+XvlRS\/fQTmzcDA4aCvXPwLyIjmhg17TdiDv6IxMlgy5gW5hHMyapxMqWEsaSH7qIp8ZilyfJ51ANkP4TQNrCZgGdB8Og2JVEMKVxpeVHxlQvdtassGmOZAfPehZbChKsGsLIMRkBUEIPNrdYWQ+n2JbELXZubd9IHfl3E\/bVpyYqYNVZTfWwT\/hG\/u4ZVA\/oAAt2AQCcKojyCEhisUlGqtxGzkRCHkX6NGlkDXoHP9lqNXlllYGNZwA49i4iYWf7MYGiuC5wYoZ80u2hdck3rrqL18KWZdpVdbtefaNfha\/87W7gxFWER1wVWbEhmJK\/pDRHqGiIkGnJaz0zMdTY8+X52DIhr0Qx2kL2W3WnXzZld7+nf\/at7GbwLN042oG5hGtSimQPnODo7OofPqj\/k8XIenolm4hncFKlcmaTebZzuXIwq8BJuvjRHmavONz7k\/MjyToo1AzRla5rfwzZ+f2O2aegPM\/Xx5vhV5HUhFZqxrhG+jtOT35CxXE1GRbXIZHPUD7pjxsismYm5Gj+8o6lrciWkznB+a+Zke31KY4\/aiX15k\/qU5gro\/pWEybuQ7Fup3rlE6UbXGN3OlU4qR+UlJTgcblaQDOfqIgEER1Js12nL9aqDx0688+wbe38cN37BQ7GrR4\/Grj58x\/xxo+ctGjlqYavOy\/vM2bDpgVkv0tScJ8au++rkupGP5zTYv3BPHGG8d9mbuO\/ouQ8OGbZg7rV48fIeL8x+4KUNdbksw6QXrOKrSXkrPnABIQs4gKu6QJkn0K2Ti6U42UyiLosuUoue6VhclgYRJdvLKjc9TNRksqGeGOthpFGDrAIzT5PBgmjGlf2R0qa6EWmqMwakzeCnMSv69dv1mcR1jfjbd0Zzdedp0VH8v7z1xnf926saX\/+iaEErTzdHNHibY0BwJL3TMd4zKjjdM9O7xLPYu9qx0bPH86PjrP+qP+Umx9OOTQ7aKme4QLKY3w0CmFwBv+DP9vYwDWFONo29Eh\/umTDJVawRvl24EClgkS03utXlDZidrmJm2lKPJUvUQizLI+9eH20yKF243nfWmV1UWo5LS5Ke8mbSrCCLWVvYIgCT1aKnzGGsQ8auY2niJseMoX1m9myOm+8ev+MaFt9ZduG+6T8\/88pX5MPnp9y7deOMmetxH236Xd1mfTlRdfUfh6UvT2Jtdey72C+x72PbXn2DFjy5Y\/+aJWByATM7If2Zz4X1+mZLiCN4JIgyEYo4WoQFzkCKIK5BhGXM66Vkbamc2U\/IBnQ5JCqZrJAJy84DBw7QkgMHrr144AAi8VqE+BKIX0VkwqN2YJNZ0wPFX6qSxB86EAmzbCW6UdINDK+vG2t52ihptFymLaTLtff5d4S92mVNkfgS3J\/01EYrldqv6q\/GX00yp3JGzkQVg8xzHGQXkiCKKtCSoIoYQSb\/R9SsZ\/Z+UbXBKUIpO2Znx6ifU21wl+zleckrUKGaTIzKSFJ\/iLL5kLuwAgqnRK2qH40Qae+e3EHuJEeXc5irxjiq9FT3iidVulzFKtvXzOJBkcwSZ4tEfNR85IsEt9ywwJ8LOOZxa4ACV5siz4U2p4tYhe4Cq09FIHZa0Milb3WmQnS8QNu\/37R\/\/wI+sQW0dK1U+nSt9PYaNLCKM1NJ3AWJL4r\/wUBUgieVlybqDUGcj4M0QFMClJUgKcn\/hAz8+uXaJ9cfxT+v6piRls\/v+qsj3hNrTwbhlTvveWgx82YrwfP+AJKy6BFVyk7EgUxuZXUojusY7B8cGZwsz5WFMZ67+YnyZOVB\/kFFyHLI1JWV63Wky3KK1Zubm5OD0tK9wDef12tBkissqMyFCZBXRPOZ2gtWpvKCwDgvSOzpgi5rwcZwIPQNhdU0dodqYNepDBd2dpXqaZDu9etlG3+yZnNVtyM6kazX\/FWlCzlBCIkKjkGv2pRGWg921VdkSsHzd9d3ii9cSRZpktk8LKCaRZCmFDa2FLI8MJEGsopNviVwXZ5nIkEcaJpI5cNBSDqatmC6y+iVJLzhw8kjR81bNmD2m0tij+Kb5rTs0rXjA0\/HjuHxt4fbDWrVd8WS2CZ+V8nOEbe\/kJ+1Z\/aoLWVNaG+LY2Rx5wk5NetEteW4jr2nNWFVoJHx7\/mp\/GGQyuHtw8jYdIITwYLev3PRIYzyo6bGYWgimpI+G81NX45W8y\/T5407aZXxXeMhdDr913SLyZpuSU+nuUK2JTfN77vV2N82wN7fPZofl36fdbF1NV1lWp22AT9HNlg+N6UgG\/JoNs3DscLr1uxC3fg3zC7UzAhzqSlelaZ6OVkLm7ugsB+stMfnDPslLKmsNZLbO2xwomxeWswiLlgnI06LzkyQAKsQQrA5CTsFLpiRCYyzZuY35ZximJk5YrdZmaHjqvbdFHvrzIXYF09uxu32HccNWr+Rv+\/Rjd8NHn92\/rPfEtLkUs2b+K5Pz+B+W0592HDdI8\/ELj28O\/ZDxR5m154G2zMIEG0G3p2JNvb7cDspgU6L5jUjCZosY59eJpF1UMkGvc7r0o\/o0NNNkseXrv3X0Pu9Dnp\/1EHP++\/QS9Klf0OuSV67adHmNFWUBImXOIkT3C6PiwiJWY1UsDtsjhQHFVKpM4CtJli5pLQAdhgsAQRcjERy4TMHlzKEOh1OBwTsBPAZCjRN1pogmg88jf98edD9JVMmd5\/+8IF5sS248OHnm3QofvzO7ptiH\/G77Ond7ogd3P9iLLZxaNNNzZt0+OGFs7\/neqHXz4BlYHPlFLQiahd4rySJIqIcY6RB9ipIEhk60jVrgdiXdvEb\/EZi8Bg5+f+Huqqtb0sAKMm0Yl1hS4uvnI78u542yYNe2wPJ5Rku89rTNHLtczqX37Up1uaVmHET0yIIjrh50AcZPRSN6H1YJuL6bkAX1viJXyHEo\/wX7Y4qibp\/Uglj\/9F8Q+vB1zX\/uvafTqQdzPv\/e9s30K+vnSGVtT1Zu1ttqh0JbRgPur8TdD+EU6KeVFuqnZRl4dulFGylmZkoYHWSEPISXTn9rA0YC06viUIcLGMczgpl+imFfmWV6WWa03pPdO+brNd8pUtA976p7H4yaXYWzkoP+w3YoIeCBnd42G31qlyslV5N9gcaz1LH+gSjSN9P1M0KWUIFgG7PBVPTPGnuNCqoYS1kD\/vCUogLB0MuY3oAOcwpAbjYluIXYS+DDwVwmgLItllg5ZUDAZRJYYX0pDTCBnSKInUfhnVUipuFLDdYD4dTbETAfLDRTpuVAwPSwkK7kfHLYofWfRlbW7UN9zy2FuNHwpsDd+yYMG\/fPYGWCzB5+P7LN5M2r+DaU5Mm78S3f3kET64aVf1Y3sTZxb3m9li4dn\/sj9lDW2ALyOM5sCgZuiZ8yapUe6OeFHsBR72yYZ3hkIEYeEIUCTTYL4oCq6DpHg\/4zUoAQOnFBoGlLi7d82Hd85XOZr92UfzJMYm9UQM89L+An5SE33UWx5HUHr8R+409jWXGiUaudYkLcv76wYiEBUrIMVKkl+NAmyCz0c0QBicHkIQlCOvn9pG\/9u2rFfhdtS+QQX91JNtqi6GNb4BCzQEuUPTRdqY7hA2GbGt5kz4osi2\/ILFtmJfYZucktsFQYpvuTWxdnsQgSq5RK\/Dzy\/nNPGAVgrVlaB2qRFxjFEU90Ul0GfFWPxxcjiifqDwyLriS3PmpjjsX67hzNaolIj2dO89wR0quM77tBg\/cOhvCudKS8klFtaV1LGElSaaK+ZY39rHQCPoI0RDfm0kax6JemtGiUJJbZRmaCc0NtxoG0Pn0CypONRylR8E4M+3RXUY2v4Sr4F\/ifpR4A4ebcUc4IjNhy9ZAAfWzFTjTbWqhlR3dBvtScsuxbbq+3bvN6mDHT0RvcsM7Q6GbJNntvgkgLRtkycBTjvPzBhvPwx7ATIBoVjAYEE84TERFQpKBEgUjrpq0iprzeLyOr+T38qd4ju8isWNKnoj9EJ1WilSsJvOjquL\/fzXSv\/xtpDew8DbJW8hryi+wzIBpahGDVVERW8A6sACXjYrA1qXXekVJK5KKIJx1QTibCuEsiza\/bFmSSFjZzuVtqoXx63LUCYSgmSwFkmbSCmRGGTTADEq8t0SPJ\/QPqwtb5AzgWwN3IceWjNRCAM2JHQ4gHYUCY6tiLZQybIVc1FbI2Lw9BKS9MPL3p4Q9GJdPKo0gFlAzVOAAhj\/RsnIf+RKLtavIA3FUe\/UyqEUO+aL21WtPkLM\/xrgEarhcff7H+KiKCVgGHkl+liqQF6NmkdD\/2iVe\/Y8wQviPMOJsacIXJqAbsEPzPgX4\/roJXvEEQoIZWqKR03V1bQl0Q7cckslo0a0+KA0QPBtCzGaUamWnebNKZYSJJCsmJMnEoAisvYrG2qhAG3ewqxQNscGCZE\/+qOvJtaobBsNZCarN3r3aoUN72XhKJJKQFqobHPeJup4K+prqa05f8\/paYmgLMorozhYcCfNSpr8zRYO+FusSSYkxzKcPBfFY9RusBWZ9xasUYROEKhLELKzj7Gk6oT9kN+mPrMCr\/lFj0qsLdezXH4tYQStypTFgXTeXRYnOlP6NvUgCjqnRWYiYJRtJlbip6nz1PWCl2lntbKY5XMjYwDSQ3sZNNd5rWmCUFMJLhcbmph6kK20vRqVi4y0mwxNkFV0prpQ20BdFwUrMJlMeT0DbiaQajXm8BKSk9jb3xlFITSX2rx\/AHppMGpNTmXW2lVh3kQ3IiJts5f1SNW4SNaiywR9VZylY2QWdNGEFzpBqSGhlMwDRPFHDWjXp\/5qfL+Nn82BiyYZtFuYy3GwGSWmRC3Cm56xAe+p3TpdCBgts0K77eiCvZYq+YKaeyMKmSR76O2F9HanxGsDgEUTiR\/R8tWulCueyde03xv\/YYjKwo8kBoM92BApNDQL6INCOFoWmpi10cntDOJoc6ImUQMYLOspqJwB\/7HA2b4ED4LhwEFuewJn4tjyHuxkegvndsf6bYwP5XTW\/PNyp55P02l8duQ9rmnGnapgyrgFL72ORIZ65xarU+V\/JpTr0iuu5aIBREgHvJEpgbiUiUirJHCGyKHHULwh8nR\/i6109n9AkcM5Rjw7nUr+C\/UpPpUyZqMxWeEWCKFN39kZ42X8XbnL\/6e\/rw83rnFykNKJ7+PIrN3h4KytcFhYu4HQJ1RlaGj\/1GthXyQ8rpBtTFmyBDKqkaMdC6P7eHR0LpWjTBNm0UATrylLCHW4gmyZIdjSYmKGjBAtFkw2WFLZ\/ZUcKkOkJMh1IOyP\/2FJvbvF1qgMizMcs7sCWNe9SsuvdazEQ2BxuFghrds1sls8Ng2j4a\/4zZEKp6INoT48Z2zSbLdWZmspxGmdTnEoqt9G5w\/SOiTqdrlTiT49aeqT0cEY9A\/mB8gCtn2VIyiDnEFd\/z4DUxc5VRHN7KbV6Fdke9kMywNJqJgSxLpoQWQWcsV5kRUvGfbGucioysQR00+OZnY7TzWEmQ+E60+FOq8uBE0lwaZ3lLr5hlgwkwikaCjTlWMqmx7ItNJTfFFkKCCTCaBheiJt\/iDu+XBXb8cbB2K4N7+H0L47h1Gk\/PPxx7AvyAR6Pn9oXe\/74ydi67e\/hQf+K\/R47iAtw6jasPBo7k8iBuVpAtxG50NZogxGWcTbSVetqu027zcYpqhcsDHK6EjmQNSzpVRdJS9reZFYgefweDH8el\/H\/NTX6z8zOfb0bS1ZiyksTtZj65CgRi0KIrye0XgK8CQQsQNfnsiTnkeI7Hym5GHs\/thDft+fp0m5N5sYW8btM1hE7xu+O1da+QvGSWYMftBsZcgbGl\/IXATl2lI1HR1cMCa8NE7erhZ0oaZyPZSk2ny0o5PINnZFwa77I2Srcje\/m7Bwu5fsFB4Yn8PfR6fwSuoRfgVbT59DL9HP0ueMMOuM84\/Kk8RGUy7fmuVL+EdfK8OdhLuTIDRc4CsOdXZ3TOvg6BLuG+0sDLf3sg9IGpff3DfAPyBjDj7SPC98XXpq2NHzMdTzsVlzYDtZta2ohYoPeLVMLOZfNlcu34jlCHdlUzA67HDwSAjTFwxO2g\/hMr9dMiZTpFWVPOMXFJJFSh9wUfQqHqhOXdeSm1CGXEdEQk0pKF+Lx587OJbmBMFgnRc9JFB29ijvn39FbfKW+TnahjV7ISeZ6zkJkydfe194vTVZ20CRmk8snhRJTIK\/LzxjG4WjzJLgtDOktwlncbwsmFT791LNvvxvbs7kSd3ifAf6u2rMbxr8MOD8a+xanHh89+LYRT5VGFhTed9tePPiro3j4rjdjz3+1PXbyocala3DhVmx4NPZFDC6OfZzV2g0yXw92fRMg34Uy8LVowKqYsLV52iDfSGm8j5P1yVySvhb1dSYYOJ1l+tQqRqh1hFJHWKvj326zegpge3lbRlaBhe2nZxVoya05uYXzX25LDyfOw\/VacsvORzsDETJ1Sevi76MMThufNkm+1zTNPM+w0Py4caO52nzO9L1ZgwjHbzHbLBazxazK1lQS8DgMgpXNxuJdsuxwetxeJ3Mf+uRBpxMFMnQddgEOTJI3bFoj1E1bFOrUU088M\/QUVNCLraX+zImZszNpZobrv9Vr4X\/1QUGWDPxbySNp9NynXazUxYKEpH5H4FxRYWN91lRi0hRfPz\/zug9K5mxRgxQ1F5q1VhZrK+YqcLkeJZjA43jchRbwSVZYTNG0Qg1Cey3DB0u9kym5rmzrdDhTgrQRARMS1M2JPhIXWE8q9n80\/YPDxdn9usWv7Ot314CGga7f4PXzVnZ\/\/NlYHr+rx3vT1hxJD2V2vztWjpvMXdJSEWvvpvktpt06Wp+FODj+PXeeP4zyiD2aNYwO4ybTKRwXympGC9Pa0c5it\/QOvvaZHbP60BJxcPqA7EUppiArwzB+Z9YRoToiXEdk1RFBXRSJixNEqI4I1xFZLPftyKhsYziTZNKsUHNzQbB9qEPjQf7+wX6hO5WxxnGmkbYRrmnKdON080zt7szJofm0QllkrDA\/pM3LfDD0iHGleaXdm4zOGwbC1tSwRw7n4DBCOR4r17RJGI0A5TI2nJa6KJWkhhzGht6sEA7xDp4ZlsTojbeh7PU6qO7nImAjShOlIbYp1edVNb6Q+KZGG4YyTUaFD6Sle1MlUeAoEXAoMwOOCbw3taEnymC3DHzPBQdqqBe69MhKw37cE5fhiXg5FnA1roymNGSvZK+GFneRwygH5zC3bTKRfjmsaUZ2X46nKfQJh60sZGOnrHUgt9YPEln7Ml1wN0kWvkqLTzOzp13QRwz+LmVrtaWR02x1hfXIwuaBF+qjBSVsMnj53ygGW5jSwkvymyYrsZlZ+kCxPmksWe+225wOzqmDlNnL8ODXjEPemznhpT49B7eO3dlrzKj7f3ns2T\/n87vMmzZWri9siY8OnD19fs1T78Z+XYW\/0O56aMAtk9t3GBV0Do20eHbEhDeHj\/lojmnx0jm39cjPH5fdevvUuw9OnvIDQ2oexAO79PG4RVEjT7zAcKT\/LE2uJpO3+ROjWq8JfkwasyFyjLfjZF3qXFTRzYOUtA2\/1KWq39YZiWt1RiGWSJrYE6Udq67PWoGdEJGeLj2r6TPTE7VvNmGLVUBJSiydq4il8sZNm\/76lbV2PUR8rN5mQ0ejhrB5IDdQel\/iHAwGDoibC7jWUkeuizTV\/AJ\/ziyqiFiqye4qQbaFSV1MTupjcqIli52noml6Slnqd2C\/o6eDlDkmOmY7qMOoFz7rUgCDPzklLmEODXVIMdSbQwOXTCMT5tBQbw4NpXYWkv9tDiOlrHhaWq4zIhEB6hFOBJXifEsy8msG4W9ifoCFK9s3PFbz2cexvybuu3XTzCM7+F3Xtnwdu\/bsUmz8gfa4tvWN7Xfs0+e\/Ixn8XEc2QxDfnJwFZeUxkvSIzoB4WeIx4Rt\/fUD7+oAlPx943kaf8JIazWzM41yUTUOGxmqeWqYukhbJy9W96mVV8as9VcIRRSLJKQQyViF5hke2aaOPTsLdBln2S7xNkngEECG8jRBehlf94DdANjpCwiOIpBfssgt7Sni2tFyCfYyjRhLNLhxC8DKylhDCjlj8fE+e5EEGupzfy1\/mechCF25TyjYkstByNpuaLS4tMaPf477gSszqTw6asjHTRKZpg2xyKzKDJH7eKlsx20AyDmFRYqoGSzqz4bLmetKJ9J8X6YE4m\/QUwPmJHDIfk7a1732KZzbyZTTES96p3QeZyBezJ957L5fzV0fGczdC4lQWW+Bj0XAOCltyrGFXIWpuKbQ2d3VGt1o6W291DUQDLAOtA1zaE9IT5iQjo\/ka9rgj9gK+QG3Pt1e72vvyfdXb7MP54eo4+xR+inqf3czbWbXCKoGqEV2ObdroUnPq1pMx30s5nieCCMw3ABJlo8lsVm0pViv7\/48uCCWLtvHI5Wdb1Wph2+ggO6SciCcE8k4bxsjFS5LX7rLZ7S6rKsteuxVIq0U1m\/2axaZpFqusSi47b7ZooFfQJJ66NLNZliWJQJtcVqvFgiSP0+nR2sq4F\/IjFdZ2WKKIx712+NmwoNtdjRdvSQQGpR53ca3HVVvrcde6uncY0f5sfUxQV0Jg8QAb+q5bIF0tvr6gcOMGNGmBSdu\/H1ZF++uo61cgbDMI28IwYTWw6S8JBITgYO7fCEgWKUxwZJsa5aMtE6CYVAqASEkAIsUKm5R8HMRsQB3jp2P3vXsy09PSgJ0\/ftojmNbw7Fuxu3bHPswSnbbY+6CrbR5fcT6Tnqj1xH76dXEVfRWS2NIl\/hG31jzL0sSkxqp47A5JbkW51nJ1\/PttVicr\/H4fNQHBuWFF2UpmsaRLrxV\/GW0NBJcNK2uYy5FyDY1N3Gg8WhitnBA4nqNUkERZEGSBygaVjWf6DYrNYFAEKsiUhQcOdpT6CQZlxYKqCBjMP1aqiTsqGwwyJWAzTNXEFZVVuXfUMNtADNV4e9SoKKof0d49yDJdZbdHZUCQrS5ajCq6S1CTbuDbpGMgrh1G074AU+PI1UQtgk2pqk1szjLrXwS0XksDsS9oFIlIoMm8Pg2CUQvY5AcNVl0rnSCgNDbtQVJlldsVv4Jo\/Io+eUb3tliPEmW99gsLVx0\/scXNAsCSei8csPyt3hbSuvbDn3CgZ4dbbsdp39a+RsbT4ljHGTMmL8ebr22rfZTpeA54ykpdSuoWq4lZMrPRUtAJ3yp1kqlBUuQ6lTapyGTEilcFbfQKoK21RW1q9yc1NfIyBzzGmJMNnGQwhNMDBdkG\/Ce4GT\/mQA85Q7aSVoDZikl4G2w5JukUdhRu4b2iQBSDVwVjvhtvh3ZxwP5UJOZJUTCoXdQ2kLl5TBjxQi\/kNjJvC7pWfAW0iQ04FhVfKS\/STmvX6kdNiyyFetlF\/1FUOdMjk5ZUl0kl+jxIvY4uk4xAIXYFCmVWJHcXkgydnxBNN8PNWzB\/jcWAPYdc6tnp2sec59r7JXRDFX15eJdNm66JozZBiNglfo5L425G2agFaRhtIBvlXLfRk5tjzM0tNDa3t0htlds5t9RYmjvWOCa3LK\/COD9nteNJz0ajPbtugkOW\/osrRr3gfil7h3t39n73wexP7V9nS+0d2MuiOgtzvFbr35OGmjH\/3o9RPqfPFWmQW1DIFTbozHVq0F8qiYyUxkSmqgvU99U\/jX9GLC0KTJjTGmcWOJsGbK4hORNySE5aY1Mb0zLTWlPcxK81bTZdMlGTmvxt4491v3a8ErWz39yY9FlzJoHNqjOZ0qizmry0w7XClpYmInaRRw+IOmQZmqZRJWeoNhQJupKEApksPkmG\/z8l4pNMjulNJhunZXM7M1nWyfoOxHEWewGlvyizLtLKrCa3RU1ZUfYbCH84L7w5zBeyLJbFtZAWHNmhE00K9TKjN1iQV7i3kKwrxIVO1ra27InOkCujceYbwkGB+IQ2AhFMesqoq7Lg0nNFfaKpoBd0BJOeN+ojw0KTltf9wAmC4ogGcNJnGdcHPUW1kTNnWKxzOlL384q668sTKUHdzyyQnvjpM8ZReYgFwXqI3EL\/NivISkwev5noMbPDbrc5nMEwFUQTScyIg4to0fCdYzfvuXVyp2bjvhqF8zssnDUtvdJ116FFC1\/qqcnOjD1pzjv2TxjcdPyY0c+E0x\/s1\/Hled3ndLeZjJ7MkOGuhjeVlLvKF3eNDu3S6N7LNfNuaom\/zk7Tsosbdyq7rcdN94Dm9YyfoxcA0R48KBlpFZhmmbFZwWyociKiiLOmKaIrjVOwyS5KjP2izkpRn+EoaoyVos6DA5+9k8gi9pc2ZQsLyG6VVexLa5fSztknpY+zLKXM+SR5kq42Pqc951Elo9swloyhY\/m71YnG2cYX1O3yDsN2VXWo89XvCDVlDDFPMM8yUzMGEEan5enjp2XQrOVoHTqFLkOgaDYr6O82pkHTM02SjuCMVOhfphLxgV3HbFobSBtHGUJwJ31igYddhjun2TMPitgnthGJaNIrogZ2kagroNgktWB\/Mtpn44CJuQKTkj+r1n9Y0bLkwqQrkQuT6uYNWAoba6Wn4U\/PmSAQK8HOxFTzAv0Xg\/X5ERMyLdqSfunVr2K\/T\/ph0abjvs3uWYMWvvTc3LFL8TznawdxOja8gsmczetTx9351uEj+x5glb+OILOTiVltuF\/0OQPhjCFjgbG9kW9ma5Y2gPQ19Lb1SRtFhvMj5GG2srS9vs\/4z1O+dp9JOWO75DzvPpN+yhf3OXy+iKfIUeTp6pnoW+4TG5FMYyNHK9LM2JV0MHa0dU4bYOhvHGU8I3zv+AtfMWnYTk2KZkapwGsLMthB\/V35bP6rOaRphyxYs0QtZZbZFs4XZZhITEKyWJlBsOhmjamhRWAIsuhjyxY9jWEct5gYxy11Y1cWlnTcok\/enWLNfEM8KJ4U4yLHRNRDpKJXh5yuyaI3AUVdbLrhEnX7JLq9BT2vn21TXnyh9u\/0tbRc\/\/Fw0Wk9aWGLPi9Od7ts\/CXQjGkrqGtCYGy49PoJzy1H7J\/1+d1jP3uwbGXjbbX+V+6e+vyG++5dP\/\/pJTXPrsW0oldbYvqrI7F+9MGb73z10X4ms67gObygZ3aQWZ+o04fS7BC1lPKlcj9lBB3HT5BHKJI98UtznQGno70ZlZ6m\/\/bCepT\/y3bVwzWxtnI3SWtrLfa0TetlHezunTbUOt4zNO1e4V77VXLVpSEHNhudzp4Olv9RR5p5ubZOI5rGpaYZRLSLvMQQqxtpvfCgMb5roB0rUkB7nFEj2GU9ITTW\/VjKyDwEY6mRXS9n5RZUGrHR42PD+qFwAdtG2zJD7MM+R76WKUYzcwvqJOW\/TlJpuqQSCpamy0if2cEk1eJ6SUWKa09318ohviqvTyzZtIbkBOOi2vKi5Azd5BRGfWS7TsUSAw02MaDnnDig\/+ZDoLfvanBx5w+xS9h2\/HNswtfOGbbOG7ak9ivSS23Zf9GMjbi\/89kq7MMUqzg7diL2p+bfvGs0XjG\/3egXwIqkgAhn84eRExujXpuMze7G7jx31D3R\/aS6xrjRKHmM2cZK914352b8yPb4CtIlI1XNaQZsJxFbCkcFZFhrw7Z4SpRzhjhEySNYHyzb1qRlgT5oFknzFSxH2B1lauKOGkFNkuFoth6KZjDFQQ2SAekvyeKlLVm8ZF5cJ87q0+FZeVP\/PQ161uXeg3ehALqKDaguaq1TAz1+hbAKctALpYnglf36s9CSmOxk0yyCLAoS+FBNtqYii2BOxREcyZ0zB0dATyblW4LN8psVtGCFHzBrzKrZ2W\/Utq5dm+J5cGq3waktm\/Zuf\/AgXb2kfFxBxwHWpwwd\/097bwIeRZX1jZ9aurqruju9pJN01u7sgSCBEIiBSBpkkyiLLBIEQQUUEEVBREUM4wIq7qOi48gyjiI4LyGJGNB5yYzjhhszr+iMK47ouIwj4yAzikl\/v3OrKjQNiM47\/+f\/PN+XwK\/Ovbfurbp177nnnnvuqeqZ563+bg5GxNDO8cpnGBHs1X9JbKbb7Qj1cheHTncPD2l6bmZuL3dJqFdhjXtAaLR7RGiyc4r7Qve3xtdpKb0Le5UOLhxcenrpHb3W9XIOyB\/Qo67XCPeI\/OE9JuZP7DHXeX7++T1m9mrs9VbpJ\/l\/K\/yyNJCRrqW1yVtby3JSnWIm8Uepj5hHGqmddhMUG\/maWKUjJ8dnDC\/I8Rjpaf2K+xnF4fDuDMmfEcuYmdGYofZCk8uTegmxliHEWkaXWMsQYo1fUBKpn5lijXPxC0uWWMvgl05Gi3eYFvukYiqIFO30veZ73xf3qRFfnW8sJjoxYnxZ3Le+AvHSjLDrmC\/b+YRs82WW91qcz+KtfEyCeDsAgXakhOvYd5Dfa9tnuefvM80zl2JSymCHSqFilJpe+SznMvr3CwhbXUni2x1ztrgrT118zapwirSk6e39F\/\/+1qevemT22+v++7P7H7lm2cZfXbV045Ss8cWVs6ZWN90i1b67RpJWr2n8bt6\/Xlu6Wen5+\/adLz\/z3DO89lhJpLDHZUg6dzulg\/HTMqrEu7NCAStW+yvDlR1eVSQNzMisynAFPIGQ4pDIl+NwhtyGp1iP9RtQFdeldl1KF3NMeky4uJaJY4i7QGfVMyCcXYXqqWdxPl2s6MQ3CULcJTpPMOIVNnaPFfGD24QDxhhhiMuoGlDVlL4\/XV6Yvi69KT2erqbLoWJzc9uPOuznLzpEwTl7SRU7gtay8dtYhhilqu3MlrDF\/W0sXYxMWQxLWVgTx6SNHJewcyjeqhf73OUHyhPHqfgMAc9TAX65y3JFTNFSnMUpmidb8rowLom3nlcQBrXp8Ga+wBsoDIhu1NICK1uXty\/5r\/rWy+ePu7XWsaPjq7umP\/xgxwx5\/cqrJ9x2TcdTGJOr0FG1wgvOSa\/EztEH8BOM1e\/Q1+lNerv+vr5fd5Ie0RfqjfpaK2mvHteNiA4dy6nKCtbpyyXSHJpqaM5iB6lr1XVqk9qu7lW1dnW\/KpMaVXcjpqrsiMLtpna1myraTTX4rqqQbKot2VTbAqvyIDK4DdUxruTWu6xWvIpba32Lxnqpafpll5aLVznQKqtaW1vVz1977VCaWnLoLeZLPLPyL\/aKk8+NZWumDqFN1qbqis\/7D8dBTdFtd39zw8ywA7odEB4VYsNtknKFIQe1aKqwbexvCZayrWN\/K2jQIRLyRULseqRoqupQtWp9pOoo1k4yphhXKJcbbykfas5HNKlQK3EWu2q0k\/U671hvg9qgTXE26NeoVzru15\/T\/qC+oe3TPnX+U\/vGlRY0DAd\/vJf96XSsxx26y1VsetEpqlpsetYZ6BiVjZ3i51XAmWSobZIvpjtUsc4scHEsPyq0YL\/pBHAHJnp3McnFkoSJqY7GgkPQDbG+gseF6xSZjomixygoOF2ozSRUcMr0eD\/IHzknQVKxYDrDL3YeLj0odh7KD++jQQ3LqOFFvGo71rGHndPvqnXVKuJomSe89boU0a9XZD3sZScP6Njme9YxQ++VW6O7cnNr2TOuOZcd5F5vjgqyNd96m1p42FxKwrtuO2nx9uZ84QzSnM7kvWa\/cKsDETGPIFvdtocOmxr4VsF3VckVSsfdQqFaceBtyeYwF\/7r1uwaa6OkwVwH8paJ6XjXT5IKJSc4Udr0aec8aed7neuvdez47mmpqXNJxyw5clXn2cyX1+FQLcbih9scYiAKF9Pqk01X06r+Ju3T16QFpitqrBhi1eeIONY63neoY3HY71AijoWORkfcoUJqGbJiCjK+khBoaZjB15LUjuWUnCjV\/nVYquUmSDWzr029w2UpHfbmSDxub5dYY5TGqEeOUR6kvIg23VMlEeM\/bpnrWoWjqjlXaCXQDQql59lx6oDtB3fA\/sLMH2NnuL1Vxeo+dZ\/+QcZHUccex8GonOGKFurh7KiuKIV5OVoaT51OSSvMyvQbu4sl\/k0VuTgjIyul+I6AFFDFykQ4GQSEwUKsTELivT3xzRF+0IAs1icesT4RpoqA7QESsD3pAm3S9JgnXHxHtpQtLpfddblscbls9kYM8OWyxWyQLRaY2TyWxCSU7eELZ9s2kGy+XjrJ\/QqLpd0k8VpXjhCPP0WMv9yjxp+wZ1C6NdN8Z+uCB2IhMeWYXZFiDsmi4jZpaUv+yET9wRKe0Lz9CSlfJExC0zuEefvSy0wf2DpzEAcyEn3jUzyh1JKQJ5AtBb1p9oRkqej87QKxPZgh3iYV05LQFxMnqPWVj8xbcl9k+a6HNrUUThu88KetU2advmKgWnLPmBnnTdmxZVtHqfzzi2YMvOfhjvvk5qVLxz1wZ8efbN3iY\/BLunRNLNWhaKnyRn+b\/0PlL6n7lYOpmsoitxYMc6VfWuPfHd4bjofVqCuUEkoPQreQtHSv4U3xpBSFhT4RFrqFW2gVbqFVuLu0CrcYBO4CkYNbWGgVbqFVIP6N2aFuoVW4WesQ4tAtFBe3hP\/uMWEedFmsYYT3h+WF4XXhpnB7WA0rcr+0dDE2D7YGApbr7DEVCyNJsQgkKBaqNRLbY8FkRWVMhnhhs+sPo\/CAUDaOSMWf+YmtWnaJ6dI20rWAbrgMp6Fo\/hKs4rMlnxG0OplfXbiUpbDoZcueldDFKzdc\/u7M9eP8RmvP+aMWPaqW3Ldl+MIzKq\/pWCTfePGCIXe93CHebRqGNXIpetFLmdL8bWlhy7XnEzHI+C3y2CIOZYoTQaeR6RmpjXJN1hpcF2hzXa4q\/8DgwPT+4eH++mB9+vDwNMc0\/Uz\/9OD09DPDCxwL9Fn+BcEF6bPCV0hpuubwnq1MdEw0zvZcpMx2zDYu8hgZOaozAJERKsoWOn62YANn14eUnMJoYRm8bB8kEbC858xXyy0POxFoj6UWFVf1cUrk9DujWBD3fR8ygtNP4yUzwilF5Enh5Z14h5CETY1yRP+KpbI1aoX8IfEVBIrhkiwOZOqbxUtn6wN0Zs9h4Tz94PQEl5Muzzy2awgr+ATHBP08x3m6ynMTZ0kVn0Ag64MIicr\/sIdvevZtKf3qz295v\/OL7c0rb2xuuWFls5wqld62pPODjlc+\/4mUJ3lffunl3z\/70i5UaGXnXDUfPRikPOm82G0e\/0n+U\/z1frUu2hSVI9EensLcyrTK3KG5C6N3RF0DMwZmj84Ynd3gOtszLWNa9jzXfM9c\/4KM+dnt0f8JvRt+N+t\/8vaF9uXtjcaj6YVqub88rb860D9CHe2f6v\/I\/Xlup98dSFHSc3JYyqfnpLgpJbNotyH5jZgx02g01KjowmjM2uL+2NzVMcL2lret0HX5TpvfMjOY1wrF9vdiKbWf3C9YTNQOLUhaJzVJ+yU1ItVJYyVF4nlOSGNJSGNJSGNJcIgkbFISD2ZhcuSsYgEgCZM+RCQbHzMjI6vDUuKmuimI\/R0H9h1ezlmvJovxaFmpkIsuTbWFanpaSLxQXRpQEnpv5cMD77pw1e55l79\/9dTbewceWbJ086OLF23tnOv49c3jx6+Or\/lF56FbTh\/YcUh5+JXfvbTnpV1vsiy9AUPxOfRhgF6MDapIlfyqVKhWqaeqE9Q56mJV0wMu3aV7UwO6lxSX5BaNT4ZedodLchVEU6VUuSBw\/LVSl1bxr1ggQaRpguWPmLvM5ZKWoE6OCY783VHLpX3+6Qcu43fQuHVq7A\/wkP\/FlSnCXXv6ZfwOodlQpo3CCZF0w4bBc+vOPmfw0KGDzgnlqSXrLx018NHSkXUzL+t4nVuhLv6JshWt0EfJiF2tFoQKBuqj9WFFkwtmFyzTb9OvL3okdXOv3ypePSMrnNGnvtcbGY5seZIs+yslIzzNNU2fZkxzT\/NM885zzdPnGfPc8zzzvK0lraU+dpYp6jGgaKrR4J5VMqtsceHiosaiu40HPXeV3dfrnj4PG495flH6cFlLybMl6WW2zlNgBwrtQJEdKDPXIVYeDhTagSI7kMuezMG8mqmu0mKPoWZFS9JUd+\/cLDaGFGT2EvbazLrMsZkzMrdkvpap+TIjmZdkvp+pRjJvz5Qzf42+SQNfCOthLMTZ\/eyu75d2Y0kh+SXxvl5LKL3KtCqmBKokqfe03Ity5dycNKdqbvuIpd7H9nLu41gqd7Ca09sdyZKyijJjqeGqSi5eISxgYfPI4ypTfJMwM8olM6NcKlMsUTKFBTGzTT672VnUE0WfyKnZ3VPqyXfhEj1tf8Gepu+oxoHPxLdAemaJW+WX9qyaWdleKddVNlbKlWwJLaKwqVkJlouarQwhwgGuQFR8sYQrES3yiaHuE9XzRYW5hufjqPj+iXijwzLcFLxvL6Ay+1rmzumXdrmfAn6Qy8ZY203l5ZcmvMVdbu4tlPPH5S4V202sNbObFpOuNxQzzHk6VnpSXqEj1Ksk4A\/6U\/2KVuCNZpNe5syWHCfhkBdCND+lMJsKCr0eVw8jWyor1Q2tXM2miD+XZ3TzvURxENuqPctXrFhBCQKKV9TTuz6CVFpS2lvuXzWg+ij3L\/xjP2dhU6pr9t109bKl\/Yvvfu7+sUNO7nnnhGt+PTXQ5Fk0d9m89PSK7Ot33jd57nPXvPYn6ZSc+ZfNHnZKYbi48rQVY0ZeWRYpH3X1BeEzp51ZXZiTm2oU9RuybNrUtWc9zuO0KP6V3NNxP2Xw24sGv5JXwivs9tgQBBozJZI8XkNSKN2vl\/sMTBKK2+cvoALJGyz2SHGna7g+fKZzobPReYdTJczR65xNznbnbqcmXOYt3\/kDgouc7CAmNsBMzd8KWN703wru4NmfZxk2IlhKgKm\/OHfI8ygsDdg6J2k5JD5p2lHr33egVuxGdNSykA\/06+d\/0XQeLc4wNyPY1hqoFt8AEx5Vsj\/r9NrzLup1\/fUtTzyRWl6Wt36tf\/DsDfL5qyXnRZ23ru64+4xeWWIlCVm2l38rRBq7nbLYio81ohxNTWfn3f2xfsFQVXmqVORKTfdIqeluCPMAmon6pReHM1hxzRJacYbQhzOCwtDZtcGbIcR3RpcmnBGyTJ6WfS1DLG0yWBP2cnvEM6T2DCljTJZYebISnLU\/S16YtS6rKSuepWZ5ivWuiYO\/0hnVd+t7dVW3Jw69a+Kw7HuGsOoJRxBhyRNasC7Ma\/qYzCMWn2xGO1rdre0Qu0B1tTXWZ5MwiLJUP\/9EFHsj8cvrUHlVTzZ5XYFsYoW3Z88VmIJR1tonKi0Rbm4ZYkAM4LBSt2zPOb8Y63e3ugMXjx9\/26DWB1tHLRjbf5F8V0fLrX1Hjp9w+yq55tBb6J0stouidwzpM2sHNsPhIsOlSVqXq1uReBOnojzR4004vD3Z3yFRQaDGYPnuDdToWNBUufggQ9K1gEoWNXjRrOflV1EZDkLD0QuKqygdB8Teii0v611FURx8nh5UppcYNdTfGEUjjcnSZLnBNUWfI82R57rm6kvpCukK+UrXUv0KY6W0Ur5Rucm5ynWz\/nNao99pPE4bjF\/Tk86txov0rPEW7TH+Sh8ah+iA0QuPY4Qp3SijEqPaGEsxQ3fEgulVDrBKlf01UPbz01ihYJbyCcdDEjKU24LThOLErSJSZYfD4+ZN+HfL0TbAK+WvlFNFl0NgteF0uYp1I6TrBimyXGx6ijkMgwzT7UtzGrpCkqPCI3kKXLFYTG\/UZb1Nyn4i5mh0yA6EYnpUjkkF7s\/+wNz0RVZmx\/SO6VnhL\/ZNtz4V02XBCtQc+boYe\/JYPgCH\/0y\/POGGldpPkv6r86L\/3lccCZf\/dXvnxWpJx\/UXXDJxibzKtE6yX9WT4I6gmmu\/8xjkTQchfUzHC83SZl8XH7hUhVcrhwJRj3mivTXFNLNiauVQICbiRkCRyANtSNJ8aA2vR3zAxBOQZNVQA4ZlBzEFXYA\/ePWK\/41X\/K+L1x8t3z3xdPzHgyEbIzAk9VR7GPLowNmB2wJKIGp+btH6cJxqBwIsdvRIfpU\/J9e0kMaejBRVqZpHT9Wy9cygQyVVc+vuFFfQT6lKyJnjynbnYq1U7OzpKk+pov7Oga5BKcOUkVrMeYar3n2qb2RgdPBs35nB+c5ZrguCV2pXORe7tms7fNuCX2uH9DJ3oIzKvKUpZb7SYEXoZKoOXuG60bVGuc\/zqLRR3uh+xPMEbdN2pLygvqH9Sf9E\/cT3l+AB7Vs9xy3eK\/CIo18zXWPElC6OQYtts40UnxqkgMvpKnb6ilN4wZDiVLySp9jbFn8jVs1Sygvu6ylWBV4plKoZ7kCJUR6YqJ5pTAtcFFgWuDlgBAwVvMjdYXZMsptkRfmBCtM527+P\/5mzP\/5nx0KKcJ90OnTDcLk9HsMfCEC+17c4KAid5bTYHMOXEn0m4HRFnYFgsNzhDDkczhT0c7E3JeT1priwyi03XCEUZ59Ka6SQLDmDqssX8KR4RfWCkOP8tQweOkEfv2tlhA76vRK\/mN\/oVbxt0qMxIzrWkC4xrmVfO3lSTB8bkC4JXBtgV+ZJMbffIc0UFkkFg+vRJ6SDqQfnCJUo84wD06eHodfgPw+y6eFj+1Naoy4gjj\/AndKZ4q9lrLTcwuqbIhOmtHqjnqj8dHwvdNq9lBLf3Up9fNEgeLTrK2gN9U1VE8Rbxru3Ovm7VkjIn1Df1E+4frjie7c6o2Zq0HojlF\/g2L0NqiCuDWm1u9nZh6\/YTCfLO8w7dV28q1yGKBeI720xomqUTrZ8Na3XQV7fFqyhXkHxEtXW1MP+f6bllIefeFuUBYqQJ6kZwqlTKVWk+s6ndjxWp\/Z7bPva\/qds29LZ+tRjPd6EgPnZvsAu+eKONS+9Is859Ja87InvXoOk8WEe+jskjV96x5qH0nySW1NlXZM1LzjSJzRyX0W5YErx1ZvsJ31ByVeQab6GPi6zZqrvXvVe1\/0pD\/jaHe1au\/Mln+6LpddkKal6mjfL318a6F4h3eZ2VQTPUhucDe4pKfdJa4w17iflNs8L7l0pL\/vfUvbov\/e+7f\/ICNqDy+2hYMAX9kKx4DeAYikc8mkke8kwZE28CsosATFkOijO0TTF6dJ1SdN0diGFPob53Cv5fF6\/G0qF7HUrHr+h+WSf4X+OntNlfzHpISJdkb3PeSVvsUcJeTyKoeuKImtYCXg8ZIwNSsHTvMs9BYbvXE1fHjMwMzwZ08ZpjeIDW6fGUqLKcrlgLNrytMCy31nfVRaTBeYK\/0f+A1+It9sP87PwV7S4dbr1odEan2+lS3CpeQRh1q111VpM0ZoSzq1xizdTc2s8BRk1CsDx5vwav\/DzT6uRCvJr9FhO1ycAGoR5TuxGYMLpl8FTTzXvQyilkk+6vvP+D37RO6dXccubnXdKt7z71sDOT+UyqfObkX2G9jvU6el4VRrd0Dkdz5XfOV75G3gkS\/qnxSO5RsinuJWcTF9Qc2upsaAv6o55ohavZFaUZ72bFX4lK9PPRCzSxbSR3eLLkXz8EAtyaspCk31bDCXmjaFDomV9qvx8cHr0YLo3HCx1l3pKvQM8A7z9U+4PuMuCZamj0huCDakNaXODc1Pnpl2pLfFeGbgqdFXaDd6bA6uDq1NvCq0xNrqf9j8V2BH6zPhL6Gtvh\/+bUDwnz+ao9FR3TrbqG+a73qf4MruqbxoRgl0u6dU+n8cPWQnNITOUmlocNEKI+DwQhsVuA8tgI5XdNN0aX4By\/DlyRc7OHDmnTa57woe2iIXa5Ikxd10wFpRnBHcG5WCbNHSbTyqg4dkGnxKtFYt6+njGepRxnrhH9iBHS4UPbSPXtWZHl0EwovE6+EtrYCJ+Tz3sP7Avk7\/G\/kVW2P+FCFGYFw42R7kSN8+YpVYK\/oHUS4G0CUPaPEWe+Cfkjn8iJcqaUPy9bdU1RkF1TQpG2RNpNQHrhbMG1pf5wxFgn9RS02+gWriQWyoMf+i7sODa0KBetaMyAiUOd+eC375bXhAp\/7C186IhRX2WTa7qvOAxf1lR9nxfrlrWcf\/lK5YtkecfemHL0IYJ4uev+OdI5Nvv+mr1wRm+2q9d2S7xq1gbPiwVv0r\/jLrwjm+3dFzgJ5cHUR35JbLKOQd3jqFT\/fTtlm+v8pOV3vXn7a9ZSfybZhaa5DfpHHURpQGnOXPpCsdkmiKtpKnyJlrGUHIppj5OlyHvJsSHgO7gssg\/CXgfqAUmA1lW2hnAucAEjiPvdi6Layzk6wi6iKa6InSJY3K8A\/e71\/E8zQEeQniD+iFt1GpoAeIPo9xOlaia86DMvdomWoP0B3H+fKQ9BDoF8fUIT0O5PlZYd95KmUwBDek9cJ1brOctVX5DA9RF8Q\/wLA245mjgRtxjHOgIoB55UkGHAiul52mV9Hx8A86D0nW4\/0pOB4ZZdBSucwPO16FcEeLXIZyFemigPiAfKJMfpxo5RE+DVuD5zzKfG3ieLuRn7nom1N+q09Ew61ifCNzz10ChXBP\/CFRPqFsyrkvCaUo\/agSdD2QD4+VXaIF6Oklor\/sdH5HCAOdxO70HnKLOojGIS6jnBEcrPcBx4AyBRfEO9UFapxygk3HuKu1ePMcstHdf4CBVyH+lk7Riuhb8NQzXXwE8hGt+IvhhFk3E\/XuD9lM\/Ejx0I7Aa9\/rSbiduG8RXoF\/PxL2+4xGB8hOAkeiXRuAirg\/uX8Ftzv0uTe6sQd59yDONgfQMATw78ySX4fK4VrHFhxsOU9qAPLeiXfeCqkAa18GG4DMLOPccrpMJaEAu0Bv4CNgAzAcGAvVAGe5NuK8i+BU8w7wp+AO84XgebYi6CZ41n+Eh0Z\/mmFlvXYvvk689TvMt5PM1ebwwz6IuW+1r85hinrGp4O\/5gu\/\/xs\/JPNVFMfbUz2kk10GMQfCWTXncoc48Hu7FAmsV6APg4+uYZ7l+NuV2YV4TbYIxYdHahGftI8YIqEJUaPH6dTa126KLXkgP45oztfMgU9bRKHUxjVLupPPU\/TRM6UG9HX2QhudB3ib5czrT1U790JdjEb8\/ia5hOPdI8xzteM7NaM899HO06aXqHrlA3SM5HJvjnzpIetGxWV4uwkfRZEjt5jmmjMRzPzb934H8hmMzZObm+GeOPfE4nucuHhPOz6U+QNSmSG8GGgEsFaU1rvlSm3MS+bGQPgBcosZooCNG1Wo7+icNch5jAemTHB\/QTuVWukndE\/+T1EiN8h660ZlG58r3QqbhXvIbdB2Drw+6MIGPjuC5ZF6yqc2vyZRlvsVTEVAN4+9VC\/ssHAS+Bh\/VgyczeW5g+SzmB8ho4EaTX+PfdvHni\/RL0Fts\/kzi0\/lJ\/OlJ5stkKuYWyHd7nKIeN9nPz\/KRZRzLSJZzLGfs\/Mk0ofzN8ibwMcvhV2iqNa4LLIxGHf9sjX3IYfT3WfG4NiL+qNYa36gE4xu1SoT\/CDjij+K5l3bNqVPindZ82sOeS810ctvzqKMfLbDk2cNC3nxFPxXz6GRRP13bQtc6DqHfIQNFfddZYxDtiXrPV2eizR+g1XiOTGUlxiPSgWncJqIviMI8L\/CcqNyDdua56Fa6Tnkb+gKX7UcBMV\/U0Vmo+4siDXMqU05znEUbtM+pUp0EWdtOs7iv+Dm4Ptz3rsvJ60qDnNhDfdXHkCeNDORbJ9ogRo8KvuCy86FSoS2c55MTPDsGefh660WZGAWt9nhYtIUoD12EeZjbAtfU0uhMoU98Tmsdk+gsjKH1zkZar03CmEujjbjGL1FuEtcF5bLEfH0PnY3xtQqyaRVkDgn+nxo\/pGzG8yyFXAeURrTRZgo7GtGG88WzD1NNGbuSx4+yiUqYR7R7IIdZn7iHblbLabg2n25F2q0OyEnc9xakXY\/x2wdj9yaUj1hym3Dvm5DOZetYl2EdgceLM0apWqPQA0jUgfUU3F\/5lNYro2kV+HiI6x60ww10ElialcY8oK8JEV9uYbUJkeY3qZSv+OkaTpf70R9wBzdRnOfQ7eoKmqtOpkqlL8ZugE5Sf4+x+g39TPHRDHUX\/Uxto9UcV1OpTGnC87dCt+T012gcp8t\/QHwNTVVrUX4VXazOoEXKVvDe62Soc9DXKOe4DXxShPJf4boWpA9pqjIZY+tGhL+JP875xD1a42cx1FF0kiiXAFFXG0l1luvxVKPRp6gvh4+oL+raVU+7jseon3hOvi7KcR71Z\/x7UPF3gGKTdo6Xb6XNwDr5LTpVOYOulDbGd6BdRyRhVGJc7S8tA3qr\/elJYAXCvUD\/G9hixqG79ae3gRtw7d+AtmjCuCqRPJQGMEXaQ8Aa4CX7XCL4PsdKT4QjO77jiPgTmGsA6UB8ByM5P9p5AO43QD0lvoMBXhzN0K6lkHMJhZRSpOehXFLckY3x9AQVKRT\/54nq9H3AX5+EdowlPqPdH6DpPwDvJNAoU2tu+Lfr9u8C\/XstMF20798ozeQhSpHeiL8DOll6g\/zK5eBBAPGTEE+129PuJ6TfLdKT+g+8QtzmyenJ8eR+PVFcbqEZibD5oIsf7qLBDLUO+YHkuOtFGszQnsW5Z4+Oq4+eAFOpp\/IA1wk8WHp0XBtLpQy5CHXN4jIYc0BX\/DXICIDzivJeGsngscuQW7FeA7rO96fhjIR2HcDtqjxgnrf7x+6X5P5B\/WLqq3QaaAloDegE0NE2TRyzyeM2Oc2WJcfKkzQ2+hzvmv83AWNnF\/A88Nz\/1\/eSCLwK+AHtHeghddAj90A\/OZu9nzsgS76rAB6BHJoI+ibSMHt39gC8CAeQdgHoz4kOfY3wZUjfYyIuq9m0ztIrM5G2zSrrsq43wSx\/6AWibw8AW8zyhzYB8xD+O4D5\/NC7oL8BXYP8n6Hc9aC\/Nc93zEB8CfA04p8jfhEwBeE7QNNAewGpQBDl72WwPnLUOvQ\/To+9\/vihFDrL+ahnhG1eoMuS1xA\/mNr9eQKavNaw+\/9ENMFmkETNdsCa6c\/Q+5oS1z7ft8axKfqzMxHqpHgHdEoP69Gsy7L+LPRHi4r1m9BjcV+ikE1Zd2b9lXVn1l9B1wubgUPUZxKv80W9rHkjUbZKB+ghwA9kW3Q+8nwjl8Zfhezxgb+\/xtroYQbiKcBkE\/HXMHf5MNfthNz9GvQVxHNBv7bnNFu2HiVjTzCn\/afjP3aO\/Dfm1EoLM5JwvHQbJ1s4jZE8F\/9YnGju\/rfn8uPM0Ynz9P82bs\/zNvTBVMlwxuI7GMl66VF6wAniJ9Jzf2w8We\/40fEkvcSOJ+Oo88m8Z+szWZTVhaRx92PBawv1icO6v12H5HHcNd6sONpoeCIgB8qsOXQD5AX0\/3gugDkqfhfSlru+o0rXr6gS8ScAzJudX4DO4nOga6Vb2b7Nv4HU+RPE\/eorIu8UC7NOxM\/JfMv6udAP0WZCDt7B9acKYBAQBLYCC+y+5jUk7v0nGbMur3PVqfGv1VeBJB3whLQ\/XQr8CnEf4j7I4pAWgNyO0aNsjwc1QA3I9\/GHbXzxDu0qkWe0sC0vplGQ8xere9j2Ff+dsOl1En+1jfdRrsMcGrHtdIinsW3IGWV7SbzNss\/N1L7CPHgW5kOd5w7cd7LYE5qvsh33K\/qp4qZhlg05ZNuS2T7F85XWG2XYjpFoR\/6Q+qrTaBhQp5r7VJPY\/qJ8JPZqVrLdXRlDT1v7W03GJnpIf54ecs2iEa5rxX7TvcqDdB3SHnTeRg9q5WJ\/ZZI9r\/KceAzbH9sys7psmtYzJ+sEon7T6HS2xyTe1y7nGoG59CthhzLtmCfQbTDH3wzMMvcr4gePbe+Mv2zZPS+05vglXXN+sp1+Go1XlmPdZ9tkHwF9g85RbwSsNk6ui30vtEvH8XQhWzdB+Cxh6zP3e9gGlZqwDzdCtPOnor9O4z5zeDGGfdz\/8e2quT83VF2K\/DJlql8Cpu1R7M+xbZhtkAz5IYzRizFWwIPq3WIP73oLyBt\/RJS7yNw30yYAdajXHNxnE+8d2aAbDiO+T51ENwsIu1p8gxyKbwe9TH5J7DH6rL3ATHU1+nmmsEvbe4JhtUzYrcvUiQD6H7gS8SLx7BYVbRVDOR\/WdfyMbJvrTYRzLmWQZSO18jqfpBHOGPjVTSMcLVSkXAL9pR2yLgd9Nxr96qPrlD9Tnnoyna8EaBZDGhF\/VfocFJo6Q\/4M6X8CvRNx3vt9k86x99VM+zQdEtgFXQGw9nIZsxnyJinf2idssMK5ZhhpNbRNwL7GJnokAcgX\/zNwSP4p7j2UZsltuMc61AX3UfwYf0lAmfMslFn3GamehTF2JE5NBsoyrUgG0pkWJ8NKz0oG0pkOTQbShx6jHsfLd7x6HC+9JBlIL\/kP1ON41y1MBtILv6d+9clAev2PqMfx2rkoGUgv+p56jEkG0sck1wPyCevYzuewNn0c9I\/WfP8p6Omg4L7O3yGM9UV8jhX\/o5XvPgDr3\/j9ANbK8aEWIPPivAZeCfpXAOvq+PjD6HwRNMf0w7DvE78b6AlMNu\/FZTufMu8tYN2zs8Us3\/Erq74J8c504GPzfuLeLHt3gBYCD1j5V1n3bTLr3nn34fx8np9RlGs6jLgCnInzEdAJh9H5hIn4M6D\/BbBd9HngBSucZ7UHP\/OTfK3DcoG+FXtFvLeDudq5iUjM2VfT6ULmvnbEXGXuWX9IG4W8i0P21VKl5oUe8nMaynoDy3DHbJH\/FscszE0E\/WSy2M+br+4lh\/osZTo+ohnqxTRM2Qa9eCTkLe4h9mVwbZbbrHMoN9EZgNirFHtCvHeylFYarUJ\/8SNPSP0L6ns\/7cSabRXvn7E8d\/ZG\/A48y3pa6riarnItoJ3aftR1D83BfBXRZlCN4yc0yl7bagtId3igF1jULdH5eg7S2TfhYxqmr4Ret5vGoc2q7Xt3tYOTQkh\/xLSvdKLlOtH335UDp4s6o77Qw1SsrUO234BjOtpklqjPGLHn9BipWKOT40vM3adRmVOH7lVBq\/QwrdMO4jk03Ks8wV+A9+k3UYnzAurrWEkl9tpd24d2nkiGTXk\/zrYHQHdbr14o9MWg2Ney7AFd1L4G77c10mr2lUjWa2w9qkunsGwEXTYH+3lAef7sen6LJugbpk2hHfppGpXzPp6wiSRTq05iH68dvGTps86dNNqpgD5Cc7QbaYLjDLRLKk1wPkNB50gKs37mdAq9bgHP0Y5voItOoBLw\/qnWeL8C4LE00hrji5H+JvC4OR55fHG6GJtI63jASp8HLAPmmuf5XPxaM9zxpXl9cW6Zmb8D4zDOe3Bygq3mfRNiHRJN1FMtX6obj6KH9+6Zf0ackP5AGxqPYfapOsYefzK9G\/RCOw49732M0btQNgpoth6dTFXTP2W5SYVuyPSXFv0F8xrresk02X\/leP4s36PHmuPMpkf6vdj0HIuWdPnlnIAm+skcpvG4FU\/5obY7y+aWZdNj+B+YNrnDVDtq\/ZRIRZ+QYumxrL+PFvv87JvzPejy4foJeOBITGawP8GxoGEmYTgvOhKWnn9caLejHOCKJCP+DwbqvMJE\/GcWPrewgaFIWEsD6p3JiP9D4Nj+dcO0n+O+gOskE84XTQj9\/3uANiAnRrArKKjGc+H3AloGw\/mlhVtsxOMMu93tdrTbBc\/2MZ77wq462\/e3rvu\/7cf\/bb\/8p577++qeCMtHz6bsu6cds97oH4F\/mBC+NJso1YKGdn0K2AzssnA3A2Mli32VlNngp9nCX7GrzFF8cCvWpgwrbvnfaBo0O2fYHAfs+2OCGo7VPs7ZJv85S812En47pu71EZ7Da\/nYzrFkX5E+jtZbfrIRli2Yd3mc91F\/Q3OO1PniE8z1dHwD5kkH8gcci2mE\/FL8F46rIBP2x19wXAtdAMC9rrfwooV1pu4X32L5QWrCH3gTPZYIrG3zGJwH91sE\/NLSt1mPvcxE51\/M9MP1smWv8i88xyHKFP6lMbG+HqfOxZp+LmUqn+M89AXeb1LOpSE8ZygDoFuxz81Sy1+WbQ\/vgZrwol3GKRsTxjf717BfDSB8crifnsMcwPmfE+Xt9X2ZsC\/Nhxx\/myLC9wfnhE8PrsG+TqwXKVhROMaCL8Yj7\/j475U1oKMs\/Au4GPWdTHPl6+kkZQ7Ww7uh76Qh\/VLgEoTDoD6gAXgQWEJ9Rfoh8Mm3yA8oKuIvgzqwtncg7RsLq03webHe3kazoBPPwvXMfHtEGRMazZJ+K+41SxmK6yGfjJWSAo1CSbPCGs7fgHI7zfU72xU4vzhn59EP53F8QSOMOTRCSwVuiu9wDInvkD6lWnUqBdCnXqA\/+vpVa\/3AetRrAFor\/hDiu+RkvwB7n9yijl\/RXMcpdJKjA\/rBO+CDvVTrOEg\/c9RRmTYO89jjxLw0COC13Rz2Jxa+xHvir9q2bxvaFErTn6WR6ENi\/w2bypv5Ey143kliPhK+9BJrb5tNjUz4T5tjTei5zmF0HcbxCGCU5fc9x9wfgw6Ksaeafqpl6i8p19TjeA3VidaK83iYANnQZXtlyj5tzFuWLoii8cflP\/C6Nl7NexXyOPbXEmXPNtelcbZX\/xRgm+WDCftP9zL+\/97fkpP2oY63X3Qi34wT+WocFf+ReyrJvhsn8uU4YTxpz+VE+2XgVdaRR2Be2altiu9B\/EngTsjXhxkqxePCPmrqazcpboztxViDnkZFlk2U7aR5kF956mph07\/RvB6lQjYNNW3z8e+s9xyEPZVtc6yXKmHxHkSW9V4DX3+0Zb8V70102WmraBLLWpapYs5g326s0yBvZrFskV+kfvJ3pgyS9ggQyyJhlxyKOg4VVITlnpZMGUq63A\/PcrcJxRd\/UcikFFNmKYTrtbE8w\/xryqtcJcuUX\/LrpgyS30MeGweAz3ivRqynnzbnnM7HxNz0rSknhSxkOyTC4n0Uc\/3k4zHI78GcSF+ydMvNSfQpm55IL7TKbLbKHJ3f2rvBXJIq5uTnqQfbJrrWXUT9hG\/0x2K9MgrnWQc5rOfb9nbRT+gjc29fSl4X8H4O9629pjftZp2vJ9AZJsQ8ze34F+hlBubd08U9IOPEfs+i+AGrnrw+yQSf3tK19rPXcvZag2iQ+hA9rFwAXagP+ySJ+f7phPXtwwzmM+vlpp4\/EAuB\/eAqyEp5iYW\/gQOrAJxT9kJ6PwgNaikk\/QYiA2ts9ztEXuT3YfXhx\/MHsR4PIV9a7fGRDs0tDJmb2UaUjVtm\/44o5yqiPIMo4gcOmChAnQpaiYrfIyrFs5ThGXv8lqh8G1HvAqhjLxP1RblKzH1VWCEMGGei+iBRzYDjo9Zl4hRcrw7PNaQ30VBoscPQRyPSiUYaJk7DM47GtU\/HfDsG88O4yURnZpmYgFl+8gtEZ\/2VqOFmorM3Es1EHc7D9Wfd1o1udKMb3ehGN7rRjW50oxvd6EY3utGNbnSjG93oRje60Y1udKMb3ehGN7rRjW50oxvd6EY3utGNbnSjG93oRje60Y1u\/D8NiX+xib6iWvo5OUkmP1XwV03VC9VccpC8nSYqZS0l4cjup5UetBeQlR7N5bmR7Uqpkts8KBJrUwpbgmmVviEnKVFcrUIcozheAmwBdgIqzVDykO7H8VqgEdgC7AR2AxoRjnw2ClwCrAX28hklV8lpjkb8Q0qVTJTNRB19SgZ9CcQBhSI4VgBjgRnA7cBaQBP5OOUS4FpgJ7BfnIkpGc139UPdM5pvEaRl3kWVInquGZ02XURbzmow6RnjTTrsNDPbQDNb3yozufdQk5b2MmmwuLKRqeGtbB+SrqTjIdNR8YU4SvLvyCdJFKF1Sho1AbKiWSkxJdhSVFK5dqeikqTIikSzKBJvV6Rmb6ByiCHH5S8pSBH5b\/IX5hn5i5aUQOXaIaPlP9MWYCegyH\/Gvw\/kD+haeS+3OY51wFpgJ\/Aa8CWgyXvx7338e09+j3zyu1QB1AEzgLXATuBLwCm\/i6Nffoe5RRw5XAfI8js4+uW38Vhv4+iT30LoLfktVO1\/mqtrKreLQHmFFYgUW4GMbCsQTK9sk\/\/Q\/E0PcFQJehoc9ZRSQIOpn1LQXNw30qaEm2vnRtrkD1ui5ZF1Q\/rIr1MTIKMmr+POr1MUGAfMBBYCGkJvIPQGNQJ3AOuAJgBchqMfiMq7gJeBN6gPEAPGAS55dzNu0ya\/1lwyNDIkXX5Vfp4y0OKvyC8I+rL8nKAvyc8K+iJoHugu+bnmvAgNceM8oYwf1A9agfMO+TctRcFIfEhA3om2i+BYAdQBY4EZwO2AJu+UC5pnRYK4yFO0y0XI2UyfCvoIbXBRbF4kVnIqGDDKh5KBpyCEw9ro2hI5VnLv\/YjyoeS2uxDiQ8n1qxHiQ8lVKxDiQ8lFSxDiQ8mseQjxoWTqDIT4UDJ2IkI4tMkPPVlUGqkeO1+KDvHJV6CVrkArXYFWuoJU+Qr+R9+oXLefNffsiRZ7IFbeo2ekcYfU+LTUeKbUuEFqnC01LpcaV0iNtVLjOVJjudSYIzXmSY0xqfEp6WQ0RaMUaz0iWhMLS427pMZfSY2LpMYSqbFYaiySGqNSdaxNzm8+rZ8gwwVpGcKDDvSUwZA+PjkfLZoPns+HTNiJ42tAXMRiyBQtMDNn5jEtaOlZZ8Z7D6y8ZMgo+RkUfAbd8Ay9D6jooGfARs\/gIs\/gAj4c64AZQDvwJRAHNOQuQMVvF0cfjhVAHTADuBb4EtBEdb4EZLrEquIWUbEKq9JjOSY\/g38F+Jcv58dy\/Tn+cv8o5fYcyZcnjc2L58nVlJ5ORMGAK9Amebf90\/uvf3pJH6LLt8m3Uy464g6L3t78TW6kTVrTXPJUZEiadB\/lqeA6qYZKpGLQk2mRiPenHBfTKsqRN4NWNudMRjFfc0mvyA4phUtti3yTsy\/yaU6bjOAnOU9F3oy2qVJzZA9SNm+LvJ5zU+TFijYXUp4uaZNAdkRF1u05J0d+tUtkXYETDzRHljPZFrkmZ2Rkfo44Mds8cc4ixGK+yJklUyOjcL1hOedFYotwzW2RupxzIrVmrv5cZlukD6pQbgZ7orI9csRNC\/PEBSdVt0kXxno573VOcY51DnBWOns5850RZ64z2xlyBV1+V4rL4zJcLpfmUl2yi1yhtvjeWDn\/gmFIEz9kyK8sS6SKsF\/mo\/j+Av8ir0um0dSUqtTL9ROGSvVN7edT\/XnRpoMTCtskY\/zUJkfhUKkpWE\/1E4c2nVxe3+aMn9lUXV7f5Bx39pStknRbA1Kb5FVtEk2c0ibFOemG7KbgqVO2kyQFbrg1m2nZDbc2NFA4fUlduC44OFAzYtgxDjOtY8LPW4ePCOc23Vs\/YUrTptyGpkoOxHMb6pvunhCdNmW79JW0f\/iw7dLfmTRM2a4Mlr4afianK4OHNTTUt0mTRT6KSn9HPnDM30U+FyZmzkdRV56Z7wEzXzHKI18RE+TTdSoW+Yp1XeRTJc63dVHR8GFbi4pEnowoLRJ5FmVEE\/PsKkae4mKRJ72Rdok8u9IbOU\/TYJElJwdZ8nJEFimLckSWHClLZJl8OEuFleWmriw3iTsp0uE8OWYe7147j3cv8pT\/0L\/ZQ8vLpZZBDedPGz67cPjMwuGzgZlNtyy5MNzUeF40uvX8Bj4RbVJKZp53\/oVMz53d1FA4e1jT+YXDolsHTTvG6Wl8elDhsK00bfjEKVunxWYPax4UGzS88NxhDS0jx1VVH3Gvm7ruVTXuGBcbxxer4nuNrD7G6Wo+PZLvVc33quZ7jYyNFPciwePjpmx10dCGU6eZtEV2G+DXmdn5DUPT\/QsHC+YdlB9enr0D2spGcpc3NHkKhzZ5AT510pCThvApjCk+lYJkn3UqvHxQfvYOaaN1yo\/kQOFQKl98+aLLKTx87jDz\/yL8IWnx5dzg5rF80fH+cG54U+zcYYsWE9U39ZxQ31Q3fuqUrU4nUmfyIzUNtNPc7uFt8XYzsTcSB3KionRl5LRaTtN1K+PR\/X+5RcXvuDbKT7VIsTxpMS1qUJry6ifKEAUTp+JZp02dsgO6FE8PixrwgIukcmmRfQ2r2uZvSjPhZ7ax+HIrZLXFYouaJVFkkd0kXX\/cWOVdLbYYF6T\/A6Egza8KZW5kc3RyZWFtCmVuZG9iagoxNyAwIG9iago8PC9JdGFsaWNBbmdsZSAwL0ZvbnRCQm94Wy02NjQgLTMyNCAyMDAwIDEwMDVdL0ZsYWdzIDMyL0ZvbnRGaWxlMiAxNiAwIFIvRm9udE5hbWUvSUJZSlZHK0FyaWFsTVQvQXNjZW50IDcyOC9UeXBlL0ZvbnREZXNjcmlwdG9yL0NhcEhlaWdodCA3MTYvRGVzY2VudCAtMjEwL1N0ZW1WIDgwPj4KZW5kb2JqCjMgMCBvYmoKPDwvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nL0ZpcnN0Q2hhciAzMi9UeXBlL0ZvbnQvTGFzdENoYXIgMTIxL1N1YnR5cGUvVHJ1ZVR5cGUvV2lkdGhzWzI3NyAwIDAgMCAwIDAgMCAxOTAgMzMzIDMzMyAzODkgMCAyNzcgMzMzIDI3NyAyNzcgNTU2IDU1NiA1NTYgNTU2IDU1NiA1NTYgNTU2IDU1NiA1NTYgNTU2IDI3NyAwIDAgMCAwIDAgMCA2NjYgNjY2IDcyMiA3MjIgNjY2IDYxMCA3NzcgNzIyIDI3NyAwIDY2NiA1NTYgODMzIDcyMiA3NzcgNjY2IDc3NyA3MjIgNjY2IDYxMCA3MjIgNjY2IDk0MyAwIDY2NiA2MTAgMCAwIDAgMCAwIDAgNTU2IDAgNTAwIDU1NiA1NTYgMjc3IDU1NiA1NTYgMjIyIDAgNTAwIDIyMiA4MzMgNTU2IDU1NiA1NTYgMCAzMzMgNTAwIDI3NyA1NTYgNTAwIDcyMiA1MDAgNTAwXS9Gb250RGVzY3JpcHRvciAxNyAwIFIvQmFzZUZvbnQvSUJZSlZHK0FyaWFsTVQ+PgplbmRvYmoKMTQgMCBvYmoKPDwvQ291bnQgMS9JVFhUKDIuMS43KS9UeXBlL1BhZ2VzL0tpZHNbMSAwIFJdPj4KZW5kb2JqCjE4IDAgb2JqCjw8L05hbWVzWyhKUl9QQUdFX0FOQ0hPUl8wXzEpIDE1IDAgUl0+PgplbmRvYmoKMTkgMCBvYmoKPDwvRGVzdHMgMTggMCBSPj4KZW5kb2JqCjIwIDAgb2JqCjw8L1BhZ2VzIDE0IDAgUi9WaWV3ZXJQcmVmZXJlbmNlczw8L1ByaW50U2NhbGluZy9BcHBEZWZhdWx0Pj4vTmFtZXMgMTkgMCBSL1R5cGUvQ2F0YWxvZz4+CmVuZG9iagoyMSAwIG9iago8PC9Nb2REYXRlKEQ6MjAxOTA0MDcxMzEyMTgrMDgnMDAnKS9Qcm9kdWNlcihpVGV4dCAyLjEuNyBieSAxVDNYVCkvQ3JlYXRpb25EYXRlKEQ6MjAxOTA0MDcxMzEyMTgrMDgnMDAnKS9DcmVhdG9yKEphc3BlclJlcG9ydHMgXChDSU1JRUZvcm1cKSk+PgplbmRvYmoKeHJlZgowIDIyCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAxMTIxMiAwMDAwMCBuIAowMDAwMDExNjA3IDAwMDAwIG4gCjAwMDAwNDM1MzEgMDAwMDAgbiAKMDAwMDAwMDAxNSAwMDAwMCBuIAowMDAwMDAyNDkyIDAwMDAwIG4gCjAwMDAwMDI2NTggMDAwMDAgbiAKMDAwMDAwMzc1OCAwMDAwMCBuIAowMDAwMDAzOTI0IDAwMDAwIG4gCjAwMDAwMDUwMDcgMDAwMDAgbiAKMDAwMDAwNTE3MiAwMDAwMCBuIAowMDAwMDA2MTI4IDAwMDAwIG4gCjAwMDAwMDYyOTQgMDAwMDAgbiAKMDAwMDAwNzI4NiAwMDAwMCBuIAowMDAwMDQzOTk1IDAwMDAwIG4gCjAwMDAwMTE1NzEgMDAwMDAgbiAKMDAwMDAxMTY5NSAwMDAwMCBuIAowMDAwMDQzMzQ5IDAwMDAwIG4gCjAwMDAwNDQwNTkgMDAwMDAgbiAKMDAwMDA0NDExNSAwMDAwMCBuIAowMDAwMDQ0MTQ5IDAwMDAwIG4gCjAwMDAwNDQyNTUgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDIyL1Jvb3QgMjAgMCBSL0lEIFs8ZTg5MWFhYzEwNTgyMDMzNTA0ZjU3ZDVhZWM0OWJhMmY+PDNkY2EyMzhkNTk0NTVmNmU2MDdjMmYyNmQ0YjViNWQzPl0vSW5mbyAyMSAwIFI+PgpzdGFydHhyZWYKNDQ0MTUKJSVFT0YK"; // shortened
////    					var pdfAsArray = glblUtil.convertDataURIToBinary(pdfAsDataUri);
////    					PDFJS.getDocument(pdfAsArray);
////    					console.log(pdfAsArray);
////    					alert("INTERNAL_REQUEST_FORM.pdf"+pdfAsArray);
//    				}else if(item[0].status == "Not Started"){
//            			formsLibrary.createRequest(0,dataStore);
//            		}else{
//            			formsLibrary.createRequest(1,dataStore);
//            		}
//        		}
//        	});
//        	}, true);
	},
		
		getNewWFTrackNo :function(strWFId, strWFCode, strWFModId, strUserId,strWorkflowNo) {
			var data = [];
			data["strWFId"] = strWFId;
			data["strWFCode"] = strWFCode;
			data["strWFModId"] = strWFModId;
			data["strUserId"] = strUserId;
			var requestParams = {};
			requestParams =  data;
			requestParams.callingFunction = "getNewWFTrackNo";
			globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FormLibraryService",{
				requestParams: requestParams,
				backgroundRequest: false,
				requestCompleteCallback:globalLang.hitch (this,function(response) {
					var strWFTNo =  response.WFTNo;
					globalWorkFlowNo = strWFTNo[0].WFTNo;
					strWorkflowNo(globalWorkFlowNo);
					formsLibrary.changeGridDataJsonWF("myFormListGrid","","id");
					dijit.byId('cmdCloseWF').set('disabled',false);
					dijit.byId('cmdCancelWF').set('disabled',false);
				})
			});
			
		},
		
		getWorkFlow :function(strCustName, strWFNo, strUserId, strWFModId, strWFUIModId) {
			var data = [];
			data["strCustName"] = strCustName;
			data["strWFNo"] = strWFNo;
			data["strWFUIModId"] = strWFUIModId;
			data["strWFModId"] = strWFModId;
			data["strUserId"] = strUserId;
			var requestParams = {};
			requestParams =  data;
			requestParams.callingFunction = "getWorkFlow";
			globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FormLibraryService",{
				requestParams: requestParams,
				backgroundRequest: false,
				requestCompleteCallback:globalLang.hitch (this,function(response) {
					var workFlowList =  response.workflow;
					if(workFlowList.length == 0){
						glblUtil.alertMsg('No result found or does not match your current selection.');
					}else if(workFlowList.length > 1){
						workFlow = [];
						for(var i in workFlowList){
							var strTrackNo = workFlowList[i].wfTrackNo;
							var strId = workFlowList[i].wfId;
							var strStatus = workFlowList[i].wfStatus;
							var strCustName = workFlowList[i].wfCustName;
							var strRqstDate = workFlowList[i].wfRqstDate;
							var strCreDate = workFlowList[i].wfCreDate;
							var strCreUser = workFlowList[i].wfCreUser;
							workFlow.push({strTrackNo:strTrackNo, strId:strId, strStatus:strStatus, strCustName:strCustName, strRqstDate:strRqstDate, strCreDate:strCreDate, strCreUser:strCreUser});
						}
						workFlowStore = new globalItemFileWriteStore({data:{
							items:workFlow
						}});
						globalWFSearch.SearchPopUp(strWFModId,workFlowStore,thisMainObj);
					}else if(workFlowList.length == 1){
						var strRqstDate = workFlowList[0].wfRqstDate;
						glblUtil.getWorkFlowDetail(strWFModId,workFlowList[0].wfTrackNo,function(callback){
							if(callback!="error"){
								formsLibrary.getRequest("myFormListGrid","id", callback,strRqstDate);
					        	dijit.byId('txtCusName').set('readOnly',true);
					        	dijit.byId('txtWrkFlwNo').set('readOnly',true);
					        	dijit.byId('txtCusName').set('value',workFlowList[0].wfCustName);
					        	dijit.byId('txtWrkFlwNo').set('value',workFlowList[0].wfTrackNo);
					        	dijit.byId('cmdWrkFlw').set('disabled',true);
					        	dijit.byId('cmdSearch').set('disabled',true);
					        	dijit.byId('workflowType').set('disabled',true);
					        	dijit.byId('cmdCloseWF').set('disabled',false);
					        	dijit.byId('cmdCancelWF').set('disabled',false);
					        	if(workFlowList[0].wfStatus == "Completed"){
					        		dijit.byId('cmdLaunchWF').set('disabled',false);
					        	}
							}else{
								glblUtil.alertMsg('No result found or does not match your current selection.');
							}
							
						});
					}
				})
			});
			
			
			
		},
		createDocumentPdf:function(strCustomerName,strRequestNo,strFolderName,strUserName,strSolutionPrefix,callback){
			var requestParams = {};
			requestParams.customerName = strCustomerName;
			requestParams.requestNo = strRequestNo;
			requestParams.folderName = strFolderName;
			requestParams.userName = strUserName;
			requestParams.solutionPrefix = strSolutionPrefix;
			requestParams.callingFunction = "createDocumentPdf";
				globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FileNetService",{
					requestParams: requestParams,
					backgroundRequest: false,
					requestCompleteCallback:globalLang.hitch (this,function(response) {
						var strPdfVsId =  response.strPdfVsId;
						if(strPdfVsId != undefined){
							callback(strPdfVsId);
						}else{
							callback(0);
						}
					})
				});	
		},
		createDocumentJson:function(strCustomerName,strRequestNo,strFolderName,strCaseFolderId,callback){
			var requestParams = {};
			requestParams.customerName = strCustomerName;
			requestParams.requestNo = strRequestNo;
			requestParams.folderName = strFolderName;
			requestParams.caseFolderId = strCaseFolderId;
			requestParams.callingFunction = "createDocumentJson";
				globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FileNetService",{
					requestParams: requestParams,
					backgroundRequest: false,
					requestCompleteCallback:globalLang.hitch (this,function(response) {
						var strJsonVsId =  response.strJsonVsId;
						if(strJsonVsId != undefined){
							callback(strJsonVsId);
						}else{
							callback(0);
						}
					})
				});	
		},
		createCustomObject:function(strRequestNo,strCaseFolderId,callback){
			var requestParams = {};
			requestParams.requestNo = strRequestNo;
			requestParams.caseFolderId = strCaseFolderId;
			requestParams.callingFunction = "createCustomObject";
				globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FileNetService",{
					requestParams: requestParams,
					backgroundRequest: false,
					requestCompleteCallback:globalLang.hitch (this,function(response) {
						var strCOId =  response.strCOId;
						if(strCOId != undefined){
							callback(strCOId[strCOId.length-1].coId);
						}else{
							callback(0);
						}
					})
				});	
		},
		getCustomObjectProperties:function(){
			var requestParams = {};
			requestParams.callingFunction = "getCustomObjectProperties";
				globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FileNetService",{
				requestParams: requestParams,
				backgroundRequest: false,
				requestCompleteCallback:globalLang.hitch (this,function(response) {
					var strReferenceNumber =  response.ReferenceNumber;
//					alert(strReferenceNumber);
					
				})
			});	
		},
//		setMainCustomerCO:function(strWfNo,strRqstNo,callback){
//			var requestParams = {};
//			requestParams.WorkflowNumber = strWfNo;
//			requestParams.RequestNumber = strRqstNo;
//			requestParams.callingFunction = "setMainCustomerCO";
//			globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FileNetService",{
//			requestParams: requestParams,
//			backgroundRequest: false,
//			requestCompleteCallback:globalLang.hitch (this,function(response) {
//					var strCustomerCOVsId =  response.strCOVsId;
//					if(strCustomerCOVsId != 0){
//						callback(strCustomerCOVsId);
//					}else{
//						callback(0);
//					}
//						
//				})
//			});	
//		},
//		setNamesVerifiedCO:function(strWfNo,strRqstNo,callback){
//			var requestParams = {};
//			requestParams.WorkflowNumber = strWfNo;
//			requestParams.RequestNumber = strRqstNo;
//			requestParams.callingFunction = "setNamesVerifiedCO";
//			globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FileNetService",{
//			requestParams: requestParams,
//			backgroundRequest: false,
//			requestCompleteCallback:globalLang.hitch (this,function(response) {
//					var strCustomerCOVsId =  response.strCOVsId;
//					if(strCustomerCOVsId != 0){
//						callback(strCustomerCOVsId);
//					}else{
//						callback(0);
//					}
//						
//				})
//			});	
//		},
		sampleEventAction:function(){
			var requestParams = {};
			requestParams.callingFunction = "checkNamesCO";
			globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FileNetService",{
			requestParams: requestParams,
			backgroundRequest: false,
			requestCompleteCallback:globalLang.hitch (this,function(response) {
						alert(response.ExistingRequestDate);
				})
			});	
		},
		setCIMInternalLog:function(userid, strWorkflow, strWfAction, strStepId, strWfResponse, strWfTaskStatus, strRequestNo, strStepRemarks, strRoutedTo, strCompletionTime, callback){
			var requestParams = {};
			requestParams.userid = userid;
			requestParams.wfNo = strWorkflow;
			requestParams.wfAction = strWfAction;
			requestParams.stepId = strStepId;
			requestParams.wfResponse = strWfResponse;
			requestParams.wfTaskStatus = strWfTaskStatus;
			requestParams.requestNo = strRequestNo;
			requestParams.stepRemarks = strStepRemarks;
			requestParams.routedTo = strRoutedTo;
			requestParams.completionTime = strCompletionTime;
			
			requestParams.callingFunction = "CIMInternalLog";
				globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FormLibraryService",{
					requestParams: requestParams,
					backgroundRequest: false,
					requestCompleteCallback:globalLang.hitch (this,function(response) {
						//response.isSaved;
					})
				});	
		},
		setCIMInternalLogLaunch:function(userid,strWfNo,requestNo){
			var strwfAction = "1";
			var stepId = "CDMS_01_1410_01"; 
			var wfResponse = "";
			var wfTaskStatus = "0";
			var stepRemarks = "";
			var completionTime = "";
			formsLibrary.setCIMInternalLoglaunch(userid,strWfNo, strwfAction, stepId, wfResponse, wfTaskStatus, requestNo, stepRemarks, completionTime);
			
		},
		setCIMInternalLoglaunch:function(struserid, strWorkflow,  strWfAction, strStepId, strWfResponse, strWfTaskStatus, strRequestNo, strStepRemarks,  strCompletionTime, callback){
			var requestParams = {};
			requestParams.userid = struserid;
			requestParams.wfNo = strWorkflow;
			requestParams.wfAction = strWfAction;
			requestParams.stepId = strStepId;
			requestParams.wfResponse = strWfResponse;
			requestParams.wfTaskStatus = strWfTaskStatus;
			requestParams.requestNo = strRequestNo;
			requestParams.stepRemarks = strStepRemarks;
			requestParams.completionTime = strCompletionTime;
			requestParams.callingFunction = "CIMInternalLogLaunch";
				globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "CIMIProcessorService",{
					requestParams: requestParams,
					backgroundRequest: false,
					requestCompleteCallback:globalLang.hitch (this,function(response) {
						//response.isSaved;
					})
				});	
		},
		getExtRqstWithAuthLetter:function(varRequestNo, callback){
			var content = {};
			content.strRequestNo = varRequestNo;
			content.callingFunction = "getExtRqstWithAuthLetter";
			globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "CIMReportService",{
				requestParams: content,
				backgroundRequest: false,
				requestCompleteCallback:globalLang.hitch (this,function(response) {
					if(response.strReportUrl != "0"){
						var varWindowUrl = glblReportUrl + varRequestNo + "/" +response.strReportUrl;
						callback(varWindowUrl);
					}
				})
			});
		}
};

function getTodate(){
	globalToday = new Date();
	var dd = globalToday.getDate();
	var mm = globalToday.getMonth()+1; //January is 0!
	var yyyy = globalToday.getFullYear();
	globalTime = globalToday.toLocaleTimeString();
	if(dd<10) {
	    dd = '0'+dd;
	}; 

	if(mm<10) {
	    mm = '0'+mm;
	};

	globalToday =  yyyy + '' + mm + '' + dd;
	
};

function getMyInboxInstruction(){
	var requestParams = {};		
	requestParams.callingFunction = "getInstruction";
	requestParams.WFInstructionID = "20191126000001";
		globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "MyInboxService",{
			requestParams: requestParams,
			backgroundRequest: false,
			requestCompleteCallback:globalLang.hitch (this,function(response) {
				var result =  response.instruction;
				dojo.byId("instructionContent1").innerHTML = result[0].wfinstruction;
				//globalDom.byId("instructionContent1").innerHTML = result[0].wfinstruction;

			})
		});	
};

function launchFormsLibCIM(){//Launch in filenet side
	var requestParams = {};	
	var cimLaunchParams = [];
	cimLaunchParams["strRequiredForm"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"requiredForm");
	cimLaunchParams["strCustomerName"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"customerName");
	 var gridRequestNo = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"requestNo");
	cimLaunchParams["strStatus"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"status");
	var wfNo = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"wfNo");
	var stepId = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"strStepId");
	cimLaunchParams["strWorkFlowDtlId"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"WorkFlowDtlId");
	cimLaunchParams["strWorkFlowId"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"WorkFlowId");
	cimLaunchParams["strContext"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"Context");
	cimLaunchParams["StrName"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"StrName");
	cimLaunchParams["StrUiDisplayName"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"StrUiDisplayName");
	cimLaunchParams["StrFileName"] = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"StrFileName");
	cimLaunchParams["queueName"] = "CDMS_CIMRoster";
	cimLaunchParams["searchCriteria"] =  "strWorkflowNo ='"+wfNo+"' AND StepID = '" + stepId+"'";
	cimLaunchParams["strRequestNo"] = gridRequestNo;
	cimLaunchParams["strStepId"] = stepId;
	cimLaunchParams["strUserId"] = globalUserId;
	cimLaunchParams["strWFNo"] = wfNo;
	requestParams = cimLaunchParams;
	requestParams.callingFunction = "launchFormsLibCIM";
		globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "CDMSLaunchRequestService",{
			requestParams: requestParams,
			backgroundRequest: false,
			requestCompleteCallback:globalLang.hitch (this,function(response) {
				var result =  response.strReturnValue;
//				alert(result);
				if(result == "success"){
					updateWFTrackerCI(wfNo,gridRequestNo,stepId,"");
					clearFields();
					
				}else{
					glblUtil.alertMsg('Failed to launch request. Please contact System Administrator');
				}
			})
		});	
};


function launchExternalRequest(){//For External
	var requestParams = {};	
	var content = [];
	var varRequestNo = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"requestNo");
	var varWorkflowNo = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"wfNo");
	var varStatus = myFormListGrid.store.getValue(myFormListGrid.getItem(0),"status");
	
	content["strUserId"] = globalUserId;
	content["strWFNo"] = varWorkflowNo;
	content["strRequestNo"] = varRequestNo;
	content["strStatus"] = varStatus;
	
	requestParams = content;
	requestParams.strCallingFunction = "launchExternalWF";
		globalECMRequest.invokePluginService("CDMSCISMEXTCustomWidgetsPlugin", "FNProcessService",{
			requestParams: requestParams,
			backgroundRequest: false,
			requestCompleteCallback:globalLang.hitch (this,function(response) {
				var result = response.strReturnValue;
				if(result.toString() == "success"){
					updateWFTrackerCI(varWorkflowNo,varRequestNo,"","");
					clearFields();
				}else{
					glblUtil.alertMsg('Failed to launch request. Please contact System Administrator');
				}
			})
		});
};


function updateWFTrackerCI(wfTrckNo1,rqstNo,stepId,strResponse){//Launch in database side
	var requestParams = {};
	var paramData = [];
	//var emailAddress = getEmailAddress(stepId,strResponse);
	var emailAddress = "karl.torres@absionline.com";
	paramData["strWFTrckNo"] = wfTrckNo1;
	paramData["strRqstNo"] = rqstNo;
	paramData["strStepId"] = stepId;
	paramData["strResponse"] = strResponse;
	requestParams = paramData;
	requestParams.callingFunction = "updateWFTrackerCI";
		globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "FormLibraryService",{
			requestParams: requestParams,
			backgroundRequest: false,
			requestCompleteCallback:globalLang.hitch(this,function(response){
				var isUpdate =  response.isUpdate;
				if(isUpdate!=0){
					glblUtil.alertMsg('Workflow has already been launched.\r\n Workflow Number: '+wfTrckNo1 + 
							'\r\nRequest Number: ' + rqstNo+
							'\r\n &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp You will receive an e-mail in '+emailAddress+' regarding the launched workflow shortly.',1);
				}else{
					glblUtil.alertMsg('Failed to launch request.');
				}
			})
		});	
};

function clearFields(){
	dijit.byId('txtCusName').set('readOnly',false);
	dijit.byId('txtWrkFlwNo').set('readOnly',false);
	dijit.byId('workflowType').set('disabled',false);
	dijit.byId('cmdWrkFlw').set('disabled',false);
	dijit.byId('cmdSearch').set('disabled',false);
	dijit.byId('cmdLaunchWF').set('disabled',true);
	dijit.byId('cmdCancelWF').set('disabled',true);
	dijit.byId('cmdCloseWF').set('disabled',true);
    dijit.byId("workflowType").reset();
	dijit.byId('txtCusName').set('value','');
	dijit.byId('txtWrkFlwNo').set('value','');
    dijit.byId("workflowType").set('value','');
	glblUtil.changeGridStore("myFormListGrid", null);
}
