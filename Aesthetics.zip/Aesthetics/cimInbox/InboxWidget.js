var glblUtil;
var glblRqstType;
var globalTabContainer;
var globalContentPane;
var globalBorderContainer;
var globalDom;
var globalPayload;
var globalICMUtil;
var globalDataGrid;
var globalall;
var globalECMRequest;
var globalLang;
var WFInstructionID;
var WFInstructionName;
var WFInstructionText;
var globalHtml;
var globalAttr;
var inboxGridId;
var InboxStore;
var InboxData = [];
var globalItemFileWriteStore;
var PageLimit = 50;
var PageNum = 1;
var completeLevel = 3;
var strIsFiltered = 0;
var thisMainObj;
var solution; 
var solutionPrefix = "";
var strInstructionId = "";
var strMainPageId = "";
//var strPageId;
var reqPayload = {};
var gridId="gridInbox";
var gridInbox;
var strStepCode;
var wfDetailsPayload = {};
var glblVariousSEC;
var cmdHist = "<INPUT TYPE='button' data-dojo-type='dijit.form.Button' CLASS='viewIcon' onclick=''/>View";
var cmdHistory = function(){
	 var cmdHist = new dijit.form.Button({ 
        label: 'View',
        iconClass: "viewIcon"
	 });
	
	return cmdHist;
};
var grid;
var glblReviewAttachedReport;
var glblViewNamesVerifiedTaskHistory;
var globalRqstTypeHist;


define([
	"dojo/_base/declare",
	"dojo/json",
	"icm/base/BasePageWidget",
	"icm/base/_BaseWidget",
	"dojo/text!./templates/InboxWidget.html",
	"cdmsPluginCustomWidget/util/Util",
	"cdmsPluginCustomWidget/util/ICMUtil",
	"dijit/form/Button",
	"dijit/form/TextBox",
	"dijit/form/DateTextBox",
	"dijit/form/ComboBox",
	"dijit/layout/ContentPane",
	"dijit/layout/TabContainer",
	"dijit/layout/BorderContainer",
	"dojo/dom",
	"dojo/dom-attr",
	"dojo/domReady!",
	"dojo/ready",
	"dojo/on",
	"dojox/grid/DataGrid",
	"dojo/promise/all",
	"ecm/model/Request",
	"dojo/_base/lang",
	"dojo/data/ItemFileWriteStore",
	"cdmsPluginCustomWidget/lookup/ReviewAttachedReport",
	"cdmsPluginCustomWidget/lookup/VariousSEC",
	"cdmsPluginCustomWidget/lookup/ViewNamesVerifiedTaskHistory",
	"cdmsPluginCustomWidget/lookup/ViewRequestTypeHistory"
	
], function(declare, json, BasePageWidget, _BaseWidget, template,Util,ICMUtil,Button,TextBox,
		DateTextBox,ComboBox,ContentPane,TabContainer,BorderContainer,dom,domAttr,domReady,
		ready,onObj,DataGrid,all,ecmReq,lang,ItemFileWriteStore,ReviewAttachedReport,VariousSEC,ViewNamesVerifiedTaskHistory,ViewRequestTypeHistory){

		glblUtil = Util;
		globalDom = dom;
	 	globalTabContainer = TabContainer;
		globalContentPane =  ContentPane;
		globalBorderContainer = BorderContainer;
		globalICMUtil = ICMUtil;
		globalDataGrid = DataGrid;
		globalall = all;
		globalLang = lang;
		globalECMRequest = ecmReq;
		globalAttr = domAttr;
		globalItemFileWriteStore = ItemFileWriteStore;
		glblReviewAttachedReport = ReviewAttachedReport;
		glblVariousSEC = VariousSEC;
		glblViewNamesVerifiedTaskHistory = ViewNamesVerifiedTaskHistory;
		globalRqstTypeHist = ViewRequestTypeHistory;
		
	return declare("cdmsPluginCustomWidget.cimInbox.InboxWidget", [_BaseWidget, BasePageWidget], {
		templateString: template,

		postCreate: function(){
			solutionPrefix = this.solution.getPrefix();
			thisMainObj = this;
			solution = this.getSolution(); 
			
			globalUserId = ecm.model.desktop.userId;
			
			onObj(this.cmdCloseInbox, "click", function(evt){
				if (confirm('Are you sure you want to close this inbox?')) {
					globalICMUtil.closePage(thisMainObj);
				}
			});
//			glblUtil.getUserWorkflowStep(globalUserId,function(data){
//				if(data.stepCode!=undefined){
//					strStepCode = data.stepCode;
//					subWFCode = data.subWorkflowCode;
//					if(strStepCode == "CDMS_01_2100_05"){
//						glblRqstType = "LOANDEX";
//						strPageId="ReviewAttachedReportFromLoandex";
//					}else if(strStepCode == "CDMS_05_2140_02"){
//						glblRqstType = "NFIS";
//						strPageId="ReviewAttachedReportFromNFISCMAP";
//					}else if(strStepCode == "CDMS_05_2140_03"){
//						glblRqstType = "NFIS";
//						strPageId="ReviewReleaseReportFromNFISCMAP";
//					}else if(subWFCode == "CDMS_05_1003_03"){
//						strStepCode = subWFCode;
//						glblRqstType = "SEC";
//						strPageId="CheckSECDTIOnline";
//						inbox.inboxTable(strStepCode);
//					}
//				}
//			});
			

			
			InboxStore = new globalItemFileWriteStore({data:{
				items:InboxData
			}});
		},
		handleICM_WidgetLoadedEvent: function(payload) {
			
			
		
		},
		handleICM_PageOpenedEvent: function(payload) {
			if(payload.wfData != undefined){
				var wfData = payload.wfData;
				console.log(wfData);
				inbox.inboxTable(wfData);
				
				strStepCode = wfData.stepCode;
				strSubWorkflow = wfData.subWorkflowCode;
				strInstructionId = wfData.instructionId;
				strMainPageId = wfData.mainPageId;
				
//				document.getElementById("tabInbox").style.width = glblUtil.getWidth();
//				document.getElementById("tbInboxLoandex").style.width = glblUtil.getWidth();
//				document.getElementById("userActionContent").style.display = "none";
//				document.getElementById("userActionHeader").style.color = "#3d6392";
//				document.getElementById("workflowContent1").style.display = "none";
//				document.getElementById("workflowContent2").style.display = "none";
//				dijit.byId('cmdSaveDC').set('disabled',true);
			}
		}
	});

	
		
});

var inbox = {
		onLoadEvent:function(){
			
		},
		inboxTable:function(wfData){
			var layout = [{ field: "no", width: '2px', name: "No",styles: 'text-align: center;' },
								{ field: "requestNo", width: '9%', name: "Request No", styles: 'cursor: pointer; text-align: center;',cellStyles: 'text-decoration: underline; color: blue;' },
								{ field: "requestingOfficer", width: '13%', name: "Requesting Officer",styles:'text-align:center;',cellStyles:'text-align:center;'},
								{ field: "NameVerified", width: '17%', name: "Customer Name",styles:'text-align:center;',cellStyles:'text-align:center;'},
								{ field: "taggedStatus", width: '17%', name: "Status",styles:'text-align:center;',cellStyles:'text-align:center;'},
								{ field: "requestDate", width: '9%', name: "Request Date",styles:'text-align:center;',cellStyles:'text-align:center;'},
								{ field: "dateReceived", width: '9%', name: "Date Received",styles:'text-align:center;',cellStyles:'text-align:center;'},
								{ field: "history", width: '7%', name: "History",styles:'text-align:center;cursor:pointer;',
									formatter:cmdHistory},
								{ field: "age", width: '2px', name: "Age",styles: 'text-align: center;',styles: 'text-align: center;'}];
			
			if(dijit.byId("gridInbox") == null || gridInbox == undefined || gridInbox =="") {
				glblUtil.createDataGrid("gridInbox","divInboxGrid", layout, null);
				glblUtil.getInbox("gridInbox",glblRqstType,wfData.subWorkflowCode,globalUserId,"","","","","","","","","","",PageLimit,PageNum,0);
				grid = dijit.byId("gridInbox");
				inbox.setPaginationObject("gridInbox");
			}
			grid = dijit.byId("gridInbox");
			grid.set("singleClickEdit",true);
			
			dojo.connect( window, "onresize", function(){
				grid.attr("width", '100%');
				grid.resize();
				grid.update();
			});
			
			grid.set("canSort",function(){
				try{
					return false;
				}catch(e){
					
				}
			});
			grid.set("noResize",true);
			this.GridcellClick();
		},
		GridcellClick:function(){
			grid.on("CellClick", function(evt){
				var row = evt.rowIndex;
				var ttl = grid.rowCount;
				var index = grid.selection.selectedIndex;
				var item = grid.getItem(index);
				var data = [];
				data["strCustomerName"] = item.NameVerified.toString();
				data["strPageId"] = item.pageId.toString();
				data["strRequestNo"] = item.requestNo.toString();
				data["strROName"] = item.requestingOfficer.toString();
				data["strROUnit"] = item.requestingUnit.toString();
				data["strSpecialInstruction"] = item.specialInstruction.toString();
				data["DocumentDate"] = item.documentDate.toString();
				data["stepCode"] = item.stepCode.toString();
				data["UserName"] = globalUserId;
				data["SolutionPrefix"] = solutionPrefix;
				data["subWorkflowCode"] = strSubWorkflow;
				data["instructionId"] = strInstructionId;
				data["mainPageId"] = strMainPageId;
				
				
				var strCustomerName = item.NameVerified.toString();
				var strRequestNo = item.requestNo.toString();
				var strWorkflowNo = item.wfTrackNo.toString();
//				var strRequestingUnit = item.taggedStatus.toString();
//				var strDateRecieve = item.dateReceived.toString();
				var namesInfo = [];
				namesInfo["strCustomerName"] =  item.NameVerified.toString();
				namesInfo["strRequestNo"] = item.requestNo.toString();
				namesInfo["strWorkflowNo"] = item.wfTrackNo.toString();
				namesInfo["strRequestingUnit"] = item.taggedStatus.toString();;
				namesInfo["strDateRecieve"] = item.dateReceived.toString();
				namesInfo["UserName"] = globalUserId;
				
				if(evt.cellIndex == 1){
					if(item.stepCode.toString()=="CDMS_01_2310_05" || item.stepCode.toString()=="CDMS_01_2320_05"){
						glblVariousSEC.VariousSECPopUp(data);
					}else{
						var strPageId = item.pageId.toString();
						glblUtil.OpenWorkItemPage(thisMainObj,solutionPrefix,strPageId,data);
						dijit.byId("gridInbox").destroyRecursive();
						globalICMUtil.closePage(thisMainObj);
						glblUtil.setCIMInternalLogSaveComp(globalUserId, strWorkflowNo, 2, strStepCode, 
								"", "", strRequestNo, "", "",strCustomerName,function(isLogged){});
					}
				}
				else if(evt.cellIndex == 7){
					glblViewNamesVerifiedTaskHistory.ViewHistoryPopUpSECDTI("ViewHistory",namesInfo,strRequestNo);
				}
			});
			
		},
		getInboxDetails:function(gridId){
			InboxData = [];
			var requestParams = {};	
			requestParams.userShortName  = ""; 
			requestParams.requestNo  = "";
			requestParams.requestingOfficer  = "";
			requestParams.requestingUnit  = "";
			requestParams.customerName  = "";
			requestParams.status  = "";
			requestParams.requestDateStart  = "";
			requestParams.requestDateEnd  = "";
			requestParams.receivedDateStart  = "";
			requestParams.receivedDateEnd  = "";
			requestParams.WfTrackNo  = "";
			requestParams.pageLimit  = 0;
			requestParams.pageNum  = 0;
			requestParams.isFiltered  = 0;
			requestParams.callingFunction = "getMyInboxDetails";
			globalECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "MyInboxService", {
				requestParams: requestParams,
				backgroundRequest: false,
				requestCompleteCallback:globalLang.hitch (this,function(response) {
					var InboxLst =  response.inboxLst;
					for(var i = 0 ; InboxLst.length > i ; i++){
						var strWfTrackNo = InboxLst[i].WfTrackNo;
						var strRequestNo = InboxLst[i].RequestNo;
						var strCustCIFId = InboxLst[i].CustCIFId;
						var strCustomerName = InboxLst[i].CustomerName;
						var strRequestingOfficer = InboxLst[i].RequestingOfficer;
						var strRequestingOfficerId = InboxLst[i].RequestingOfficerId;
						var strRequestDate = InboxLst[i].RequestDate;
						var strLaunchDate = InboxLst[i].LaunchDate;
						var strStatus = InboxLst[i].Status;
						//alert(" strWfTrackNo: "+strWfTrackNo+" strRequestNo: "+strRequestNo+" strCustCIFId: "+strCustCIFId+" strCustomerName: "+strCustomerName+" strRequestingOfficer: "+strRequestingOfficer+" strRequestingOfficerId: "+strRequestingOfficerId+" strRequestDate: "+strRequestDate+" strLaunchDate: "+strLaunchDate+" strStatus: "+strStatus);
						InboxStore.newItem({no:i+1,requestNo:strRequestNo,requestingOfficer:strRequestingOfficer,customerName:strCustomerName,status:strStatus,requestDate:strRequestDate,dateReceived:strLaunchDate,history:"",age:""});
					}
					InboxStore.save();
				})
			});
		},
		setPaginationObject:function(strGridId){
			dojo.connect(dojo.byId("resultSize"),'onchange',function(){
				rs = dojo.byId("resultSize").value;
				if(rs!=""){
					dojo.byId("currentPage").value = 1;
					var strWorkflowNo  = dijit.byId("textWorkflowNo").get('value') ;
					var strRequestNo  = dijit.byId("textRqstNo").get('value') ;
					var strCustomerName  = dijit.byId("textCustName").get('value');
					var strRequestingOfficer  = dijit.byId("textRqstOfficer").get('value') ;
					var strRequestingUnit  = dijit.byId("textRqstUnit").get('value');
					var strRequestDateStart = glblUtil.formatDate(dijit.byId("txtDateReqFrm").get('value'));
					var strRequestDateEnd = glblUtil.formatDate(dijit.byId("txtDateReqTo").get('value'));
					var strReceivedDateStart = glblUtil.formatDate(dijit.byId("txtDateRecvReqFrm").get('value'));
					var strReceivedDateEnd = glblUtil.formatDate(dijit.byId("txtDateRecvReqTo").get('value'));
					var strPageLimit = dojo.byId('resultSize').value;
					var strPageNum = Number(dojo.byId('currentPage').value);
					glblUtil.getInbox(strGridId,"",strSubWorkflow,globalUserId,strRequestNo,
			    			strRequestingOfficer,strRequestingUnit,strCustomerName,"",
			    			strRequestDateStart,strRequestDateEnd,strReceivedDateStart,strReceivedDateEnd,
			    			strWorkflowNo,strPageLimit,strPageNum,1);
				}
			});
			
			dojo.connect(dojo.byId("nextPage"),'onclick',function(){
				var rs = dojo.byId("resultSize").value;
				var currentPage = Number(dojo.byId("currentPage").value);
				var totalPage 	= dojo.byId("totalPages").innerHTML;

				if (currentPage <= totalPage && currentPage < totalPage){
					currentPage += 1;
					dojo.byId("currentPage").value = currentPage;
					var strWorkflowNo  = dijit.byId("textWorkflowNo").get('value') ;
					var strRequestNo  = dijit.byId("textRqstNo").get('value') ;
					var strCustomerName  = dijit.byId("textCustName").get('value');
					var strRequestingOfficer  = dijit.byId("textRqstOfficer").get('value') ;
					var strRequestingUnit  = dijit.byId("textRqstUnit").get('value');
					var strRequestDateStart = glblUtil.formatDate(dijit.byId("txtDateReqFrm").get('value'));
					var strRequestDateEnd = glblUtil.formatDate(dijit.byId("txtDateReqTo").get('value'));
					var strReceivedDateStart = glblUtil.formatDate(dijit.byId("txtDateRecvReqFrm").get('value'));
					var strReceivedDateEnd = glblUtil.formatDate(dijit.byId("txtDateRecvReqTo").get('value'));
					var strPageLimit = dojo.byId('resultSize').value;
					var strPageNum = Number(dojo.byId('currentPage').value);
					glblUtil.getInbox(strGridId,"",strSubWorkflow,globalUserId,strRequestNo,
			    			strRequestingOfficer,strRequestingUnit,strCustomerName,"",
			    			strRequestDateStart,strRequestDateEnd,strReceivedDateStart,strReceivedDateEnd,
			    			strWorkflowNo,strPageLimit,strPageNum,1);
				}
			});
			
			dojo.connect(dojo.byId("prevPage"),'onclick',function(){
				var rs = dojo.byId("resultSize").value;
				var currentPage = Number(dojo.byId("currentPage").value);
				var totalPage 	= dojo.byId("totalPages").innerHTML;

				if (currentPage <= totalPage && currentPage != 1){
					currentPage -= 1;
					dojo.byId("currentPage").value = currentPage;
					var strWorkflowNo  = dijit.byId("textWorkflowNo").get('value') ;
					var strRequestNo  = dijit.byId("textRqstNo").get('value') ;
					var strCustomerName  = dijit.byId("textCustName").get('value');
					var strRequestingOfficer  = dijit.byId("textRqstOfficer").get('value') ;
					var strRequestingUnit  = dijit.byId("textRqstUnit").get('value');
					var strRequestDateStart = glblUtil.formatDate(dijit.byId("txtDateReqFrm").get('value'));
					var strRequestDateEnd = glblUtil.formatDate(dijit.byId("txtDateReqTo").get('value'));
					var strReceivedDateStart = glblUtil.formatDate(dijit.byId("txtDateRecvReqFrm").get('value'));
					var strReceivedDateEnd = glblUtil.formatDate(dijit.byId("txtDateRecvReqTo").get('value'));
					var strPageLimit = dojo.byId('resultSize').value;
					var strPageNum = Number(dojo.byId('currentPage').value);
					glblUtil.getInbox(strGridId,"",strSubWorkflow,globalUserId,strRequestNo,
			    			strRequestingOfficer,strRequestingUnit,strCustomerName,"",
			    			strRequestDateStart,strRequestDateEnd,strReceivedDateStart,strReceivedDateEnd,
			    			strWorkflowNo,strPageLimit,strPageNum,1);
				}
			});
			
			dojo.connect(dojo.byId("gotoPage"),'onclick',function(){
				var rs = dojo.byId("resultSize").value;
				var currentPage = Number(dojo.byId("currentPage").value);
				if(currentPage != ""){
					var strWorkflowNo  = dijit.byId("textWorkflowNo").get('value') ;
					var strRequestNo  = dijit.byId("textRqstNo").get('value') ;
					var strCustomerName  = dijit.byId("textCustName").get('value');
					var strRequestingOfficer  = dijit.byId("textRqstOfficer").get('value') ;
					var strRequestingUnit  = dijit.byId("textRqstUnit").get('value');
					var strRequestDateStart = glblUtil.formatDate(dijit.byId("txtDateReqFrm").get('value'));
					var strRequestDateEnd = glblUtil.formatDate(dijit.byId("txtDateReqTo").get('value'));
					var strReceivedDateStart = glblUtil.formatDate(dijit.byId("txtDateRecvReqFrm").get('value'));
					var strReceivedDateEnd = glblUtil.formatDate(dijit.byId("txtDateRecvReqTo").get('value'));
					var strPageLimit = dojo.byId('resultSize').value;
					var strPageNum = Number(dojo.byId('currentPage').value);
					glblUtil.getInbox(strGridId,"",strSubWorkflow,globalUserId,strRequestNo,
			    			strRequestingOfficer,strRequestingUnit,strCustomerName,"",
			    			strRequestDateStart,strRequestDateEnd,strReceivedDateStart,strReceivedDateEnd,
			    			strWorkflowNo,strPageLimit,strPageNum,1);
				}else{
	        		dijit.byId("currentPage").set('value',1);
				}
			}); 
		}
};






