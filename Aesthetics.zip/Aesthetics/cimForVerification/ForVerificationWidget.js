var globalUtil;
var snode="";
var glblQuery;
var glblDDMenu;
var glblPageNavi;
var glblWorkFlowId;
var myFormListGrid;
var workFlowStore;
var workFlow = [];
var iData= {};
var txtCusName;
var txtWrkFlwNo;
var txtWrkFlwNoVal;
var txtCusNameVal;
var strStepId;
var PageLimit = 50;
var PageNum = 1;
var grid;
var grid2;
var grid3;
var glblViewRequestDetails;
var globalECMRequest;
var glblNamesInquired;
var globalRow1;
var strIsFiltered = 0;
var glblRqstType = "NFIS";//from user mapping
var glblUserShortName = "";//from user mapping
var cancelRqst = "<div class='cancelRqstIcon'></div>";
var cancelRqstIcon = function(val) {
	var rt = "";
	if(val!=""){
		rt = cancelRqst;
	}else{
		rt = "";
	}
	return rt;
};
var rqstNoMerge = function(val){

	return val; 
};
var completeLevel = 0;
var rs = 50;
var strScreenCode = "0";
var strInstructionId="";
var strStepCode="";
var glblIndex;
var glblTabId="tabForVerification";

var cmdHistory = function(){
	 var cmdHist = new dijit.form.Button({ 
       label: 'View',
       style: '',
       iconClass: "viewIcon"
	 });
	
	return cmdHist;
};

var findNamesVerified = "<div class='findNamesVerifiedIcon'></div>";
var findIcon = function(val) {findNamesVerified;return findNamesVerified;};

var addressNV = "<div class='addressIcon'></div>";
var addressIcon = function(val) {addressNV;return addressNV;};

var workflowTypeStore = [];
var icmContextRoot = "/CDMS_MyWorkplaceWidgets";
var paths = {
		"cdmsPluginCustomWidget": icmContextRoot + "/cdmsPluginCustomWidget"
};

var wfDetailsPayload = {};
var solutionPrefix = "";
var reqPayload = {};
var propPayload = {};
var thisMainObj;
var solution; 
var repositoryId; 
var glblCoordination;
var tooltip = "<span id='divTooltip' class='tooltiptext'></span>";
var getTooltip = function(val) {tooltip;return tooltip;};

var dataForVeri = [];
var storeForVeri;
var glblUtil;
var glblDom;
var glblTabContainer;
var glblContentPane;
var glblBorderContainer;
var glblICMUtil;
var glblDataGrid;
var glblall;
var glblLang;
var glblECMRequest;
var glblAttr;
var glblItemFileWriteStore;
var storeAction;
var actionTakenData = [];
var glblDom;
var glblLookup;
var globalUserId;
var gridId = "ForVeriGrid";
var gridNFISProcess;
var gridNFISCutOff;
var ForVeriGrid;
var tabReturn=0;
var glblRemarks;
var solutionPrefix;
var globalPayload;
var glblCNode;
define([
        "dojo/_base/declare",
        "dojo/json",
        "icm/base/BasePageWidget",
        "icm/base/_BaseWidget",
        "dojo/on",
        "dojo/query",
        "cdmsPluginCustomWidget/util/DropDownMenu",
        "cdmsPluginCustomWidget/util/pagenavigation",
        "dijit/form/ComboBox",
        "cdmsPluginCustomWidget/util/ICMUtil",
        "icm/base/Constants",
        "dojo/_base/lang",
        "dojo/text!./templates/ForVerificationWidget.html",
        "dijit/form/Button",
        "dijit/_WidgetsInTemplateMixin",
        "ecm/LoggerMixin",
        "dojo/Deferred","dojo/promise/all",
        "icm/util/Coordination",
        "cdmsPluginCustomWidget/util/Util",
        "icm/model/CaseEditable",
        "ecm/model/Request",
        "dojo/_base/lang",
        "cdmsPluginCustomWidget/lookup/WFSearch",
        "dojo/data/ItemFileWriteStore",
        "icm/model/Case",
        "dojo/keys",
        "dijit/Tooltip",
        "dojo/dom",
        "cdmsPluginCustomWidget/util/Lookup",
        "cdmsPluginCustomWidget/lookup/ViewRequestDetails",
        "cdmsPluginCustomWidget/lookup/ExistingNamesInquired",
        "cdmsPluginCustomWidget/lookup/Remarks"
        ], function(declare, json, BasePageWidget, _BaseWidget, onObj, query, DropDownMenu, 
        			pagenavigation, ComboBox, ICMUtil, Constants, lang, template, ButtonObj, 
        			_WidgetsInTemplateMixin, LoggerMixin, Deferred, all, Coordination, Util, CaseEditable,
        			ecmReq,lang,WFSearch, ItemFileWriteStore,Case,keys,Tooltip,dom,Lookup,ViewRequestDetails,
        			ExistingNamesInquired,Remarks){
	
		glblUtil = Util;
		glblICMUtil = ICMUtil;
		glblall = all;
		glblLang = lang;
		glblECMRequest = ecmReq;
		glblItemFileWriteStore = ItemFileWriteStore;
		glblTooltip = Tooltip;
		glblDom =dom;
		glblLookup = Lookup;
		glblViewRequestDetails = ViewRequestDetails;
		glblNamesInquired=ExistingNamesInquired;
		glblRemarks=Remarks;
		
		
	return declare("cdmsPluginCustomWidget.cimForVerification.ForVerificationWidget", [_BaseWidget, BasePageWidget], {
		templateString: template,
		
		
		postCreate: function(){
			globalUserId = ecm.model.desktop.userId;
			solutionPrefix = this.solution.getPrefix();
//			var currentPage = "currentPage"+gridId;
//			onObj(this.currentPageForVeriGrid, "keypress", function(evt){
//				var currentPage = Number(dojo.byId("currentPage"+glblTabId).value);
//				 switch(evt.keyCode) {
//		            case keys.ENTER:
//		              if(currentPage != ""){
//		            	  	glblUtil.getSearchFieldsForVeri(glblTabId,function(data){
//								var strRequestNo = data.strRequestNo;
//								var strNameVerified = data.strNameVerified;
//								var strRqstDateFrm = data.strRqstDateFrm;
//								var strRqstDateTo = data.strRqstDateTo;
//								var strRptDateFrm = data.strRptDateFrm;
//								var strRptDateTo = data.strRptDateTo;
//								var strSuggestedStatus = data.strSuggestedStatus;
//								var strResultSize = data.strResultSize;
//								var strCurrentPage = data.strCurrentPage;
//								glblUtil.getForLoandexProcessing(gridId,glblRqstType,"","",strRequestNo,
//										"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
//										strSuggestedStatus,strResultSize,strCurrentPage,1);
//							});
//		              }else{
//			        		dijit.byId("currentPage"+glblTabId).set('value',1);
//		              }
//		                break;
//		            default:
//		           
//		        }
//			});
			
		dojo.connect(dijit.byId("tbLoandex"),'selectChild',function(page){
			if(page.id.toString() == "tabForVerification"){
				glblTabId=page.id.toString();
				gridId = "ForVeriGrid";
				strStepCode = "CDMS_01_2100_01";
				dijit.byId('txtStepCode').set('value',strStepCode);
			}else if(page.id.toString() == "tabReturntoProcessor"){
				glblTabId=page.id.toString();
				strStepCode = "CDMS_01_2100_03";
				dijit.byId('txtStepCode').set('value',strStepCode);
				gridId = "ReturntoProcessorGrid";
				if(tabReturn==0){
					tabReturn=1;
					forVerification.getActionTaken(strStepCode,function(store){
						forVerification.returnToProcessorGrid(store);
					});
				}
			}else if(page.id.toString() == "tabAfterCutOff"){
				forVerification.AfterCutOffGrid(page.id.toString());
				dijit.byId('txtTabId').set('value',page.id.toString());
			}
			
		});
		
		},
		handleICM_PageOpenedEvent: function(payload) {
//			iData.wfNo=dijit.byId("txtWrkFlwNo").get('value');
//			iData["wfNo"]=dijit.byId("txtWorkflowNo").get('value');
			globalPayload = payload;
//			if(payload.wfNo != undefined){
			if(payload.wfData != undefined){
				var wfData = payload.wfData;
				if(wfData.stepCode!=undefined){
					strStepCode = wfData.stepCode;
					if(strStepCode=="CDMS_01_2100_01"){
						glblRqstType = "LOANDEX";
						forVerification.getActionTaken(strStepCode,function(store){
							forVerification.LoandexForVerificationGrid(store);
						});
					}else if(strStepCode=="CDMS_01_2200_01"){
						glblRqstType = "NFIS";
						if(dijit.byId("tbLoandex")!=undefined){
							dijit.byId("tbLoandex").removeChild(dijit.byId("tabReturntoProcessor"));
							dijit.byId("tabReturntoProcessor").destroyRecursive(true);
						}
						forVerification.getActionTaken(strStepCode,function(store){
							forVerification.NFISForVerificationGrid(store);
						});
						
					}
				}
				dijit.byId('txtStepCode').set('value',strStepCode);
				dijit.byId('txtRequestType').set('value',glblRqstType);
				dijit.byId('txtTabId').set('value',glblTabId);
				document.getElementById("userActionContent").style.display = "none";
				document.getElementById("userActionHeader").style.color = "#3d6392";
				document.getElementById("workflowContent1").style.display = "none";
			}
			
		},
		handleICM_SendWorkItemEvent: function(payload) {
			
		}
		
	});
	
});

var forVerification = {
		LoandexForVerificationGrid : function(store){
			storeAction=store;
			var layout = [{ field: "no", width: '15px', name: "No",styles: 'text-align: center;' },
			              { field: "requestNo", width: '90px', name: "Request No",styles: 'cursor: pointer; text-align: center;',
						cellStyles: 'text-decoration: underline; color: blue;',formatter:rqstNoMerge},
						{ field: "btnCancel",width: '15px',name: '&nbsp;',styles:'align:center;',formatter:cancelRqstIcon},
						{ field: "NameVerified", width: 'auto',cellStyles:'text-align: left;', name: "Name Verified",styles: 'text-align: center;'},
						{ field: "btnSearch",width: '15px',name: '&nbsp;',styles:'align:center;',formatter:findIcon},
						{ field: "Address", width: '100px', name: "Address",styles: 'text-align: center;',
						cellStyles: 'text-align: left;text-decoration: underline; color: blue;'},
						{ field: "lastReportDate", width: '100px', name: "Last Report Date",styles: 'text-align: center;'},
						{ field: "lastRequestDate", width: '100px', name: "Last Request Date",styles: 'text-align: center;'},
						{ field: "suggestedStatus", width: '100px', name: "Suggested Status",styles: 'text-align: center;cursor: pointer; text-align: center;',
						cellStyles: 'text-decoration: underline; color: blue;'},
						{ field: "taggedStatus", name: "Action Taken",editable:true,width: '120px'
							,cellType: dojox.grid.cells._Widget,widgetClass: dijit.form.ComboBox,
							widgetProps: {searchAttr:'strActionName', store: storeAction,intermediateChanges:true,
								onKeyPress:glblUtil.disableKeyPress
								,onChange:forVerification.OnChangeTag
							},
							formatter:function(data, inRow){
								return data;
							},
							styles: 'text-align: center;'
						},
						{ field: "remarksToProcessor", width: '250px', name: "Remarks",styles: 'text-align: center;', editable:true}];
			if(dijit.byId("ForVeriGrid") == null || grid == undefined || grid =="") {
				glblUtil.createDataGrid("ForVeriGrid","divForVerificationGrid", layout, null);
				glblUtil.getForLoandexProcessing(glblTabId,"ForVeriGrid",glblRqstType,strStepCode,globalUserId,"","","","","","","","","",PageLimit,PageNum,strIsFiltered);
				grid = dijit.byId("ForVeriGrid");
				forVerification.setPaginationObject(glblTabId,"ForVeriGrid");
			}
			grid.set("singleClickEdit",true);
			//TODO
			grid.update();
			grid._refresh();
			dojo.connect( window, "onresize", function(){
				grid.attr("width", '100%');
				grid.resize();
				grid.update();
			});
			
			grid.set("canSort",function(){
				try{
					return false;
				}catch(e){
					
				}
			});
			dojo.connect(grid,'onCellFocus',function(a,row){
				globalRow1 = row;
			});
			grid.update();
			grid._refresh();
			forVerification.forVerificationCellClick(grid,strStepCode);
			forVerification.tooltip(grid);
		},
		returnToProcessorGrid : function(storeAction){
			var layout = [{ field: "no", width: '15px', name: "No",styles: 'text-align: center;' },
							{ field: "requestNo", width: '90px', name: "Request No",styles: 'cursor: pointer; text-align: center;',
							cellStyles: 'text-decoration: underline; color: blue;',formatter:rqstNoMerge},
							{ field: "btnCancel",width: '15px',name: '&nbsp;',styles:'align:center;',formatter:cancelRqstIcon},
							{ field: "NameVerified", width: 'auto',cellStyles:'text-align: left;', name: "Name Verified",styles: 'text-align: center;'},
							{ field: "btnSearch",width: '15px',name: '&nbsp;',styles:'align:center;',formatter:findIcon},
							{ field: "Address", width: '100px', name: "Address",styles: 'text-align: center;',
								cellStyles: 'text-align: left;text-decoration: underline; color: blue;cursor:pointer'},
							{ field: "lastReportDate", width: '100px', name: "Last Report Date",styles: 'text-align: center;'},
							{ field: "lastRequestDate", width: '100px', name: "Last Request Date",styles: 'text-align: center;'},
							{ field: "suggestedStatus", width: '100px', name: "Suggested Status",styles: 'text-align: center;cursor: pointer;text-align: center;',
								cellStyles: 'text-decoration: underline; color: blue;'},
							{ field: "taggedStatus", name: "Action Taken",editable:true,width: '120px'
				            	   ,cellType: dojox.grid.cells._Widget,widgetClass: dijit.form.ComboBox,
				            		widgetProps: {searchAttr:'strActionName', store: storeAction,intermediateChanges:true,
				            				onKeyPress:glblUtil.disableKeyPress
				            				,onChange:forVerification.OnChangeTag
				            		},
				            		formatter:function(data, inRow){
				     					return data;
				     			    },
				     			  styles: 'text-align: center;'
				               },
							{ field: "remarksToProcessor", width: '250px', name: "Remarks",styles: 'text-align: center;', editable:true}];
				if(dijit.byId("ReturntoProcessorGrid") == null || grid2 == undefined || grid2 =="") {
					glblUtil.createDataGrid("ReturntoProcessorGrid","divReturntoProcessorGrid", layout, null);
					glblUtil.getForLoandexProcessing(glblTabId,gridId,glblRqstType,strStepCode,globalUserId,"","","","","","","","","",rs,PageNum,strIsFiltered);
					grid = dijit.byId("ReturntoProcessorGrid");
					forVerification.setPaginationObject(glblTabId,"ReturntoProcessorGrid");
				}
				dojo.connect(grid,'onCellFocus',function(a,row){
					globalRow1 = row;
				});
				grid.update();
				grid._refresh();
				grid.set("singleClickEdit",true);
				dojo.connect( window, "onresize", function(){
					//console.log("Resize");
					grid.attr("width", '100%');
					grid.resize();
					grid.update();
				});
				grid.set("canSort",function(){
					try{
						return false;
					}catch(e){
						
					}
				});
				forVerification.returnedCellClick(grid);
				forVerification.tooltip(grid);
		},
		AfterCutOffGrid: function(strTabId){
			var layout = [{field: "no", width: '15px', name: "No",styles: 'text-align: center;'},
				{ field: "requestNo", width: '90px', name: "Request No",styles: 'text-align: center;'},
				{ field: "NameVerified", width: 'auto', name: "Name Verified",styles: 'text-align: center;'},
				{ field: "Address", width: '350px', name: "Address",styles: 'text-align: center;'},
				{ field: "lastReportDate", width: '130px', name: "Last Report Date",styles: 'text-align: center;'},
				{ field: "lastRequestDate", width: '130px', name: "Last Request Date",styles: 'text-align: center;'},
				{ field: "suggestedStatus", width: '130px', name: "Suggested Status",styles: 'text-align: center;cursor: pointer;text-align: center;'},
			];
			if(dijit.byId("AfterCutOffGrid") == null || grid == undefined || grid =="") {
				glblUtil.createDataGrid("AfterCutOffGrid","divAfterCutOffGrid", layout, null);
				glblUtil.getCutOff(strTabId,"AfterCutOffGrid",strStepCode,globalUserId,"","","","","","","","","","",1,50,0);
				grid = dijit.byId("AfterCutOffGrid");
				forVerification.setPaginationObject(strTabId,"AfterCutOffGrid");
			}	
			grid.update();
			grid._refresh();
			dojo.connect( window, "onresize", function(){
				//console.log("Resize");
				grid.attr("width", '100%');
				grid.resize();
				grid.update();
			});

		},
		NFISForVerificationGrid : function(store){
			storeAction=store;
			var layout = [{ field: "no", width: '15px', name: "No",styles: 'text-align: center;' },
				{ field: "requestNo", width: '90px', name: "Request No",styles: 'cursor: pointer; text-align: center;',
				cellStyles: 'text-decoration: underline; color: blue;'},
				{ field: "btnCancel",width: '15px',name: '&nbsp;',styles:'align:center;',formatter:cancelRqstIcon},
				{ field: "NameVerified", width: 'auto',cellStyles:'text-align: left;', name: "Name Verified",styles: 'text-align: center;'},
				{ field: "btnSearch",width: '15px',name: '&nbsp;',styles:'align:center;',formatter:findIcon},
				{ field: "Address", width: '100px', name: "Address",styles: 'text-align: center;',
					cellStyles: 'text-align: left;text-decoration: underline; color: blue;'},
				{ field: "lastReportDate", width: '100px', name: "Last Report Date",styles: 'text-align: center;'},
				{ field: "lastRequestDate", width: '100px', name: "Last Request Date",styles: 'text-align: center;'},
				{ field: "suggestedStatus", width: '100px', name: "Suggested Status",styles: 'text-align: center;cursor: pointer;text-align: center;',
					cellStyles: 'text-decoration: underline; color: blue;'},
				{ field: "taggedStatus", name: "Action Taken",editable:true,width: '120px'
	            	   ,cellType: dojox.grid.cells._Widget,widgetClass: dijit.form.ComboBox,
	            		widgetProps: {searchAttr:'strActionName', store: storeAction,intermediateChanges:true,
	            				onKeyPress:glblUtil.disableKeyPress
	            				,onChange:forVerification.OnChangeTag
	            		},
	            		formatter:function(data, inRow){
	     					return data;
	     			    },
	     			  styles: 'text-align: center;'
	               },
	            { field: "requestType", width: '120px', name: "Request Type",styles: 'text-align: center;'},
				{ field: "remarksToProcessor", width: '250px', name: "Remarks",styles: 'text-align: center;', editable:true}];
			
			if(dijit.byId("gridNFISProcess") == null || grid == undefined || grid =="") {
				glblUtil.createDataGrid("gridNFISProcess","divForVerificationGrid", layout, null);
				glblUtil.getForLoandexProcessing(glblTabId,"gridNFISProcess",glblRqstType,strStepCode,globalUserId,"","","","","","","","","",PageLimit,PageNum,strIsFiltered);
				grid = dijit.byId("gridNFISProcess");
				forVerification.setPaginationObject(glblTabId,"gridNFISProcess");
			}
			
			grid.set("singleClickEdit",true);
			grid.set("canSort",false);
			grid.update();
			grid._refresh();
			dojo.connect( window, "onresize", function(){
				//console.log("Resize");
				grid.attr("width", '100%');
				grid.resize();
				grid.update();
			});
			dojo.connect(grid,'onCellFocus',function(a,row){
				globalRow1 = row;
			});
			forVerification.forVerificationCellClick(grid,strStepCode);
			forVerification.tooltip(grid);
		},
		getActionTaken:function(strStepCode,callback){
    		var requestParams = {};
    		requestParams.StepCode = strStepCode;
    		requestParams.callingFunction = "getActionTaken";
    		glblECMRequest.invokePluginService("CDMSCustomWidgetsPlugin", "CDMSService",{
    				requestParams: requestParams,
    				backgroundRequest: false,
    				requestCompleteCallback:glblLang.hitch (this,function(response) {
    					var rs =  response.list;
    					if(rs != null || rs !=""){
    						actionTakenData = [];
    						for(var i in rs){
    							actionTakenData.push({strActionId:rs[i].StepId.toString(),strActionName:rs[i].ActionTake.toString(),strNextStepCode:rs[i].NextStepCode});
        					}
    						storeAction = new glblItemFileWriteStore({data:{
    							items:actionTakenData
    						}});
    						callback(storeAction);
    					}
    					
    				})
    			});	
				
		},
		forVerificationCellClick:function(grid,strStepCode){
			grid.on("CellClick", function(evt){
				var userid = globalUserId;
				var row = evt.rowIndex;
				var ttl = grid.rowCount;
				var index = grid.selection.selectedIndex;
				var item = grid.getItem(index);
				var namesInfo = [];
				if(evt.cellIndex == 1){
					var strRequestNo = grid.store.getValue(item,'requestNo');
					if(strRequestNo!=""){
						namesInfo["strRequestNo"]=item.requestNo;
						namesInfo["strNameVerified"]=item.NameVerified;
						namesInfo["strRqstStats"]=item.RqstStats;
						namesInfo["strRqstOfficerName"]=item.requestingOfficer;
						namesInfo["strDateRcvd"]=item.dateReceived;
						namesInfo["strWFTrackNo"]=item.wfNo;
						var strWfNo = item.wfNo;
						var strRequestNo = item.requestNo;
						var strNameVerified = item.NameVerified;
						var strRqstStats = item.RqstStats;
						var strRqstOfficerName = item.requestingOfficer;
						var strDateRcvd = item.dateReceived;
						alert("strRequestNo >>"+strRequestNo);
						
						glblViewRequestDetails.RequestDetailsPopUp(namesInfo,strRequestNo,userid,strNameVerified,strRqstStats,strRqstOfficerName,strDateRcvd);
					}
				}else if(evt.cellIndex == 2){
					var strRequestNo = grid.store.getValue(item,'requestNo');
					if(strRequestNo!=""){
						glblRemarks.remarksPopUp(function(remarks){
							if(remarks!=false){
								grid.store.fetch({
									onComplete:function(items){
										for(var x = 0; items.length > x ;x++){
											if(strRequestNo==grid.store.getValue(items[x],'requestNo')){
												var strWobNum = items[x].objectId.toString();
												glblUtil.setCancelRequest(strWobNum,remarks,strStepCode,"Cancel Name",globalUserId,solutionPrefix,function(isSaved){
													if(isSaved!=true){
														alert("error in cancellation.");
													}
												});
												grid.store.deleteItem(items[x]);
												grid.store.save();
											}
										}
										dojo.byId("totalRecords").innerHTML = document.getElementById('totalRecords').innerHTML-items.length;
									}
								});
							}
						});
					}
				}else if(evt.cellIndex == 4){
					glblNamesInquired.ExistingNamesInquiredPopUp(item.objectId,item.bapId,item.NameVerified,item.fullAddress,grid,strScreenCode);
				}else if(evt.cellIndex == 5){
					console.log("dijit__MasterTooltip_0");
					document.getElementById("dijit__MasterTooltip_0").style.display = "none";
					glblUtil.getAddressAlert(item.fullAddress.toString());
				}else if(evt.cellIndex == 8){
					var strSuggestedVSID = item.suggestedVSID.toString();
					if(strSuggestedVSID!=""){
						glblUtil.onViewDocumentsXT(strSuggestedVSID,"","");
					}
				}
			});
		},
		returnedCellClick:function(grid){
			grid.on("CellClick", function(evt){
				var row = evt.rowIndex;
				var ttl = grid.rowCount;
				var index = grid.selection.selectedIndex;
				var item = grid.getItem(index);
				var namesInfo = [];
				if(evt.cellIndex == 1){
					var strRequestNo = grid.store.getValue(item,'requestNo');
					if(strRequestNo!=""){
						namesInfo["strRequestNo"]=item.requestNo;
						namesInfo["strNameVerified"]=item.NameVerified;
						namesInfo["strRqstStats"]=item.RqstStats;
						namesInfo["strRqstOfficerName"]=item.requestingOfficer;
						namesInfo["strDateRcvd"]=item.dateReceived;
						
						var strRequestNo = item.requestNo;
						var strNameVeri = item.NameVerified;
						var strReqStats = RqstStats;
						var strReqOfficer = item.requestingOfficer;
						var strdateRecieved = item.dateReceived;
						glblViewRequestDetails.RequestDetailsPopUp(namesInfo,strRequestNo,strNameVeri,strReqStats,strReqOfficer,strdateRecieved);
					}
				}else if(evt.cellIndex == 2){
					var strRequestNo = grid.store.getValue(item,'requestNo');
					if(strRequestNo!=""){
						glblRemarks.remarksPopUp(function(remarks){
							if(remarks!=false){
								var strRequestNo = grid.store.getValue(item,'requestNo');
								grid.store.fetch({
									onComplete:function(items){
										for(var x = 0; items.length > x ;x++){
											if(strRequestNo==grid.store.getValue(items[x],'requestNo')){
												var strWobNum = items[x].objectId.toString();
												glblUtil.setCancelRequest(strWobNum,remarks,strStepCode,"Cancel Name",globalUserId,solutionPrefix,function(isSaved){
													if(isSaved!=true){
														alert("error in cancellation.");
													}
												});
												grid.store.deleteItem(items[x]);
												grid.store.save();
											}
											dojo.byId("totalRecords2").innerHTML = document.getElementById('totalRecords2').innerHTML-items.length;
										}
									}
								});
							}
						});
					}
				}else if(evt.cellIndex == 4){
					glblNamesInquired.ExistingNamesInquiredPopUp(item.objectId,item.bapId,item.NameVerified,item.fullAddress,grid,strScreenCode);
				}else if(evt.cellIndex == 5){
					glblUtil.getAddressAlert(item.fullAddress.toString());
				}else if(evt.cellIndex == 8){
					var strSuggestedVSID = item.suggestedVSID.toString();
					if(strSuggestedVSID!=""){
						glblUtil.onViewDocumentsXT(strSuggestedVSID,"","");
					}
				}
			});
		},
		tooltip:function(grid){
			try{
				dojo.connect(grid, "onCellMouseOver", showTooltip);
				dojo.connect(grid, "onCellMouseOut", function(e){
					dijit.hideTooltip(e.cellNode);  
				});
				
				function showTooltip(e) {
					 enabled: true;
					 try{
						 if (grid.getCell(e.cellIndex).field == 'Address') {
							 var value = grid.store.getValue(grid.getItem(e.rowIndex),'fullAddress');
							 dijit.showTooltip(value, e.cellNode);
						 }
					 }catch(e){
						 console.log(e);
					 }
					
				}
				function hideTooltip(e) {
					console.log(e);
					 dijit.hideTooltip(e.cellNode);  
				}
			}catch(err){
				
			}
		},
		OnChangeTag:function(e){
			try{
				if(e!="" || e!="For Encoding"){
					forVerification.getActionTakenNextStep(storeAction,e,function(nextStepCode){
						if(nextStepCode!=undefined){
							grid.store.setValue(grid.getItem(globalRow1), "taggedStatus",e);
							grid.store.setValue(grid.getItem(globalRow1), "nextStepCode",nextStepCode);
							grid.store.save();
						}
					});
				}
			}catch(e){
//				alert(e.message);
			}
				
		},
		getActionTakenNextStep:function(store,ActionTaken,callback){
			var strNextStepCode="";
			store.fetch({
				query: {strActionName:ActionTaken+"*"},
				onItem:function(a){
					strNextStepCode = a.strNextStepCode;
				}
			});
			callback(strNextStepCode);
		},setPaginationObject:function(strTabId,gridId){
			dojo.connect(dojo.byId("resultSize"+strTabId),'onchange',function(){
				rs = dojo.byId("resultSize"+strTabId).value;
				if(rs!=""){
					dojo.byId("currentPage"+strTabId).value = 1;
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+strTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+strTabId).value);
					if(strTabId == "tabAfterCutOff"){
						glblUtil.getCutOff(strTabId,gridId,globalUserId,strRequestNo,"","",strNameVerified,strSuggestedStatus,
								strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								"",strCurrentPage,rs,1);

					}else{
						glblUtil.getForLoandexProcessing(strTabId,gridId,glblRqstType,"","",strRequestNo,
								"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								strSuggestedStatus,strResultSize,strCurrentPage,1);
					}
				}
			});
			
			dojo.connect(dojo.byId("nextPage"+strTabId),'onclick',function(){
				var rs = dojo.byId("resultSize"+strTabId).value;
				var currentPage = Number(dojo.byId("currentPage"+strTabId).value);
				var totalPage 	= dojo.byId("totalPages"+strTabId).innerHTML;

				if (currentPage <= totalPage && currentPage < totalPage){
					currentPage += 1;
					dojo.byId("currentPage"+strTabId).value = currentPage;
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+strTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+strTabId).value);
					if(strTabId == "tabAfterCutOff"){
						glblUtil.getCutOff(strTabId,gridId,globalUserId,strRequestNo,"","",strNameVerified,strSuggestedStatus,
								strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								"",strCurrentPage,strResultSize,1);

					}else{
						glblUtil.getForLoandexProcessing(strTabId,gridId,glblRqstType,"","",strRequestNo,
								"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								strSuggestedStatus,strResultSize,strCurrentPage,1);
					}
				}
			});
			
			dojo.connect(dojo.byId("prevPage"+strTabId),'onclick',function(){
				var rs = dojo.byId("resultSize"+strTabId).value;
				var currentPage = Number(dojo.byId("currentPage"+strTabId).value);
				var totalPage 	= dojo.byId("totalPages"+strTabId).innerHTML;

				if (currentPage <= totalPage && currentPage != 1){
					currentPage -= 1;
					dojo.byId("currentPage"+strTabId).value = currentPage;
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+strTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+strTabId).value);
					if(strTabId == "tabAfterCutOff"){
						glblUtil.getCutOff(strTabId,gridId,globalUserId,strRequestNo,"","",strNameVerified,strSuggestedStatus,
								strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								"",strCurrentPage,strResultSize,1);

					}else{
						glblUtil.getForLoandexProcessing(strTabId,gridId,glblRqstType,"","",strRequestNo,
								"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								strSuggestedStatus,strResultSize,strCurrentPage,1);
					}
				}
			});
			
			dojo.connect(dojo.byId("gotoPage"+strTabId),'onclick',function(){
				var rs = dojo.byId("resultSize"+strTabId).value;
				var currentPage = Number(dojo.byId("currentPage"+strTabId).value);
				if(currentPage != ""){
					var strRequestNo = dijit.byId("textRqstNo").get('value');
					var strNameVerified = dijit.byId("textCustName").get('value');
					var strRqstDateFrm = glblUtil.formatDate(dijit.byId("txtRqstDateFrm").get('value'));
					var strRqstDateTo = glblUtil.formatDate(dijit.byId("txtRqstDateTo").get('value'));
					var strRptDateFrm = glblUtil.formatDate(dijit.byId("txtRptDateFrm").get('value'));
					var strRptDateTo = glblUtil.formatDate(dijit.byId("txtRptDateTo").get('value'));
					var strSuggestedStatus = dijit.byId("cbStatus").get('value');
					var strResultSize = dojo.byId('resultSize'+strTabId).value;
					var strCurrentPage = Number(dojo.byId('currentPage'+strTabId).value);
					if(strTabId == "tabAfterCutOff"){
						glblUtil.getCutOff(strTabId,gridId,globalUserId,strRequestNo,"","",strNameVerified,strSuggestedStatus,
								strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								"",strCurrentPage,strResultSize,1);

					}else{
						glblUtil.getForLoandexProcessing(strTabId,gridId,glblRqstType,"","",strRequestNo,
								"","",strNameVerified,strRqstDateFrm,strRqstDateTo,strRptDateFrm,strRptDateTo,
								strSuggestedStatus,strResultSize,strCurrentPage,1);
					}
				}else{
	        		dijit.byId("currentPage"+strTabId).set('value',1);
				}
			}); 
		},
		
};
function getAuthor(requestNo, rowIndex){
	

};


 

